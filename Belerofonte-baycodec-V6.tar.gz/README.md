# Belerofonte-Baycodec-JS

Extensión de navegador (Manifest V3) que identifica las tecnologías de la página que visitas: CMS, frameworks, UI frameworks, servidores, CDN, analítica, pagos, etc. Funciona como Wappalyzer. Además analiza la **tipografía** que usa realmente la página.

## Instalación (Chrome, Edge, Brave, Chromium)

1. Abre `chrome://extensions` (en Edge: `edge://extensions`).

2. Activa el **Modo desarrollador**.

3. Pulsa **Cargar descomprimida** y selecciona esta carpeta.

4. Visita cualquier web: el icono muestra cuántas tecnologías se detectaron; haz clic para ver el detalle.

Tras modificar el código o las reglas, pulsa el botón de recargar de la extensión en `chrome://extensions`.

## Estructura

```
manifest.json            Permisos y configuración
background.js            Service worker: recoge datos de la página y ejecuta el motor
engine.js                Motor de detección (patrones, versiones, confianza, implies)
domain.js                Perfil del dominio: RDAP, IP, archive.org y estimación de antigüedad
wordpress.js             Análisis de WordPress: versión del núcleo, tema y plugins frente a WordPress.org
capture.js               Capturas de pantalla: área visible, página completa y selección
capture/                 Pestaña de vista previa de la captura (copiar, descargar PNG / PDF)
downloads/               Gestor de descargas: engine-worker.js (motor por partes) + downloads.html
float/float.js           Botón «⬇ Descargar» sobre los videos (script de contenido)
float/sniff.js           Detecta listas HLS en reproductores blob: (MediaSource), aunque vengan disfrazadas
speedtest/               Prueba de velocidad: latencia, jitter, bajada y subida (Cloudflare)
eyedropper.js            Cuentagotas: elegir el color de cualquier punto de la página
fontinspector.js         Identificar fuente: pasar el cursor sobre un texto para ver su fuente
media.js                 Videos: detecta archivos y streams HLS de la pestaña y lanza la descarga
okru.js                  Videos de OK.ru: lee los MP4 de cada calidad desde la página de su reproductor
video/                   Página de descarga HLS y DASH: hls.js (.m3u8), dash.js (.mpd), mp4.js (TS → MP4, une pistas), oembed.js (títulos), subtitles.js (subtítulos), lib/mux.js
native/                  Conector nativo con yt-dlp (YouTube…): belerofonte_ytdlp.py + instalar.sh (Linux) / instalar.bat (Windows)
data/technologies.json   Base de reglas (categorías + tecnologías)
data/public-suffixes.txt Public Suffix List (ICANN) para calcular el dominio registrable
popup/                   Interfaz que aparece al hacer clic en el icono
icons/                   Iconos de la extensión: 128 y 48 px desde icono.svg; 32 y 16 px desde icono-pegaso.svg
icons/logo/icono.png     Logo original (Belerofonte sobre Pegaso)
icons/logo/icono.svg     Logo vectorizado (círculo, degradado y figuras trazadas con potrace)
icons/logo/icono-pegaso.svg  Variante sin texto, con Pegaso más grande, para los tamaños pequeños
icons/tech/              Logos de las tecnologías (generados con tools/build-icons.py)
test/icons.html          Hoja con todos los logos para revisarlos
tools/build-icons.py     Genera los logos a partir de Simple Icons
tools/vectorize-logo.py  Convierte icons/logo/icono.png en icono.svg e icono-pegaso.svg (instrucciones dentro)
test/engine-test.html    Pruebas del motor (ver abajo)
```

## Cómo detecta

| Método | De dónde sale | Ejemplo |
| - | - | - |
| `headers` | `chrome.webRequest` sobre el documento principal | `Server: nginx/1.25.3` |
| `cookies` | `chrome.cookies` (incluye las HttpOnly) | `PHPSESSID`, `laravel_session` |
| `meta` | `<meta name/property>` | `generator: WordPress 6.6` |
| `html` | HTML de la página (primeros 500 KB) | `<link href=".../wp-content/...">` |
| `scripts` | `src` de `<script>` + scripts cargados dinámicamente | `cdn.shopify.com` |
| `resources` | Hojas de estilo, archivos de fuentes y demás recursos descargados | `fonts.gstatic.com` |
| `css` | `<style>` y hojas de estilo del mismo dominio | `tailwindcss v3.4.4` |
| `js` | Variables globales, leídas en el mundo `MAIN` de la página | `jQuery.fn.jquery` |
| `dom` | Selectores CSS y sus atributos | `[ng-version]` |
| `domProps` | Propiedades internas de los nodos | `__reactFiber`, `__vue_app__` |
| `url` | URL de la página | `\.php$` |
| `implies` | Deducción a partir de otra tecnología | WordPress ⇒ PHP, MySQL |


## Tipografía

La sección **Tipografía** del popup no usa reglas: se calcula sobre la página.

- **Fuente pintada:** para cada elemento con texto se lee su `font-family` calculada y se toma la primera webfont cargada de la pila; si no hay ninguna, la primera de la lista (local o del sistema).

- **% del texto:** proporción de caracteres pintados con cada fuente.

- **Uso:** Títulos (`h1`–`h6`), Texto, Código (`pre`, `code`) o Iconos (Font Awesome, Material Icons…).

- **Pesos** realmente usados (400, 700…).

- **Origen:** Google Fonts, Adobe Fonts, Bunny Fonts, Fontshare, autoalojada, CDN o del sistema. Se deduce de las URLs de los archivos de fuente, de los enlaces a Google/Bunny Fonts y de las reglas `@font-face`.

La vista previa «Aa» de las fuentes de Google Fonts se descarga de Google al abrir el popup. Las demás solo se ven si la fuente también está instalada en tu equipo.

## Capturas de pantalla

La sección **📷 Capturar** del popup tiene tres modos:

| Botón | Qué hace |
| - | - |
| **Área visible** | Captura lo que se ve ahora en la pestaña. |
| **Página completa** | Primero prepara la página: congela animaciones y transiciones y la recorre entera para que aparezca el contenido que se muestra al hacer scroll y se carguen las imágenes diferidas. Después la desplaza de arriba abajo, captura cada tramo (solapándolos 2 px para que no queden líneas en pantallas al 125 %, 150 %…) y los une en una sola imagen. Desde el segundo tramo oculta los elementos fijos (cabeceras, banners de cookies…) para que no se repitan, y al terminar deja la página como estaba. |
| **Selección** | Cierra el popup y oscurece la página: arrastra para elegir la región (Esc cancela). |


La captura se abre en una pestaña nueva con los botones **Copiar imagen**, **Descargar PNG** y **Descargar PDF**. Se guarda solo en memoria (las 3 últimas) y no se envía a ningún sitio.

El PDF se genera en el propio navegador (`capture/pdf.js`, sin bibliotecas) con la imagen sin pérdida y ajustada al ancho de un A4. Si la captura cabe en una página, la página mide lo mismo que la imagen. Si es más alta (página completa), un selector junto al botón permite elegir:

- **Páginas A4**: listas para imprimir (el corte puede caer a mitad de una línea).

- **Una sola página larga**: sin cortes. Los visores no admiten páginas de más de 14 400 pt (~5 m), así que en capturas muy largas la página se reduce; la imagen conserva todos sus píxeles y se ve nítida al hacer zoom.

Limitaciones: la página completa tarda ~0,6 s por pantalla (Chrome no permite capturar más rápido) más el recorrido previo (máximo 15 s en webs con scroll infinito); en páginas muy largas se corta al llegar al tamaño máximo de imagen (se avisa); si la página se desplaza dentro de un contenedor propio en vez de en la ventana, solo se captura lo visible; la selección se limita a la parte visible de la página.

## Velocidad de internet

El botón **📶 Medir latencia, bajada y subida** del popup abre una pestaña que mide la conexión contra el servidor de Cloudflare más cercano (`speed.cloudflare.com`, el mismo de su propia prueba):

| Dato | Cómo se mide |
| - | - |
| **Latencia (ping)** | 20 peticiones vacías: de cada una se toma el tiempo hasta el primer byte (Resource Timing) y se resta lo que el servidor dice haber tardado (`Server-Timing`). Se da la mediana |
| **Jitter** | Media de las diferencias entre latencias seguidas (importante en videollamadas y juegos) |
| **Bajada** | 6 conexiones en paralelo durante ~8 s; se descartan los primeros instantes, mientras la conexión acelera |
| **Subida** | 4 conexiones en paralelo enviando datos aleatorios durante ~8 s, igual que la bajada |
| **Latencia al sitio** | Si se abre desde una web, 6 peticiones `HEAD` a ese sitio: la primera (DNS + conexión + TLS) y la mediana de las siguientes |


La velocidad se ve en vivo mientras se mide. Al terminar, cada dato lleva una valoración (excelente, buena…), una lista de **qué puedes hacer** con esa conexión (4K, videollamadas, juegos…), **tu conexión** (proveedor de internet u operador con su ASN, IP pública IPv4 e IPv6 por separado, ubicación aproximada y centro de datos de la prueba), y el botón **Copiar resultado**. Las 10 últimas mediciones se guardan en el navegador.

Privacidad y datos: Cloudflare recibe tu IP como en cualquier visita; la IPv4 se obtiene de `1.1.1.1` y la IPv6 de `2606:4700:4700::1111` (Cloudflare), y el proveedor de [ipwho.is](https://ipwho.is/), al que se envía tu IP. La prueba usa como máximo ~300 MB de bajada y ~100 MB de subida (en conexiones rápidas termina antes); con datos móviles, tenlo en cuenta. Para un resultado fiable, cierra otras descargas y videos.

## Cuentagotas

La sección **🎨 Cuentagotas** del popup permite obtener el color de cualquier punto de la página:

1. Pulsa **Elegir un color de la página**. El popup se cierra y la página se «congela»: se pone encima una captura de lo que se ve, así el color elegido es exactamente el que ves, aunque haya animaciones o vídeos.

2. Mueve el ratón: una **lupa** muestra los píxeles ampliados y el código HEX del píxel central.

3. Haz clic. Aparece una tarjeta con el color en **HEX** (`#3498DB`), **RGB** (`rgb(52, 152, 219)`) y **HSL** (`hsl(204, 70%, 53%)`), cada uno con su botón **Copiar**. El HEX se copia solo. **Elegir otro color** vuelve a abrir el cuentagotas. **Esc** cancela.

4. Debajo, **Colores que combinan** propone paletas con el color elegido y 3 compatibles, girando su tono en el círculo cromático (mismas saturación y luminosidad):

| Paleta | Colores | Para qué |
| - | - | - |
| **Análogos** | tono −30°, +30°, +60° | Armonía suave, poco contraste |
| **Complementarios** | tono +150°, +180°, +210° | Máximo contraste, para destacar botones o avisos |
| **Cuadrada** | tono +90°, +180°, +270° | Paleta variada y equilibrada |
| **Monocromática** | mismo tono, más claro y más oscuro | Fondos, bordes y estados (hover, desactivado) |


Haz clic en un color para copiar su HEX, o en **Copiar** para copiar la fila entera (`#3498DB, #34DBCA, #3445DB, #7734DB`). Con un color neutro (gris, blanco, negro) girar el tono no cambia nada, así que solo se ofrece la paleta monocromática.

Los últimos 12 colores se guardan en el navegador (`chrome.storage.local`) y aparecen en el popup como muestras: haz clic en una para copiar su HEX.

No se usa la API nativa `EyeDropper` porque se cancela al cerrarse el popup y no existe en Firefox.

## Identificar fuente

La sección **🔤 Identificar fuente** del popup (o clic derecho → **Identificar fuente** en cualquier página) sirve para ver con qué fuente está escrito cualquier texto, sin abrir DevTools:

1. Pulsa **Ver la fuente de cualquier texto**. El popup se cierra.

2. Pasa el cursor por la página: el elemento se resalta y un recuadro muestra la **fuente** **pintada**, el tamaño y el peso.

3. Haz clic en un texto (no se siguen los enlaces ni se activan los botones mientras está abierto). Aparece una tarjeta con una muestra del texto en esa fuente y:

   - **Fuente pintada** y su origen: *webfont descargada por la página*, *instalada en tu equipo*, *genérica* (`serif`, `sans-serif`…) o *no disponible*.

   - **Pila CSS** completa (`font-family`), **tamaño** en px y rem, **peso** (700 · Bold), **estilo**, **interlineado**, **espaciado entre letras** y **color** en HEX.

   - Botones **Copiar nombre** y **Copiar CSS** (las propiedades listas para pegar).

Haz clic en otro texto para compararlo; **Esc** sale.

La fuente pintada es la primera de la pila que está disponible: una webfont ya cargada, o una fuente local que se comprueba midiendo un texto de prueba en un `canvas`. La interfaz va en un Shadow DOM cerrado, así que el CSS de la página no la altera.

Limitaciones: si una fuente no tiene algún carácter concreto (emojis, otros alfabetos), el navegador lo pinta con la siguiente de la pila y eso no se refleja; con una genérica (`sans-serif`) no se puede saber qué fuente exacta del sistema elige el navegador; no inspecciona el contenido de los `iframe`.

## Videos

La sección **🎬 Videos de la página** del popup lista los videos que ha cargado la pestaña:

| Tipo | Cómo se detecta | Qué hace el botón |
| - | - | - |
| **Archivo** (MP4, WebM, MOV, MP3…) | Peticiones de red con esa extensión o `Content-Type: video/*` / `audio/*`, y las etiquetas `<video>` / `<audio>` | **Descargar** con el gestor de descargas de la extensión (varias conexiones, se puede pausar) |
| **HLS** (`.m3u8`) | Listas pedidas por el reproductor (`.m3u8` o `Content-Type` `mpegurl`) | Abre una pestaña para elegir la **calidad** y descargar |
| **HLS en directo** | Lista sin `#EXT-X-ENDLIST` | **Grabar**: guarda desde ese momento hasta que pulses *Detener y guardar* |


La descarga HLS baja los segmentos de 6 en 6 (con 3 reintentos), muestra el progreso, la velocidad y el tiempo restante, y al terminar los convierte en **un solo archivo MP4** con video y audio, sin recodificar (no se pierde calidad):

- Segmentos MPEG-TS (`.ts`) o AAC → se remuxan a MP4 con [mux.js](https://github.com/videojs/mux.js) (incluido en `video/lib/`, licencia Apache-2.0).

- Segmentos fMP4 (`#EXT-X-MAP`) → ya son MP4: se unen tal cual.

- Si el audio va en una pista aparte (`#EXT-X-MEDIA:TYPE=AUDIO`), se descargan las dos y se combinan en el mismo MP4 (`video/mp4.js`). Un stream solo de audio se guarda como `.m4a`.

- Si la conversión falla (p. ej. un códec que mux.js no admite, como HEVC dentro de TS), se guarda el formato original (`.ts`) y la página explica cómo convertirlo con ffmpeg.

El MP4 resultante es *fragmentado* (como el que usan los propios reproductores web): se reproduce en el navegador, VLC, mpv y la mayoría de reproductores y editores. Todo el video se guarda en memoria hasta el final, así que un video muy largo necesita bastante RAM.

Si el reproductor no ha pedido el video todavía, no aparece: dale a reproducir unos segundos y vuelve a abrir el popup. También puedes **pegar un enlace** (`.mp4`, `.m3u8`…) en el campo de la sección; si no tiene extensión, se mira el `Content-Type` que devuelve el servidor.

**Reproductores con `blob:` (MediaSource).** Muchos reproductores (hls.js, Video.js, JW Player…) ponen en el `<video>` una dirección `blob:` que no se puede descargar: el video llega por trozos a través de una lista HLS. Para encontrarla aunque venga disfrazada (`/api/source`, `.txt`, `.png`, sin extensión, servida como `text/plain`) o creada en memoria, `float/sniff.js` se ejecuta en cada página y marco (también en los iframes de otros dominios) y mira el comienzo de las respuestas pequeñas de `fetch` y `XMLHttpRequest`, y los `blob:` que crea la página: si empiezan por `#EXTM3U`, la lista aparece en *Videos de la página* y en el botón **⬇ Descargar** sobre el video. Basta con **darle a reproducir unos segundos**. Se guarda la dirección del reproductor que la pidió y se usa como `Referer` al leer la lista y al descargar, porque muchos servidores solo entregan el video a su reproductor. No modifica las peticiones ni las respuestas de la página. Detecta igual los manifiestos DASH (`<MPD`). No sirve para contenido cifrado o con DRM.

**DASH (`.mpd`).** Muchos sitios entregan el video como DASH en lugar de HLS: un manifiesto `.mpd` (o `Content-Type: application/dash+xml`) con cada calidad de video y cada pista de audio por separado. Aparecen en *Videos de la página* y en el botón flotante con la etiqueta **DASH**; la página de descarga deja elegir la calidad y el audio, baja los segmentos en paralelo y une video y audio en **un solo MP4** sin recodificar (`video/dash.js`). Admite las tres formas de indicar los segmentos: `SegmentTemplate` (con `$Number$`, `$Time$` y `SegmentTimeline`), `SegmentList` y `SegmentBase` (un archivo por calidad, troceado con su índice `sidx`). Con varios periodos se descarga el más largo (el contenido principal, no los anuncios). No admite contenido con DRM (`ContentProtection`); si las pistas son WebM, se guardan por separado (video y audio) porque no se pueden pasar a MP4 sin recodificar.

**Directos DASH.** Un manifiesto con `type="dynamic"` aparece como *🔴 En directo* y el botón cambia a **⏺ Grabar directo**: graba desde el borde del directo (como un reproductor, con los últimos segundos publicados) hasta que pulses *Detener y guardar*. Cada pocos segundos se vuelve a leer el manifiesto y se bajan solo los segmentos nuevos. Funciona con `SegmentTimeline` (el manifiesto enumera los segmentos publicados) y con `SegmentTemplate` de duración fija (los segmentos se calculan con la hora: el reloj se sincroniza con el del servidor mediante `UTCTiming` o la cabecera `Date`). Si un segmento no está disponible, se salta y se avisa en lugar de cortar la grabación. Al guardar, las marcas de tiempo se ponen a cero (la grabación empieza en 0:00 aunque la emisión lleve horas) manteniendo el audio sincronizado con el video.

**Subtítulos (HLS y DASH).** Si el stream trae subtítulos, la página de descarga los muestra debajo de la calidad (💬, marcado el idioma del navegador) y la lista de videos indica los idiomas. Se descargan junto con el video o solos (**💬 Solo subtítulos**), en **SRT** (funciona en casi todos los reproductores y televisores) o **WebVTT** (conserva estilos y posiciones), con el nombre del video más el idioma (`Video.es.srt`), así VLC, mpv y la mayoría de reproductores los cargan solos (`video/subtitles.js`).

| Origen | Formatos |
| - | - |
| HLS | Pistas `#EXT-X-MEDIA:TYPE=SUBTITLES`: WebVTT por segmentos (o WebVTT dentro de MP4) |
| DASH | Pistas de texto: archivo `.vtt` o `.ttml` entero, segmentos de texto, o MP4 con `wvtt` (WebVTT) o `stpp` (TTML / EBU-TT-D / IMSC) |

Las frases de todos los segmentos se unen (sin repetir las que aparecen en dos segmentos) y se sincronizan con el video guardado, que empieza en 0:00: en HLS con `X-TIMESTAMP-MAP` y el primer instante del video, en DASH con la línea de tiempo del stream y `presentationTimeOffset`. Al pasar a SRT se conservan la cursiva, la negrita y el subrayado; se quitan las demás etiquetas. No se graban subtítulos de los directos, ni los subtítulos incrustados en la imagen o dentro de los segmentos de video (CEA-608/708).

**Título del video.** En YouTube, Vimeo y TikTok el título se obtiene al momento con oEmbed (el servicio público de esos sitios para mostrar sus videos en otras webs) y aparece en la pestaña de descarga y en el popup al pegar un enlace, aunque el enlace venga de una vista previa o se haya pegado a mano; yt-dlp lo confirma en cuanto lee el video. El archivo se guarda como `Título [id].mp4`.

**Enlaces con token y protección anti-hotlink.** Muchos servidores (p. ej. enlaces como `…/key=…,end=1791483182/state=…/video.mp4`) rechazan con 403 las peticiones que no llevan como `Referer` la página del video. El gestor de descargas y la página de HLS añaden el `Referer` y el `Origin` de la web del video con una regla temporal de `declarativeNetRequest` limitada a las peticiones de la extensión hacia ese servidor (permiso `declarativeNetRequestWithHostAccess`). Lo que no se puede evitar: si el enlace ya caducó (`end=` es la hora de caducidad) o está ligado a otra IP, hay que recargar la página del video para obtener uno nuevo.

**YouTube** y **Vimeo** se descargan con **yt-dlp**, que la extensión arranca ella misma a través de un conector nativo (*Native Messaging*): no hace falta abrir ningún servidor ni terminal. Solo hay que registrarlo **una vez**. El ID de la extensión es fijo (`dejpllhccjefbgonpfchjndlabeklghh`, sale de la `"key"` de `manifest.json`), así que no hay que repetirlo si mueves la carpeta.

**Windows:** si falta el conector, la página de descarga muestra el botón **⬇ Descargar el instalador**: genera `instalar-belerofonte.bat`, que lleva dentro el conector y el instalador, los copia a `%LOCALAPPDATA%\Belerofonte-Baycodec\native` y los registra con el ID de la extensión; al terminar, pulsa **🔄 Reintentar**. También puedes hacer doble clic en **`native\instalar.bat`**. Descarga e instala dentro de esa misma carpeta, sin permisos de administrador, todo lo que haga falta:

| Qué | Dónde | Para qué |
| - | - | - |
| Python 3.13 (solo si no tienes Python 3.10 o posterior) | `native\python\` (con tu Python: entorno en `native\venv\`) | Ejecutar el conector |
| yt-dlp, yt-dlp-ejs y curl_cffi | dentro de ese Python | Descargar; reto de YouTube; TikTok |
| ffmpeg y ffprobe ([compilación de yt-dlp](https://github.com/yt-dlp/FFmpeg-Builds)) | `native\ffmpeg\bin\` | Unir video y audio, MP3, subtítulos |
| Deno (si no hay Deno ni Node) | `native\deno\` | Resolver el reto en JavaScript de YouTube |

Antes de instalar, comprueba el SHA-256 de cada descarga (y la firma digital del instalador de Python). Después registra el conector en Chrome, Edge, Brave, Chromium y Vivaldi (registro de Windows, `HKCU`) y escribe `native\host.bat`. Recarga la extensión al terminar. Para quitarlo: `powershell -ExecutionPolicy Bypass -File native\instalar.ps1 -Desinstalar`.

**Linux:**

```
cd "/run/media/baycodec/Disco-01/Proyectos/Belerofonte-baycodec-V1" && ./native/instalar.sh
```

El instalador busca un Python con yt-dlp (primero el `venv` de `descargar-videos-youtube`, luego el del sistema; si no hay, crea `native/venv` e instala yt-dlp), se asegura de que estén **yt-dlp-ejs** y un entorno de JavaScript (si no hay Deno, Node ni Bun, descarga **Deno** a `~/.deno/bin` desde su release oficial y comprueba su SHA-256), genera `native/host.sh` y registra `com.baycodec.belerofonte_ytdlp` para Chrome, Chromium, Brave, Edge y Vivaldi. Calcula el ID de la extensión a partir de la `"key"` de `manifest.json` (`--id` para indicarlo a mano). `--desinstalar` lo quita.

Al pegar un enlace de YouTube o Vimeo (o abrir el popup en un video de esos sitios, que se rellena solo) aparecen las opciones: **calidad** (mejor, 1080p, 720p, 480p, 360p), **solo audio MP3** (320, 192 o 128 kbps) y **subtítulos** (es/en, incrustados). La pestaña de descarga muestra el progreso de yt-dlp; **Cancelar** detiene la descarga y borra el archivo a medias. El resultado se guarda en tu carpeta de descargas (`~/Descargas`) con el nombre `Título [id].mp4` (o `Título [id] - audio.mp3`), y el botón **📂 Abrir la carpeta** la abre. Hace falta `ffmpeg` para unir video y audio y para MP3. Si YouTube cambia y deja de funcionar, actualiza yt-dlp en el Python del conector (`…/venv/bin/pip install -U "yt-dlp[default]"`).

*«HTTP Error 403: Forbidden»*: YouTube entrega cada video con un reto en JavaScript que yt-dlp solo resuelve con `yt-dlp-ejs` y un entorno de JS (Deno). El conector busca Deno también en `~/.deno/bin`, porque Chrome lo arranca con un `PATH` mínimo. Vuelve a ejecutar `./native/instalar.sh` para instalar lo que falte.

**Vimeo.** Valen los enlaces `vimeo.com/123456`, `vimeo.com/123456/hash` (videos ocultos), `vimeo.com/channels/…/123456` y `player.vimeo.com/video/123456`; todos se pasan a yt-dlp como el del reproductor, que no exige iniciar sesión. En una web que **inserta** un video de Vimeo, la sección *Videos de la página* lo muestra con la etiqueta *Vimeo*: al descargarlo se envía esa web como `Referer`, porque muchos videos solo se pueden ver desde la web que los inserta. Los videos de Vimeo con **DRM** (Widevine/PlayReady) no se pueden descargar: yt-dlp no los descifra y la página lo indica. Tampoco los privados que exigen contraseña o cuenta.

A veces Vimeo bloquea a yt-dlp aunque el video sea público (*«We couldn't verify the security of* *your connection»*, HTTP 401). Alternativa: reproduce el video en su pestaña unos segundos y vuelve a abrir el popup; el stream HLS que cargó el reproductor aparece en *Videos de la página* y se descarga desde el navegador como cualquier HLS (si tiene DRM, sale como *Protegido*).

**TikTok** también se descarga con yt-dlp. Valen los enlaces `tiktok.com/@usuario/video/ID`, los cortos (`vm.tiktok.com/…`, `vt.tiktok.com/…`, `tiktok.com/t/…`) y los del reproductor insertado (`tiktok.com/embed/v2/ID`, que se pasa a yt-dlp como `tiktok.com/@/video/ID`). En una web que inserta un TikTok (iframe o `<blockquote class="tiktok-embed">`), la sección *Videos de la página* lo muestra con la etiqueta *TikTok*. TikTok rechaza a yt-dlp (*«Your IP address is blocked from accessing this post»*) si no imita a un navegador; para eso necesita **curl_cffi**, que `./native/instalar.sh` instala (`yt-dlp[default,curl-cffi]`). Si con curl_cffi sigue saliendo ese error con un video concreto, ese video no está disponible en tu país.

**Instagram** se descarga con yt-dlp. Valen los enlaces de reels y publicaciones (`instagram.com/reel/…`, `/reels/…`, `/p/…`, `/usuario/p/…`, `/tv/…`) y de historias (`/stories/usuario/ID`); en una web que inserta una publicación (iframe `…/embed` o `<blockquote class="instagram-media">`), aparece en *Videos de la página*. Instagram solo entrega la mayoría de los reels con la sesión iniciada, así que la página de descarga lee las cookies de `instagram.com` del navegador (permiso `cookies`) y se las pasa al conector, que las escribe en un archivo temporal legible solo por tu usuario y lo borra al terminar o cancelar; no salen de tu equipo salvo hacia Instagram. Si no has iniciado sesión, solo se pueden bajar las publicaciones que Instagram muestra sin cuenta. Los trozos `…mp4?bytestart=…` que pide el reproductor (pistas DASH con video y audio por separado, también en Facebook) ya no se listan, porque descargarlos daba archivos sin sonido: esos videos se bajan con yt-dlp.

**Facebook** se descarga con yt-dlp: reels (`/reel/ID`), `/watch/?v=ID`, `/usuario/videos/ID`, `video.php?v=ID`, directos (`/watch/live/?v=ID`), publicaciones de páginas y grupos (`/usuario/posts/…`, `/groups/…/posts/…`, `story.php`, `permalink.php`) y el reproductor insertado (`/plugins/video.php?href=…` o `<div class="fb-video">`, que aparece en *Videos de la página*). Valen también `m.`, `web.` y `mbasic.facebook.com`. Los enlaces del botón *Compartir* (`facebook.com/share/v/…`, `/share/r/…`, `fb.watch/…`) yt-dlp no los entiende: la extensión los sigue primero hasta el video. Los videos públicos se bajan sin cuenta; para los privados o de grupos se pasan a yt-dlp las cookies de `facebook.com`, igual que con Instagram. El conector quita del nombre del archivo las estadísticas que Facebook pone delante del título («9.8K views · 341 reactions | …»).

**OK.ru** (Odnoklassniki) no usa yt-dlp, cuyo extractor de OK.ru dejó de funcionar: la extensión lee la página del reproductor (`ok.ru/videoembed/ID`), que publica un MP4 directo por calidad (144p a 1440p/2160p), y lo descarga con el gestor de descargas como `Título [720p].mp4`. Esos enlaces van atados a tu IP y a tu navegador, y caducan en unas horas, por eso se piden en el momento:

- En la página de un video de OK.ru, la sección *Videos de la página* muestra una entrada por calidad.

- En una web que inserta un video de OK.ru, también aparecen sus calidades (hasta 3 videos).

- Al pegar un enlace (`ok.ru/video/ID`, `m.ok.ru/video/ID`, `ok.ru/videoembed/ID`) se elige la calidad y se baja la más alta que no la supere.

- Las emisiones en directo se graban con su lista HLS.

Con esta función la extensión no es apta para la Chrome Web Store (que no admite descargadores de YouTube); úsala para uso personal y respetando los derechos de autor.

**No se descarga** contenido cifrado ni con DRM (`#EXT-X-KEY` con AES-128, SAMPLE-AES, `ContentProtection` de DASH, Widevine, FairPlay…): aparece como *Protegido*. Descarga solo videos que tengas derecho a guardar. Otros límites: los videos `blob:` cuyo reproductor no pide ninguna lista HLS ni manifiesto DASH reconocible no son compatibles, y algunos servidores rechazan las peticiones que no vienen de su propia web.

## Gestor de descargas

Funciona como Internet Download Manager. Se abre con **📥 Gestor de descargas** (popup, sección Videos) y aparece solo al añadir una descarga. Es una ventana propia: **déjala abierta** mientras descarga; si la cierras, las descargas se pausan y continúan solas al volver a abrirla (también tras reiniciar el navegador).

| Función | Cómo funciona |
| - | - |
| **Descarga acelerada por partes** | El archivo se divide en trozos y cada uno se pide por una conexión distinta (cabecera `Range`), hasta 16 a la vez (8 por defecto). Cuando una conexión termina su trozo, el que más tiene pendiente se parte por la mitad y la conexión libre se lleva la segunda mitad (división dinámica, como IDM). La barra de progreso muestra un tramo por conexión |
| **Pausar y reanudar** | ⏸ / ▶ en cada descarga o en todas. Lo descargado queda en el disco (almacenamiento privado de la extensión, OPFS) y al reanudar cada trozo sigue donde quedó. Con `If-Range` se comprueba que el archivo no cambió en el servidor; si cambió, se descarga de nuevo desde el principio |
| **Cola e historial** | Descargas a la vez configurables (3 por defecto); las demás esperan **En cola**. La lista guarda las últimas 300 (también las de HLS y yt-dlp), con filtros *En curso*, *Completadas* y *Con error*, y botones **Abrir**, **Mostrar en la carpeta**, **Copiar enlace**, **Reintentar** y **Quitar** |
| **Botón flotante sobre los videos** | Al pasar el ratón sobre un video aparece **⬇ Descargar** arriba a la derecha. Ofrece las formas de bajar ese video: yt-dlp en YouTube, Vimeo, TikTok, Instagram y Facebook (mejor calidad, 720p o solo audio MP3), el archivo del `<video>` y los streams HLS o archivos que haya detectado la pestaña. Se desactiva en ⚙ Ajustes o con «Ocultar este botón» |

También se puede **pegar un enlace** en el gestor: los archivos se bajan ahí mismo y los de YouTube, Vimeo, listas `.m3u8`… abren su página de descarga como desde el popup.

Al terminar, el archivo se entrega a la carpeta de descargas del navegador y se borra la copia privada (durante la descarga ocupa su tamaño en el disco del perfil del navegador; permiso `unlimitedStorage`).

Limitaciones: si el servidor no admite `Range` se usa una sola conexión y no se puede pausar (al reanudar empieza de cero; el gestor lo avisa); las descargas solo avanzan con la ventana del gestor abierta; los enlaces con caducidad pueden fallar al reanudarlos mucho después (vuelve a la página del video y descárgalo otra vez); el botón flotante aparece en las pestañas que se carguen después de instalar o recargar la extensión.

## Simulador de dispositivos

El botón **📱 Ver este sitio en móviles, tablets y más** del popup abre el sitio en una pestaña de simulador con **124 dispositivos** (`simulator/devices.js`): 35 iPhone, 51 Android (Pixel, Galaxy, Xiaomi, OnePlus, Motorola, Huawei, Sony…), 5 plegables, 17 tablets (iPad, Galaxy Tab, Pixel Tablet, Surface…), 13 portátiles y monitores, y 3 relojes. Las medidas (px CSS y DPR) son aproximadas según las especificaciones públicas.

- **Buscador** y selector agrupado por tipo; **‹ ›** (o las flechas del teclado) para pasar de uno a otro; **Girar** (o la tecla R) para verlo en horizontal.

- **Zoom**: Ajustar a la ventana, 100 %, 75 %, 50 % o 33 %. **Marco**: muestra u oculta el dibujo del dispositivo (Dynamic Island, notch, botón de inicio, cámara perforada, portátil, monitor…).

- **Barra de direcciones** (sigue los enlaces que pulses dentro; **Ir** carga esa dirección en todas las vistas), **↻** recargar, **↗** abrir en una pestaña normal y **📷** capturar (con varias vistas, todas juntas; abre la vista previa de capturas).

**Comparar dispositivos.** **➕ Añadir vista** pone otro dispositivo al lado (hasta 6); cada vista tiene su barra con el nombre, el tamaño, ⟳ girar y ✕ quitar. Haz clic en la barra de una vista para que sea la **activa**: el selector, ‹ ›, el buscador y Girar de arriba actúan sobre ella. Las **plantillas** cargan comparaciones típicas (Móvil · Tablet · Escritorio, iPhone vs Android, tamaños de iPhone, tablets, portátiles y monitores, plegable cerrado y abierto). Con **Desplazamiento sincronizado**, al bajar en una vista las demás bajan a la misma altura proporcional. *Ajustar* encaja todas las vistas en la ventana. Las vistas se recuerdan.

Al comparar, el **servidor** recibe el User-Agent de la **primera vista** en todas (Chrome solo permite cambiar las cabeceras por pestaña, no por marco); el tamaño, el diseño *responsive* y lo que ven los scripts sí son los de cada dispositivo. La página lo avisa cuando las vistas mezclan sistemas.

Para que el sitio se comporte como en el dispositivo:

| Qué | Cómo |
| - | - |
| Ancho y alto de la ventana (diseño *responsive*) | El marco mide lo mismo que la pantalla del dispositivo |
| Versión móvil del servidor | Se envía el `User-Agent` y los Client Hints (`Sec-CH-UA-Mobile`, `Sec-CH-UA-Platform`) del dispositivo; los iPad se presentan como Mac, igual que Safari en iPadOS |
| Lo que ven los scripts | `simulator/frame.js` ajusta `navigator.userAgent`, `platform`, `maxTouchPoints`, `devicePixelRatio` y `screen`, y oculta las barras de desplazamiento |
| Sitios que prohíben mostrarse en marcos | Se quitan `X-Frame-Options` y `Content-Security-Policy` de la respuesta |
| Sitios que intentan «escaparse» del marco | El marco no permite navegar la ventana principal (`sandbox` sin `allow-top-navigation`) |


Todo eso afecta **solo a la pestaña del simulador**: las reglas de `declarativeNetRequest` van limitadas a ella y el script solo está registrado mientras haya un simulador abierto (y solo actúa en su marco). Al cerrarlo se quita todo.

Limitaciones: es una simulación en el motor de Chrome, no Safari ni un móvil real (diferencias de renderizado, fuentes, `:hover`, gestos táctiles); las páginas sin `<meta name="viewport">` no se ven «alejadas» como en un móvil; dentro del marco las cookies son de terceros, así que las sesiones iniciadas pueden no aparecer; el 📷 captura solo la parte visible de la ventana.

## Análisis de WordPress

El botón **🧩 Analizar WordPress: versión, tema y plugins** del popup muestra, en sitios hechos con WordPress, qué versión usan y si están al día:

| Qué | De dónde sale (de más a menos fiable) |
| - | - |
| **Versión de WordPress** | Feed RSS (`/feed/` → `<generator>`), `wp-links-opml.php`, `<meta name="generator">`, `?ver=` de los archivos de `wp-includes` y `readme.html` |
| **Tema** (activo y padre) | Carpeta `wp-content/themes/<tema>/` en la página; nombre, versión y autor de su `style.css`. Si es un tema hijo (`Template:`), también se lee el padre |
| **Plugins** | Carpetas `wp-content/plugins/<plugin>/` y `mu-plugins/` en la página, firmas en comentarios HTML y `generator` (Yoast, AIOSEO, Rank Math, MonsterInsights, LiteSpeed, WP Rocket…) y espacios de nombres de la API REST (`/wp-json/`) |
| **Versión de cada plugin** | Firma en el HTML, `Stable tag` de su `readme.txt` o el `?ver=` de sus archivos |
| **Última versión** | API de WordPress.org: ✓ *Al día*, ⚠ *Desactualizado · última X* o *Premium o propio* si no está en el directorio |


Solo se leen archivos públicos, los mismos que puede abrir cualquier visitante; no se prueban rutas a ciegas. A WordPress.org solo se envían los nombres (slugs) del tema y los plugins. El resultado se guarda una hora en memoria de la sesión; el botón **↻ Volver a analizar** lo repite.

Limitaciones: solo aparecen los plugins que dejan rastro en la página analizada o en la API REST (un plugin que solo actúa en el panel de administración no se ve); muchos sitios ocultan la versión o bloquean `readme.txt`, `/feed/` o `/wp-json/`; el `?ver=` de un plugin a veces es la versión de una biblioteca que incluye y no la del plugin.

## Antigüedad del dominio

El botón **🕰 Ver antigüedad del dominio** del popup muestra un perfil tipo WHOIS en español:

| Dato | Fuente |
| - | - |
| Registrador, ID IANA, fechas de creación / vencimiento / actualización, estado, servidores de nombres, DNSSEC | [RDAP](https://rdap.org/) (el sustituto oficial de WHOIS) |
| Dirección IP | La conexión real de la pestaña (o DNS de Cloudflare) |
| Ubicación de la IP, ASN | [ipwho.is](https://ipwho.is/) |
| Titular de la red, fecha de registro del ASN | RDAP |
| Primera captura del sitio | [Wayback Machine](https://web.archive.org/) (puede tardar hasta un minuto; se carga después) |
| Copyright más antiguo, año de fundación, última modificación | La propia página |


**Estimación de creación del sitio:** el sitio no pudo crearse antes de registrar el dominio, y ya existía cuando archive.org lo capturó por primera vez (o en el año del copyright más antiguo). Ejemplo: *«Creado entre noviembre de 2018 y diciembre de 2021»*. Si la evidencia es anterior al registro actual, el dominio probablemente caducó y se volvió a registrar.

Privacidad: solo se consulta al pulsar el botón, y solo se envían el dominio y su IP. Los resultados se guardan 6 horas en memoria de la sesión.

Limitaciones: algunas extensiones de país (`.mx`, `.es`…) no publican RDAP; la geolocalización de una IP es aproximada (cada base de datos puede dar otra ciudad); no se ofrece historial de IPs ni de hosting porque solo existe en servicios de pago.

## Añadir una tecnología

Edita `data/technologies.json`. Los patrones usan el formato de Wappalyzer: `"regex\\;version:\\1\\;confidence:50"`. Un patrón vacío `""` significa «basta con que exista».

```
"MiFramework": {
  "cats": [3],
  "website": "https://ejemplo.com",
  "js": { "MiFramework.version": "^(.+)$\\;version:\\1" },
  "scripts": ["miframework(?:\\.min)?\\.js"],
  "headers": { "x-powered-by": "^MiFramework" },
  "cookies": { "mf_session": "", "mf_pref_*": "" },
  "implies": ["Node.js"]
}
```

- Las claves de `headers` y `meta` van en minúsculas.

- En `cookies`, un `*` final indica un prefijo.

- En `js`, `nombre*` (sin puntos) busca cualquier variable global que empiece así.

- Cada coincidencia suma su `confidence` (100 por defecto) hasta un máximo de 100.

- `noVersionNote`: aclaración que aparece en el popup (ℹ) cuando no se detecta la versión, p. ej. «Django no envía su versión…».

- `versionNote` + `versionLabels`: aclaración cuando sí hay versión. `{version}` es la versión detectada y `{label}` su nombre según `versionLabels`, cuyas claves son prefijos. Así, `"1.8": "Java 8"` convierte `1.8.0_181` en «1.8.0\_181 corresponde a Java 8», y la cabecera `X-AspNet-Version: 4.0.30319` se aclara como el motor de .NET Framework 4.x (no la versión de ASP.NET).

## Logos de las tecnologías

Cada tecnología indica su icono con el campo `"icon"` de `data/technologies.json`:

| Valor | Origen | Licencia |
| - | - | - |
| `"react"` | [Simple Icons](https://simpleicons.org/), en el color de la marca | CC0 |
| `"logos:magento"` | [gilbarbara/logos](https://github.com/gilbarbara/logos), a color | CC0 |
| `"devicon:carbon"` | [devicon](https://devicon.dev/) | MIT |
| `"lucide:server"` | [Lucide](https://lucide.dev/): **icono de referencia** (fondo lila) cuando no hay logo oficial | ISC |


Para añadir o actualizar iconos, pon el `"icon"` y regenera (los comandos de descarga están en `tools/build-icons.py`):

```
python3 -I tools/build-icons.py si/package logos/package devicon/package lucide/package
```

Para revisar todos los iconos de un vistazo: `python3 -m http.server 8000` y abre `http://localhost:8000/test/icons.html`.

Los logos son marcas registradas de sus respectivos dueños.

## Pruebas

```
python3 -m http.server 8000
# abre http://localhost:8000/test/engine-test.html
```

## Limitaciones

- No se pueden inspeccionar páginas internas del navegador (`chrome://`, Chrome Web Store).

- Si la pestaña ya estaba abierta antes de instalar la extensión, las cabeceras se obtienen volviendo a pedir la página.

- En aplicaciones de una sola página (SPA), pulsa ↻ tras navegar para volver a analizar.

- Firefox requiere ajustar `background` en el manifest (`"scripts"` en lugar de `"service_worker"`).

