// Detector de listas HLS dentro de la página (mundo MAIN, desde el inicio de la carga y en todos los
// marcos). Muchos reproductores (hls.js, Video.js, JW Player…) ponen en el <video> una dirección
// blob: (MediaSource) y piden la lista .m3u8 por fetch o XMLHttpRequest, a veces con otro nombre
// (.txt, .png, sin extensión) o creada en memoria como blob:. Aquí se mira el comienzo de cada
// respuesta pequeña: si empieza por #EXTM3U es una lista HLS y se avisa a float.js (mundo aislado),
// que la pasa a la extensión. No cambia las respuestas ni las peticiones.
(() => {
  if (window.__belerofonteSniff) return;
  Object.defineProperty(window, '__belerofonteSniff', { value: true });

  const EVENT = 'belerofonte-media-found';
  const MAX_TEXT = 4 * 1024 * 1024; // las listas son texto pequeño; no se leen respuestas grandes
  const SKIP_TYPE = /^(video|audio|image|font)\/|mp2t|octet-stream.*segment|application\/(wasm|javascript)/i;
  const SEGMENT = /\.(ts|m4s|m4v|m4a|mp4|aac|cmfv|cmfa|key|js|css|woff2?|png|jpe?g|gif|webp|svg)(?:$|[?#])/i;
  const seen = new Set();

  function report(url, text, kind = 'hls') {
    const key = url.startsWith('blob:') || url.startsWith('data:') ? `${url}|${text.length}` : url;
    if (seen.has(key)) return;
    seen.add(key);
    const detail = { url, page: location.href, kind };
    // Una lista creada en memoria no se puede volver a pedir: se envía su contenido.
    if (!/^https?:/i.test(url)) detail.text = text.slice(0, MAX_TEXT);
    document.dispatchEvent(new CustomEvent(EVENT, { detail: JSON.stringify(detail) }));
  }

  const looksLikePlaylist = (text) => typeof text === 'string' && text.trimStart().startsWith('#EXTM3U');
  // Manifiesto DASH: XML con la etiqueta <MPD (a veces con prefijo de espacio de nombres).
  const looksLikeMpd = (text) => typeof text === 'string' && /^\s*(<\?xml[^>]*>\s*)?(<!--[\s\S]*?-->\s*)*<([\w-]+:)?MPD[\s>]/.test(text.slice(0, 4000));
  function check(url, text) {
    if (looksLikePlaylist(text)) report(url, text, 'hls');
    else if (looksLikeMpd(text)) report(url, text, 'dash');
  }

  // Servidores que nunca sirven listas HLS útiles y sí mucho video (YouTube lo baja yt-dlp).
  const SKIP_HOST = /^https?:\/\/([^/]+\.)?(googlevideo\.com|youtube\.com|ytimg\.com|doubleclick\.net|googlesyndication\.com)\//i;

  function worthReading(url, type, length) {
    if (SKIP_HOST.test(url)) return false;
    if (/mpegurl|dash\+xml/i.test(type) || /\.(m3u8?|mpd)(?:$|[?#])/i.test(url)) return true;
    if (SKIP_TYPE.test(type)) return false;
    if (length > MAX_TEXT) return false;
    // Segmentos con su extensión habitual: no merece la pena mirarlos (salvo .png/.jpg sin tipo de imagen).
    return !SEGMENT.test(url) || /\.(png|jpe?g|gif|webp)(?:$|[?#])/i.test(url);
  }

  // --- fetch ---
  const originalFetch = window.fetch;
  if (originalFetch) {
    window.fetch = function (...args) {
      const promise = originalFetch.apply(this, args);
      promise.then((response) => {
        try {
          const type = response.headers.get('content-type') || '';
          const length = Number(response.headers.get('content-length')) || 0;
          if (!response.ok || !worthReading(response.url, type, length)) return;
          response.clone().text().then((text) => check(response.url, text), () => {});
        } catch { /* nunca molestar a la página */ }
      }, () => {});
      return promise;
    };
  }

  // --- XMLHttpRequest ---
  const XHR = window.XMLHttpRequest?.prototype;
  if (XHR) {
    const open = XHR.open;
    XHR.open = function (method, url, ...rest) {
      try {
        this.__belerofonteUrl = new URL(url, location.href).href;
      } catch { /* dirección rara */ }
      return open.call(this, method, url, ...rest);
    };
    const send = XHR.send;
    XHR.send = function (...args) {
      this.addEventListener('load', () => {
        try {
          const url = this.responseURL || this.__belerofonteUrl || '';
          const type = this.getResponseHeader('content-type') || '';
          if (this.status >= 400 || !worthReading(url, type, 0)) return;
          let text = '';
          if (this.responseType === '' || this.responseType === 'text') text = this.responseText;
          else if (this.responseType === 'document' && this.responseXML?.documentElement?.localName === 'MPD') {
            text = new XMLSerializer().serializeToString(this.responseXML);
          } else if (this.responseType === 'arraybuffer' && this.response && this.response.byteLength < MAX_TEXT) {
            const head = String.fromCharCode(...new Uint8Array(this.response, 0, Math.min(64, this.response.byteLength)));
            if (head.startsWith('#EXTM3U') || head.trimStart().startsWith('<')) text = new TextDecoder().decode(this.response);
          }
          check(url, text);
        } catch { /* nunca molestar a la página */ }
      });
      return send.apply(this, args);
    };
  }

  // --- Listas creadas en memoria: URL.createObjectURL(new Blob(['#EXTM3U…'])) ---
  const createObjectURL = URL.createObjectURL;
  URL.createObjectURL = function (object, ...rest) {
    const url = createObjectURL.call(this, object, ...rest);
    try {
      if (object instanceof Blob && object.size < MAX_TEXT && !SKIP_TYPE.test(object.type)) {
        object.slice(0, 64).text().then((head) => {
          if (head.startsWith('#EXTM3U') || head.trimStart().startsWith('<')) object.text().then((text) => check(url, text), () => {});
        }, () => {});
      }
    } catch { /* nunca molestar a la página */ }
    return url;
  };
})();
