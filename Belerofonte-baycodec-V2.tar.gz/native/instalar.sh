#!/usr/bin/env bash
# Registra el conector nativo de Belerofonte-Baycodec (descargas con yt-dlp) para los navegadores
# basados en Chromium del usuario. Solo hace falta ejecutarlo una vez (y otra si mueves la carpeta).
#
# Uso:
#   ./native/instalar.sh                 instala para Chrome, Chromium, Brave, Edge y Vivaldi
#   ./native/instalar.sh --desinstalar   quita el registro
# Opciones:
#   --id ID          ID de la extensión (por defecto se calcula a partir de la ruta de la carpeta)
#   --python RUTA    Python con yt-dlp que usará el conector
#   --dir CARPETA    instala además en otra carpeta NativeMessagingHosts (p. ej. un perfil de pruebas)

set -euo pipefail

NAME="com.baycodec.belerofonte_ytdlp"
NATIVE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EXT_DIR="$(dirname "$NATIVE_DIR")"
HOST_SCRIPT="$NATIVE_DIR/belerofonte_ytdlp.py"
WRAPPER="$NATIVE_DIR/host.sh"

EXT_ID=""
PYTHON=""
EXTRA_DIRS=()
UNINSTALL=0
while [[ $# -gt 0 ]]; do
  case "$1" in
    --id) EXT_ID="$2"; shift 2 ;;
    --python) PYTHON="$2"; shift 2 ;;
    --dir) EXTRA_DIRS+=("$2"); shift 2 ;;
    --desinstalar) UNINSTALL=1; shift ;;
    -h|--help) sed -n '2,13p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "Opción desconocida: $1" >&2; exit 1 ;;
  esac
done

# Carpetas NativeMessagingHosts de cada navegador (solo las de los navegadores instalados).
TARGETS=()
for browser in google-chrome google-chrome-beta google-chrome-unstable chromium \
               BraveSoftware/Brave-Browser microsoft-edge vivaldi; do
  [[ -d "$HOME/.config/$browser" ]] && TARGETS+=("$HOME/.config/$browser/NativeMessagingHosts")
done
TARGETS+=("${EXTRA_DIRS[@]}")

if [[ $UNINSTALL -eq 1 ]]; then
  for dir in "${TARGETS[@]}"; do
    rm -f "$dir/$NAME.json" && echo "Quitado: $dir/$NAME.json"
  done
  rm -f "$WRAPPER"
  exit 0
fi

# El ID de una extensión cargada como «descomprimida» es el SHA-256 de su ruta absoluta:
# los 32 primeros dígitos hexadecimales, cambiando 0-9a-f por a-p.
if [[ -z "$EXT_ID" ]]; then
  EXT_ID="$(printf '%s' "$EXT_DIR" | sha256sum | cut -c1-32 | tr '0-9a-f' 'a-p')"
fi

has_ytdlp() { [[ -x "$1" ]] && "$1" -I -c 'import yt_dlp' 2>/dev/null; }

if [[ -z "$PYTHON" ]]; then
  for candidate in \
      "$EXT_DIR/../descargar-videos-youtube/venv/bin/python" \
      "$NATIVE_DIR/venv/bin/python" \
      "$(command -v python3 || true)"; do
    if has_ytdlp "$candidate"; then PYTHON="$(realpath "$candidate")"; break; fi
  done
fi
if [[ -z "$PYTHON" ]]; then
  echo "No se encontró un Python con yt-dlp: se crea un entorno en $NATIVE_DIR/venv…"
  python3 -m venv "$NATIVE_DIR/venv"
  "$NATIVE_DIR/venv/bin/pip" install --quiet --upgrade yt-dlp
  PYTHON="$NATIVE_DIR/venv/bin/python"
fi
has_ytdlp "$PYTHON" || { echo "El Python indicado no tiene yt-dlp: $PYTHON" >&2; exit 1; }

# YouTube exige resolver un reto en JavaScript: sin yt-dlp-ejs y un entorno de JS (Deno) las
# descargas fallan con "HTTP Error 403: Forbidden".
if ! "$PYTHON" -I -c 'import yt_dlp_ejs' 2>/dev/null; then
  echo "Instalando yt-dlp-ejs (scripts para el reto de YouTube)…"
  "$PYTHON" -I -m pip install --quiet --upgrade "yt-dlp[default]"
fi

# TikTok bloquea a yt-dlp ("Your IP address is blocked") salvo que imite a un navegador con curl_cffi.
if ! "$PYTHON" -I -c 'import curl_cffi' 2>/dev/null; then
  echo "Instalando curl_cffi (necesario para TikTok)…"
  "$PYTHON" -I -m pip install --quiet --upgrade "yt-dlp[default,curl-cffi]"
fi

find_js() {
  for exe in "$(command -v deno || true)" "$HOME/.deno/bin/deno" "$(command -v node || true)" "$(command -v bun || true)"; do
    [[ -n "$exe" && -x "$exe" ]] && { echo "$exe"; return 0; }
  done
  return 1
}
if ! JS="$(find_js)"; then
  echo "Instalando Deno en ~/.deno/bin (necesario para YouTube)…"
  case "$(uname -m)" in
    x86_64) TRIPLE="x86_64-unknown-linux-gnu" ;;
    aarch64|arm64) TRIPLE="aarch64-unknown-linux-gnu" ;;
    *) echo "Arquitectura no compatible con Deno: $(uname -m). Instala Deno o Node a mano." >&2; exit 1 ;;
  esac
  TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
  URL="https://github.com/denoland/deno/releases/latest/download/deno-$TRIPLE.zip"
  curl -fsSL -o "$TMP/deno.zip" "$URL"
  curl -fsSL -o "$TMP/deno.zip.sha256sum" "$URL.sha256sum"
  WANT="$(grep -oE '[0-9a-fA-F]{64}' "$TMP/deno.zip.sha256sum" | head -1 | tr 'A-F' 'a-f')"
  GOT="$(sha256sum "$TMP/deno.zip" | cut -d' ' -f1)"
  [[ -n "$WANT" && "$WANT" == "$GOT" ]] || { echo "La suma SHA-256 de Deno no coincide: no se instala." >&2; exit 1; }
  mkdir -p "$HOME/.deno/bin"
  python3 -I -c 'import os, sys, zipfile
z = zipfile.ZipFile(sys.argv[1]); z.extract("deno", sys.argv[2]); os.chmod(os.path.join(sys.argv[2], "deno"), 0o755)' \
    "$TMP/deno.zip" "$HOME/.deno/bin"
  JS="$HOME/.deno/bin/deno"
fi

cat > "$WRAPPER" <<EOF
#!/bin/sh
# Generado por instalar.sh: arranca el conector con el Python que tiene yt-dlp.
exec "$PYTHON" -I "$HOST_SCRIPT" "\$@"
EOF
chmod +x "$WRAPPER" "$HOST_SCRIPT"

MANIFEST="$(cat <<EOF
{
  "name": "$NAME",
  "description": "Belerofonte-Baycodec: descargas con yt-dlp",
  "path": "$WRAPPER",
  "type": "stdio",
  "allowed_origins": ["chrome-extension://$EXT_ID/"]
}
EOF
)"

if [[ ${#TARGETS[@]} -eq 0 ]]; then
  echo "No se encontró ningún navegador basado en Chromium en ~/.config." >&2
  exit 1
fi
for dir in "${TARGETS[@]}"; do
  mkdir -p "$dir"
  printf '%s\n' "$MANIFEST" > "$dir/$NAME.json"
  echo "Registrado: $dir/$NAME.json"
done

echo
echo "ID de la extensión: $EXT_ID"
echo "  (compruébalo en chrome://extensions; si no coincide: ./native/instalar.sh --id <ID>)"
echo "Python con yt-dlp:  $PYTHON ($("$PYTHON" -I -c 'import yt_dlp; print(yt_dlp.version.__version__)'))"
echo "JavaScript:         $JS ($("$JS" --version 2>/dev/null | head -1))"
command -v ffmpeg >/dev/null || echo "Aviso: falta ffmpeg (necesario para unir video+audio y para MP3)."
echo "Listo. Recarga la extensión en chrome://extensions."
