// Videos de la pestaña: detecta archivos (mp4, webm…) y listas HLS (.m3u8) que carga la página,
// clasifica las listas y lanza la descarga. No descarga contenido cifrado ni con DRM.

import { fetchPlaylist } from './video/hls.js';
import { okruId, okruVideo, pickQuality, safeFileName } from './okru.js';

const FILE_EXT = /\.(mp4|m4v|webm|mov|mkv|ogv|mp3|m4a|ogg|oga|wav|flac)(?:$|[?#])/i;
const HLS_EXT = /\.m3u8(?:$|[?#])/i;
const HLS_TYPE = /mpegurl/i;
const MEDIA_TYPE = /^(video|audio)\//i;
// Segmentos sueltos de un stream: no se listan (se descargan a través de su lista).
const SEGMENT_EXT = /\.(ts|m4s|m4f|cmfv|cmfa|aac)(?:$|[?#])/i;
// Trozos de una pista DASH pedidos por rango en la URL (Instagram, Facebook): video y audio van por
// separado, así que descargarlos da un archivo sin sonido o incompleto.
const RANGE_SEGMENT = /[?&]bytestart=\d/i;
const MAX_PER_TAB = 40;
// YouTube no se descarga desde la red de la pestaña (sus streams van troceados y protegidos): se
// descarga con yt-dlp a través del conector nativo (native/). Ver video/video.js. Vimeo también usa
// yt-dlp, pero sus listas HLS (vimeocdn.com) sí se listan: si Vimeo bloquea a yt-dlp, el video que se
// reproduce en el navegador se puede bajar desde ahí (salvo que tenga DRM, que se marca como Protegido).
const BLOCKED_HOSTS = /(^|\.)(youtube\.com|youtube-nocookie\.com|youtu\.be|googlevideo\.com)$/i;
const YOUTUBE_HOSTS = /(^|\.)(youtube\.com|youtu\.be)$/i;

const isYouTube = (url) => {
  try {
    return YOUTUBE_HOSTS.test(new URL(url).hostname);
  } catch {
    return false;
  }
};

// Enlace de un video de Vimeo → el del reproductor (player.vimeo.com/video/ID), que yt-dlp puede leer
// sin iniciar sesión (con vimeo.com/ID pide una cuenta). Los videos ocultos llevan un hash (?h=…).
//   vimeo.com/123 · vimeo.com/123/abc · vimeo.com/channels/x/123 · player.vimeo.com/video/123?h=abc
export function vimeoPlayerUrl(url) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return null;
  }
  if (!/(^|\.)vimeo\.com$/i.test(parsed.hostname)) return null;
  const match = parsed.pathname.match(/(?:^|\/)(\d{5,})(?:\/([0-9a-f]{6,}))?\/?$/i);
  if (!match) return null;
  const hash = parsed.searchParams.get('h') || match[2];
  return `https://player.vimeo.com/video/${match[1]}${hash ? `?h=${hash}` : ''}`;
}

// Enlace de un video de TikTok → el que entiende yt-dlp. Los cortos (vm.tiktok.com/…, /t/…) se pasan
// tal cual (yt-dlp sigue la redirección); los del reproductor insertado (/embed/v2/ID, /player/v1/ID)
// no los admite, así que se cambian por /@/video/ID.
//   tiktok.com/@usuario/video/123 · vm.tiktok.com/ZMabc/ · tiktok.com/t/ZTabc/ · tiktok.com/embed/v2/123
export function tiktokUrl(url) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return null;
  }
  if (!/(^|\.)tiktok\.com$/i.test(parsed.hostname)) return null;
  if (/^(vm|vt)\./i.test(parsed.hostname) || /^\/t\/\w+/.test(parsed.pathname)) return parsed.href;
  if (/^\/@[^/]*\/video\/\d+/.test(parsed.pathname)) return `https://www.tiktok.com${parsed.pathname}`;
  const id = parsed.pathname.match(/^\/(?:embed(?:\/v\d)?|player\/v\d|v)\/(\d{10,})/)?.[1];
  return id ? `https://www.tiktok.com/@/video/${id}` : null;
}

// Enlace de una publicación de Instagram → su forma canónica. Las historias (que exigen sesión) se
// pasan tal cual. La mayoría de reels solo se leen con la sesión iniciada: video/video.js envía a
// yt-dlp las cookies de instagram.com.
//   instagram.com/reel/CODE · /reels/CODE · /p/CODE · /usuario/p/CODE · /tv/CODE · /p/CODE/embed
export function instagramUrl(url) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return null;
  }
  if (!/(^|\.)instagram\.com$/i.test(parsed.hostname)) return null;
  if (/^\/stories\/[\w.]+\/\d+/.test(parsed.pathname)) return `https://www.instagram.com${parsed.pathname}`;
  const match = parsed.pathname.match(/^\/(?:[\w.]+\/)?(p|reels?|tv)\/([\w-]{5,})/);
  if (!match) return null;
  return `https://www.instagram.com/${match[1] === 'reels' ? 'reel' : match[1]}/${match[2]}/`;
}

// Enlace de un video de Facebook → con www.facebook.com (m., web. y mbasic. son la misma web). Los
// videos privados o de grupos exigen sesión: video/video.js envía a yt-dlp las cookies de facebook.com.
//   /reel/ID · /watch/?v=ID · /usuario/videos/ID · /video.php?v=ID · /groups/…/posts/ID ·
//   /usuario/posts/ID · /story.php · /permalink.php · /plugins/video.php?href=…
// Los de compartir (/share/v/…, /share/r/…, fb.watch/…) yt-dlp no los entiende: se siguen antes (shareTarget).
const FACEBOOK_PATH = /^\/(?:reel\/\d|watch\/?(?:live\/?)?$|video\.php$|story\.php$|permalink\.php$|plugins\/video\.php$|groups\/[^/]+\/(?:posts|permalink)\/|[\w.-]+\/(?:videos|posts)\/)/;
const FACEBOOK_SHARE = /^\/share\/[vrp]\/\w+/;

export function facebookUrl(url) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return null;
  }
  if (/^fb\.watch$/i.test(parsed.hostname)) return parsed.pathname.length > 1 ? parsed.href : null;
  if (!/(^|\.)facebook\.com$/i.test(parsed.hostname)) return null;
  if (!FACEBOOK_PATH.test(parsed.pathname) && !FACEBOOK_SHARE.test(parsed.pathname)) return null;
  if (/^\/(?:watch|video\.php$)/.test(parsed.pathname) && !parsed.searchParams.get('v')) return null;
  parsed.hostname = 'www.facebook.com';
  return parsed.href;
}

const isFacebookShare = (url) => {
  try {
    const { hostname, pathname } = new URL(url);
    return /^fb\.watch$/i.test(hostname) || FACEBOOK_SHARE.test(pathname);
  } catch {
    return false;
  }
};

// Sigue un enlace de compartir de Facebook hasta el video (con tu sesión, por si es de un grupo o
// privado). Si no se puede, se devuelve el original y yt-dlp lo intenta igualmente.
async function shareTarget(url) {
  try {
    const response = await fetch(url, { credentials: 'include', redirect: 'follow' });
    response.body?.cancel();
    const target = facebookUrl(response.url);
    return target && !isFacebookShare(target) ? target : url;
  } catch {
    return url;
  }
}

// ¿Lo descarga yt-dlp? Devuelve el nombre del sitio o null.
const ytdlpSite = (url) =>
  isYouTube(url) ? 'YouTube'
    : vimeoPlayerUrl(url) ? 'Vimeo'
      : tiktokUrl(url) ? 'TikTok'
        : instagramUrl(url) ? 'Instagram'
          : facebookUrl(url) ? 'Facebook'
            : null;
const ytdlpUrl = (url, site) =>
  ({ Vimeo: vimeoPlayerUrl, TikTok: tiktokUrl, Instagram: instagramUrl, Facebook: facebookUrl })[site]?.(url) || url;

const mediaKey = (tabId) => `media:${tabId}`;
const byTab = new Map(); // tabId -> Map(url -> entrada)
const classifying = new Map(); // url -> promesa

const isBlocked = (url) => {
  try {
    return BLOCKED_HOSTS.test(new URL(url).hostname);
  } catch {
    return false;
  }
};

async function tabMedia(tabId) {
  if (!byTab.has(tabId)) {
    const stored = (await chrome.storage.session.get(mediaKey(tabId)))[mediaKey(tabId)] || [];
    byTab.set(tabId, new Map(stored.map((m) => [m.url, m])));
  }
  return byTab.get(tabId);
}

const persist = (tabId) => chrome.storage.session.set({ [mediaKey(tabId)]: [...byTab.get(tabId).values()] });

const header = (headers = [], name) => headers.find((h) => h.name.toLowerCase() === name)?.value || '';

function fileName(url) {
  try {
    const parts = new URL(url).pathname.split('/').filter(Boolean).map(decodeURIComponent);
    const last = parts.pop() || 'video';
    // Nombres genéricos de listas ("index.m3u8", "playlist.m3u8"…): se añade la carpeta para distinguirlas.
    if (/^(index|playlist|master|chunklist|prog_index|manifest|stream)\b.*\.m3u8$/i.test(last) && parts.length) {
      return `${parts.pop()}/${last}`;
    }
    return last;
  } catch {
    return 'video';
  }
}

// Tamaño total: en respuestas parciales (206) viene en Content-Range ("bytes 0-1023/52428800").
function totalSize(headers, statusCode) {
  const range = header(headers, 'content-range').match(/\/(\d+)$/);
  if (range) return Number(range[1]);
  const length = Number(header(headers, 'content-length'));
  return statusCode === 200 && length ? length : null;
}

async function classify(entry) {
  try {
    const playlist = await fetchPlaylist(entry.url);
    if (playlist.type === 'master') {
      const audioUris = playlist.renditions.map((r) => r.uri).filter(Boolean);
      entry.info = {
        playlist: 'master',
        qualities: playlist.variants.length,
        maxHeight: Math.max(0, ...playlist.variants.map((v) => v.height || 0)) || null,
        children: [...playlist.variants.map((v) => v.uri), ...audioUris],
      };
      // Para saber si está cifrado hay que mirar una de sus listas de medios.
      const first = playlist.variants[0];
      if (first) {
        const media = await fetchPlaylist(first.uri);
        Object.assign(entry.info, { encryption: media.encryption, live: media.live, duration: media.duration });
      }
    } else {
      entry.info = { playlist: 'media', encryption: playlist.encryption, live: playlist.live, duration: playlist.duration };
    }
  } catch (err) {
    entry.info = { error: err.message };
  }
}

async function addMedia(tabId, entry) {
  const list = await tabMedia(tabId);
  const existing = list.get(entry.url);
  if (existing) {
    if (!existing.size && entry.size) existing.size = entry.size;
    return;
  }
  if (list.size >= MAX_PER_TAB) list.delete(list.keys().next().value);
  list.set(entry.url, entry);
  if (entry.kind === 'hls') {
    const job = classify(entry).then(() => persist(tabId));
    classifying.set(entry.url, job);
    job.finally(() => classifying.delete(entry.url));
  }
  persist(tabId);
}

// --- Detección ------------------------------------------------------------------------

chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    if (details.tabId < 0 || details.statusCode >= 400) return;
    if (details.initiator?.startsWith('chrome-extension://')) return; // peticiones de la propia extensión
    const { url } = details;
    if (!/^https?:/i.test(url) || isBlocked(url) || SEGMENT_EXT.test(url) || RANGE_SEGMENT.test(url)) return;
    const type = header(details.responseHeaders, 'content-type');

    if (HLS_EXT.test(url) || HLS_TYPE.test(type)) {
      addMedia(details.tabId, { url, kind: 'hls', name: fileName(url), detectedAt: Date.now() });
    } else if (FILE_EXT.test(url) || MEDIA_TYPE.test(type)) {
      if (/mp2t|iso.segment/i.test(type)) return;
      addMedia(details.tabId, {
        url,
        kind: 'file',
        name: fileName(url),
        type: type.split(';')[0] || null,
        size: totalSize(details.responseHeaders, details.statusCode),
        detectedAt: Date.now(),
      });
    }
  },
  { urls: ['<all_urls>'], types: ['media', 'xmlhttprequest', 'other', 'object'] },
  ['responseHeaders'],
);

// Al cargar otra página en la pestaña se vacía la lista.
chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    if (details.tabId < 0) return;
    byTab.set(details.tabId, new Map());
    chrome.storage.session.remove(mediaKey(details.tabId));
  },
  { urls: ['<all_urls>'], types: ['main_frame'] },
);

chrome.tabs.onRemoved.addListener((tabId) => {
  byTab.delete(tabId);
  chrome.storage.session.remove(mediaKey(tabId));
});

// Videos que ya estaban en caché y no pasaron por la red: se buscan en el DOM. También los
// reproductores de Vimeo insertados (<iframe src="player.vimeo.com/video/…">), que baja yt-dlp.
function findVideoElements() {
  const urls = [];
  for (const node of document.querySelectorAll('video, video source, audio, audio source')) {
    for (const url of [node.currentSrc, node.src]) if (url && /^https?:/i.test(url)) urls.push(url);
  }
  for (const frame of document.querySelectorAll('iframe[src*="player.vimeo.com/video/"], iframe[src*="ok.ru/videoembed/"], iframe[src*="tiktok.com/"]')) {
    urls.push(frame.src);
  }
  // TikTok insertado con su código oficial: <blockquote class="tiktok-embed" cite="…/video/ID">.
  for (const quote of document.querySelectorAll('blockquote.tiktok-embed[cite]')) urls.push(quote.cite);
  // Instagram insertado: <iframe src="…/p/CODE/embed"> o <blockquote class="instagram-media" data-instgrm-permalink>.
  for (const frame of document.querySelectorAll('iframe[src*="instagram.com/"]')) urls.push(frame.src);
  // Facebook insertado: <iframe src="facebook.com/plugins/video.php?href=…"> o <div class="fb-video" data-href>.
  for (const frame of document.querySelectorAll('iframe[src*="facebook.com/plugins/video.php"]')) urls.push(frame.src);
  for (const div of document.querySelectorAll('.fb-video[data-href]')) urls.push(div.dataset.href);
  for (const quote of document.querySelectorAll('blockquote.instagram-media[data-instgrm-permalink]')) {
    urls.push(quote.dataset.instgrmPermalink);
  }
  return [...new Set(urls)];
}

const MAX_OKRU_EMBEDS = 3;

// Un video de OK.ru → una entrada por calidad (MP4 directo); en directo, su lista HLS para grabarla.
async function okruItems(id) {
  const video = await okruVideo(id);
  if (video.live || !video.qualities.length) {
    return video.hls ? [{ url: video.hls, kind: 'hls', site: 'OK.ru', name: video.title, detectedAt: Date.now() }] : [];
  }
  return video.qualities.map((q) => ({
    url: q.url,
    kind: 'file',
    site: 'OK.ru',
    quality: q.height ? `${q.height}p` : q.name,
    name: video.title,
    filename: `${safeFileName(video.title)} [${q.height ? `${q.height}p` : q.name}].mp4`,
    detectedAt: Date.now(),
  }));
}

// --- API para el popup ----------------------------------------------------------------

export async function listMedia({ tabId }) {
  const tab = await chrome.tabs.get(tabId);
  // En la página de un video de YouTube o Vimeo se rellena el enlace para bajarlo con yt-dlp. En Vimeo
  // se listan además los streams que haya cargado el reproductor (alternativa si yt-dlp falla).
  const site = ytdlpSite(tab.url || '');
  const ytdlp = site ? { url: ytdlpUrl(tab.url, site), title: tab.title, site } : null;
  if (site === 'YouTube' || isBlocked(tab.url || '')) return { ytdlp, items: [] };
  // En la página de un video de OK.ru solo interesan sus calidades (no los anuncios ni los trozos).
  const okId = okruId(tab.url || '');
  if (okId) return { ytdlp: null, items: await okruItems(okId) };

  const extra = []; // videos de OK.ru insertados: sus enlaces caducan, así que no se guardan
  try {
    const frames = await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, func: findVideoElements });
    const okIds = new Set();
    for (const url of frames.flatMap((f) => f.result || [])) {
      const embedded = okruId(url);
      if (embedded) {
        okIds.add(embedded);
        continue;
      }
      const vimeo = vimeoPlayerUrl(url);
      if (vimeo) {
        addMedia(tabId, { url: vimeo, kind: 'ytdlp', site: 'Vimeo', name: `Vimeo ${vimeo.match(/\d+/)[0]}`, detectedAt: Date.now() });
        continue;
      }
      const tiktok = tiktokUrl(url);
      if (tiktok) {
        // En la propia web de TikTok ya se ofrece el video de la pestaña (y el feed carga muchos).
        if (site !== 'TikTok') {
          addMedia(tabId, { url: tiktok, kind: 'ytdlp', site: 'TikTok', name: `TikTok ${tiktok.match(/\d{10,}/)?.[0] || ''}`.trim(), detectedAt: Date.now() });
        }
        continue;
      }
      const instagram = instagramUrl(url);
      if (instagram) {
        if (site !== 'Instagram') {
          addMedia(tabId, { url: instagram, kind: 'ytdlp', site: 'Instagram', name: `Instagram ${instagram.split('/')[4]}`, detectedAt: Date.now() });
        }
        continue;
      }
      const facebook = facebookUrl(url);
      if (facebook) {
        if (site !== 'Facebook') {
          addMedia(tabId, { url: facebook, kind: 'ytdlp', site: 'Facebook', name: `Facebook ${facebook.match(/\d{6,}/)?.[0] || 'video'}`, detectedAt: Date.now() });
        }
        continue;
      }
      if (isBlocked(url)) continue;
      addMedia(tabId, HLS_EXT.test(url)
        ? { url, kind: 'hls', name: fileName(url), detectedAt: Date.now() }
        : { url, kind: 'file', name: fileName(url), type: null, size: null, detectedAt: Date.now() });
    }
    const found = await Promise.allSettled([...okIds].slice(0, MAX_OKRU_EMBEDS).map(okruItems));
    extra.push(...found.flatMap((r) => (r.status === 'fulfilled' ? r.value : [])));
  } catch {
    // Páginas en las que no se puede inyectar: solo cuenta lo detectado por red.
  }

  await Promise.allSettled([...classifying.values()]);
  const list = [...(await tabMedia(tabId)).values()];

  // Las listas que forman parte de una maestra ya detectada no se muestran por separado.
  const children = new Set(list.flatMap((m) => m.info?.children || []));
  const items = list.filter((m) => !children.has(m.url));
  return { ytdlp, items: [...extra, ...items] };
}

// --- Referer ----------------------------------------------------------------------------
// Muchos servidores de video (sobre todo los de enlaces con token) rechazan las peticiones que no
// llevan como Referer la página donde está el video. fetch no permite fijarlo, así que la página de
// descarga de la extensión lo recibe con una regla de declarativeNetRequest limitada a su pestaña.
// (Esas reglas no se aplican a chrome.downloads; por eso, si el navegador recibe un 403, se
// reintenta desde la página de descarga.)

// Cada pestaña de descarga tiene su propia regla, con un ID fijo y muy por encima de los que usa el
// simulador (que toma los más bajos libres): así nunca se pisan ni se borran entre sí.
const REFERER_RULE_BASE = 1_000_000;
const refererRuleId = (tabId) => REFERER_RULE_BASE + tabId;

// La página de descarga lo pide antes de empezar: sus peticiones llevarán el Referer y el Origin de
// la web del video mientras la pestaña esté abierta.
export async function prepareReferer({ referer }, sender) {
  if (!httpUrl(referer) || !sender.tab) return {};
  const id = refererRuleId(sender.tab.id);
  await chrome.declarativeNetRequest.updateSessionRules({
    removeRuleIds: [id],
    addRules: [{
      id,
      priority: 1,
      condition: { tabIds: [sender.tab.id], resourceTypes: ['xmlhttprequest', 'media', 'other'] },
      action: {
        type: 'modifyHeaders',
        requestHeaders: [
          { header: 'referer', operation: 'set', value: referer },
          { header: 'origin', operation: 'set', value: new URL(referer).origin },
        ],
      },
    }],
  });
  return {};
}

chrome.tabs.onRemoved.addListener((tabId) => {
  chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [refererRuleId(tabId)] }).catch(() => {});
});

const httpUrl = (url) => (/^https?:/i.test(url || '') ? url : null);

const INTERRUPT_REASONS = {
  SERVER_FORBIDDEN: 'el servidor rechazó la descarga (403)',
  SERVER_UNAUTHORIZED: 'el servidor pide iniciar sesión',
  SERVER_BAD_CONTENT: 'el archivo ya no existe en el servidor (404)',
  SERVER_FAILED: 'error del servidor',
  NETWORK_FAILED: 'error de red',
  NETWORK_TIMEOUT: 'el servidor tardó demasiado en responder',
};
// Errores que suelen deberse a la falta de Referer/cookies: se reintenta desde la página de descarga.
const RETRY_FROM_PAGE = new Set(['SERVER_FORBIDDEN', 'SERVER_UNAUTHORIZED', 'SERVER_BAD_CONTENT']);

// Espera a que la descarga termine, falle o lleve unos segundos en marcha.
function firstOutcome(downloadId, ms) {
  return new Promise((resolve) => {
    const done = (value) => {
      chrome.downloads.onChanged.removeListener(listener);
      clearTimeout(timer);
      resolve(value);
    };
    const check = () =>
      chrome.downloads.search({ id: downloadId }).then(([item]) => {
        if (item?.state === 'interrupted') done({ error: item.error || 'FAILED' });
        else if (item?.state === 'complete') done({ complete: true });
      });
    const listener = (delta) => {
      if (delta.id === downloadId && delta.state) check();
    };
    const timer = setTimeout(() => done({ running: true }), ms);
    chrome.downloads.onChanged.addListener(listener);
    // Puede haber fallado antes de empezar a escuchar (p. ej. un 403 inmediato).
    check();
  });
}

function openDownloadPage(tab, params) {
  const page = new URL(chrome.runtime.getURL('video/video.html'));
  for (const [key, value] of Object.entries(params)) if (value) page.searchParams.set(key, value);
  return chrome.tabs.create({ url: page.href, windowId: tab.windowId, index: tab.index + 1, openerTabId: tab.id });
}

// filename: nombre con el que guardarlo (si el enlace no lo lleva, p. ej. los de OK.ru).
async function downloadFile(tab, url, referer, filename) {
  const downloadId = await chrome.downloads.download({ url, saveAs: false, ...(filename && { filename: safeFileName(filename) }) });
  const outcome = await firstOutcome(downloadId, 5000);
  if (!outcome.error) return { downloadId };

  if (RETRY_FROM_PAGE.has(outcome.error) && referer) {
    // Se quita el intento fallido de la lista de descargas y se reintenta con el Referer de la página.
    chrome.downloads.erase({ id: downloadId }).catch(() => {});
    await openDownloadPage(tab, { url, kind: 'file', title: filename ? filename.replace(/\.\w+$/, '') : tab.title, referer });
    return { opened: 'file' };
  }
  throw new Error(`No se pudo descargar: ${INTERRUPT_REASONS[outcome.error] || outcome.error}.`);
}

// ¿Es una lista HLS? Por la extensión o, si no la tiene, por el Content-Type que devuelve el servidor.
async function isHls(url) {
  if (HLS_EXT.test(url)) return true;
  if (FILE_EXT.test(url)) return false;
  try {
    const response = await fetch(url, { method: 'HEAD', credentials: 'include' });
    return HLS_TYPE.test(response.headers.get('content-type') || '');
  } catch {
    return false;
  }
}

// kind: 'file' | 'hls' | 'ytdlp' | 'auto' (enlace pegado por el usuario).
// ytdlp: opciones para YouTube y Vimeo { calidad, soloAudio, subtitulos } (las mismas que la app Flask).
export async function downloadMedia({ tabId, url, kind, ytdlp = {}, filename }) {
  let parsed;
  try {
    parsed = new URL(url.trim());
  } catch {
    throw new Error('El enlace no es válido.');
  }
  if (!/^https?:$/.test(parsed.protocol)) throw new Error('El enlace tiene que empezar por http:// o https://.');
  url = parsed.href;

  const tab = await chrome.tabs.get(tabId);
  const referer = httpUrl(tab.url);
  const site = ytdlpSite(url);
  if (site) {
    // El título de la pestaña solo sirve si la pestaña es la del propio video.
    const onVideoPage = ytdlpSite(tab.url || '') === site;
    await openDownloadPage(tab, {
      url: isFacebookShare(url) ? await shareTarget(url) : ytdlpUrl(url, site),
      kind: 'ytdlp',
      site,
      title: onVideoPage ? tab.title : '',
      // Vimeo: muchos videos insertados solo se pueden ver desde la web que los inserta.
      referer: site === 'Vimeo' && !onVideoPage ? referer : '',
      calidad: ytdlp.calidad || 'mejor',
      audio: ytdlp.soloAudio ? '1' : '',
      subs: ytdlp.subtitulos ? '1' : '',
    });
    return { opened: 'ytdlp' };
  }
  if (isBlocked(url)) {
    throw new Error('Este enlace es un trozo interno del reproductor: pega el enlace del video (youtube.com/watch?v=… o vimeo.com/…).');
  }

  // Enlace de OK.ru pegado: se lee su reproductor y se baja el MP4 de la calidad elegida.
  const okId = okruId(url);
  if (okId) {
    const video = await okruVideo(okId);
    const quality = pickQuality(video.qualities, ytdlp.calidad);
    if (!quality) {
      await openDownloadPage(tab, { url: video.hls, title: video.title, referer: 'https://ok.ru/' });
      return { opened: 'hls' };
    }
    const label = quality.height ? `${quality.height}p` : quality.name;
    return downloadFile(tab, quality.url, 'https://ok.ru/', `${video.title} [${label}].mp4`);
  }

  if (kind === 'hls' || (kind === 'auto' && (await isHls(url)))) {
    await openDownloadPage(tab, { url, title: tab.title, referer });
    return { opened: 'hls' };
  }

  return downloadFile(tab, url, referer, filename);
}
