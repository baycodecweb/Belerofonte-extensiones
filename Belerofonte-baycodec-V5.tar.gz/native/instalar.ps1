﻿# Registra el conector nativo de Belerofonte-Baycodec (descargas con yt-dlp) en Windows, para
# Chrome, Edge, Brave, Chromium y Vivaldi. Basta con hacer doble clic en instalar.bat (una sola vez).
#
# Instala dentro de esta carpeta (native\) todo lo que haga falta, sin permisos de administrador:
#   python\  o  venv\   Python con yt-dlp, yt-dlp-ejs (reto de YouTube) y curl_cffi (TikTok)
#   ffmpeg\bin\         ffmpeg y ffprobe (unir video y audio, MP3, subtítulos)
#   deno\               Deno (YouTube lo necesita para resolver su reto en JavaScript)
#
# Uso (desde PowerShell):
#   .\instalar.ps1                  instala
#   .\instalar.ps1 -Desinstalar     quita el registro (los programas descargados se quedan en native\)
# Opciones:
#   -Id ID          ID de la extensión (por defecto se calcula a partir de la "key" de manifest.json)
#   -Python RUTA    python.exe que usará el conector como base (se crea un venv con yt-dlp)

param(
  [string]$Id = "",
  [string]$Python = "",
  [switch]$Desinstalar
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

$Name = "com.baycodec.belerofonte_ytdlp"
$NativeDir = $PSScriptRoot
$ExtDir = Split-Path -Parent $NativeDir
$HostScript = Join-Path $NativeDir "belerofonte_ytdlp.py"
$HostBat = Join-Path $NativeDir "host.bat"
$Manifest = Join-Path $NativeDir "$Name.json"

# Claves del registro donde cada navegador busca los conectores nativos.
$RegistryKeys = @(
  "HKCU:\Software\Google\Chrome\NativeMessagingHosts\$Name",
  "HKCU:\Software\Chromium\NativeMessagingHosts\$Name",
  "HKCU:\Software\Microsoft\Edge\NativeMessagingHosts\$Name",
  "HKCU:\Software\BraveSoftware\Brave-Browser\NativeMessagingHosts\$Name",
  "HKCU:\Software\Vivaldi\NativeMessagingHosts\$Name"
)

# Instalador oficial de Python (python.org), solo si no hay ningún Python 3.10 o posterior.
$PythonVersion = "3.13.9"
$PythonUrl = "https://www.python.org/ftp/python/$PythonVersion/python-$PythonVersion-amd64.exe"
$PythonSha256 = "200ddff856bbff949d2cc1be42e8807c07538abd6b6966d5113a094cf628c5c5"

# ffmpeg de yt-dlp (compilación recomendada por yt-dlp) y Deno: se comprueba su SHA-256 publicado.
$FfmpegUrl = "https://github.com/yt-dlp/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip"
$FfmpegSums = "https://github.com/yt-dlp/FFmpeg-Builds/releases/download/latest/checksums.sha256"
$DenoUrl = "https://github.com/denoland/deno/releases/latest/download/deno-x86_64-pc-windows-msvc.zip"

function Say($text) { Write-Host $text }
function Fail($text) { Write-Host ""; Write-Host "ERROR: $text" -ForegroundColor Red; exit 1 }

if ($Desinstalar) {
  foreach ($key in $RegistryKeys) {
    if (Test-Path $key) { Remove-Item -Path $key -Force; Say "Quitado: $key" }
  }
  Remove-Item -Force -ErrorAction SilentlyContinue $HostBat, $Manifest
  Say "Listo. Si quieres liberar espacio, borra también las carpetas python, venv, ffmpeg y deno de $NativeDir"
  exit 0
}

# --- Utilidades ------------------------------------------------------------------------------

# Ejecuta un programa sin que sus mensajes por stderr cuenten como error de PowerShell.
function Run([string]$exe, [string[]]$arguments) {
  $ErrorActionPreference = "Continue"
  & $exe @arguments | Out-Host
  return ($LASTEXITCODE -eq 0)
}

function Quiet([string]$exe, [string[]]$arguments) {
  $ErrorActionPreference = "Continue"
  $null = & $exe @arguments 2>&1
  return ($LASTEXITCODE -eq 0)
}

function Download([string]$url, [string]$out) {
  Say "  Descargando $url"
  $curl = Get-Command curl.exe -ErrorAction SilentlyContinue
  if ($curl) {
    if (-not (Run $curl.Source @("-fL", "--retry", "3", "--progress-bar", "-o", $out, $url))) { Fail "No se pudo descargar $url" }
  } else {
    Invoke-WebRequest -Uri $url -OutFile $out -UseBasicParsing
  }
}

function Check-Sha256([string]$file, [string]$expected) {
  $got = (Get-FileHash -Algorithm SHA256 -Path $file).Hash.ToLower()
  if ($got -ne $expected.ToLower()) { Fail "La suma SHA-256 de $(Split-Path -Leaf $file) no coincide: no se instala." }
}

# Extrae del ZIP solo los archivos indicados (más rápido que descomprimirlo entero).
function Extract-Files([string]$zipPath, [string[]]$names, [string]$dest) {
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  New-Item -ItemType Directory -Force -Path $dest | Out-Null
  $zip = [IO.Compression.ZipFile]::OpenRead($zipPath)
  try {
    $found = 0
    foreach ($entry in $zip.Entries) {
      if ($names -contains $entry.Name) {
        [IO.Compression.ZipFileExtensions]::ExtractToFile($entry, (Join-Path $dest $entry.Name), $true)
        $found++
      }
    }
    if ($found -lt $names.Count) { Fail "El archivo $(Split-Path -Leaf $zipPath) no contiene $($names -join ', ')." }
  } finally { $zip.Dispose() }
}

function Usable-Python([string]$exe) {
  if (-not $exe -or -not (Test-Path -LiteralPath $exe -PathType Leaf)) { return $false }
  if ($exe -like "*\WindowsApps\*") { return $false }  # acceso directo de Microsoft Store, no un Python real
  return (Quiet $exe @("-I", "-c", "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)"))
}

function Has-Module([string]$exe, [string]$module) {
  return (Quiet $exe @("-I", "-c", "import $module"))
}

# Pythons instalados: lanzador py, PATH y registro (PEP 514).
function Find-Pythons {
  $list = New-Object System.Collections.Generic.List[string]
  $py = Get-Command py.exe -ErrorAction SilentlyContinue
  if ($py) {
    $ErrorActionPreference = "Continue"
    $exe = (& $py.Source -3 -c "import sys; print(sys.executable)" 2>$null | Select-Object -First 1)
    if ($exe) { $list.Add($exe.Trim()) }
  }
  foreach ($cmd in @(Get-Command python.exe, python3.exe -All -ErrorAction SilentlyContinue)) { $list.Add($cmd.Source) }
  foreach ($root in @("HKCU:\Software\Python\PythonCore", "HKLM:\Software\Python\PythonCore", "HKLM:\Software\WOW6432Node\Python\PythonCore")) {
    if (-not (Test-Path $root)) { continue }
    foreach ($ver in (Get-ChildItem $root | Sort-Object { try { [version]$_.PSChildName } catch { [version]"0.0" } } -Descending)) {
      $ip = Join-Path $ver.PSPath "InstallPath"
      if (-not (Test-Path $ip)) { continue }
      $item = Get-ItemProperty $ip
      if ($item.ExecutablePath) { $list.Add($item.ExecutablePath) }
      elseif ($item."(default)") { $list.Add((Join-Path $item."(default)" "python.exe")) }
    }
  }
  return $list
}

# --- ID de la extensión --------------------------------------------------------------------------
# Es el SHA-256 de la clave pública de manifest.json: los 32 primeros dígitos hexadecimales, cambiando
# 0-9a-f por a-p. Sin "key", Chrome usa la ruta de la carpeta (en UTF-16, con la unidad en mayúscula).
function To-ExtensionId([byte[]]$data) {
  $sha = [Security.Cryptography.SHA256]::Create()
  $hash = $sha.ComputeHash($data)
  $id = ""
  foreach ($b in $hash[0..15]) { $id += [char](97 + ($b -shr 4)); $id += [char](97 + ($b -band 15)) }
  return $id
}

if (-not $Id) {
  $ext = Get-Content -Raw -Encoding UTF8 (Join-Path $ExtDir "manifest.json") | ConvertFrom-Json
  if ($ext.key) {
    $Id = To-ExtensionId ([Convert]::FromBase64String($ext.key))
  } else {
    $path = (Resolve-Path $ExtDir).ProviderPath
    if ($path -match "^[a-z]:") { $path = $path.Substring(0, 1).ToUpper() + $path.Substring(1) }
    $Id = To-ExtensionId ([Text.Encoding]::Unicode.GetBytes($path))
  }
}

Say "Instalando el conector de descargas de Belerofonte-Baycodec en $NativeDir"
Say ""

$Tmp = Join-Path ([IO.Path]::GetTempPath()) ("belerofonte-" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Force -Path $Tmp | Out-Null

try {
  # --- 1. Python con yt-dlp ---------------------------------------------------------------------
  # Si hay que instalar Python, va a native\python y yt-dlp se instala en él: así la carpeta se puede
  # mover. Con un Python ya instalado se crea un entorno aparte en native\venv.
  $Private = Join-Path $NativeDir "python\python.exe"
  $Venv = Join-Path $NativeDir "venv\Scripts\python.exe"
  $HostPython = ""

  if ($Python) {
    if (-not (Usable-Python $Python)) { Fail "El Python indicado no existe o es anterior a 3.10: $Python" }
    $HostPython = $Venv
    if (-not (Usable-Python $Venv)) {
      Say "Creando el entorno de Python en native\venv..."
      if (-not (Run $Python @("-m", "venv", "--clear", (Join-Path $NativeDir "venv")))) { Fail "No se pudo crear el entorno de Python." }
    }
  } elseif (Usable-Python $Private) {
    $HostPython = $Private
  } elseif (Usable-Python $Venv) {
    $HostPython = $Venv
  } else {
    $base = Find-Pythons | Where-Object { Usable-Python $_ } | Select-Object -First 1
    if ($base) {
      Say "Python encontrado: $base"
      Say "Creando el entorno de Python en native\venv..."
      if (-not (Run $base @("-m", "venv", "--clear", (Join-Path $NativeDir "venv")))) { Fail "No se pudo crear el entorno de Python." }
      $HostPython = $Venv
    } else {
      Say "No hay Python 3.10 o posterior: se instala Python $PythonVersion en native\python (solo para este conector)."
      $installer = Join-Path $Tmp "python-installer.exe"
      Download $PythonUrl $installer
      Check-Sha256 $installer $PythonSha256
      $sig = Get-AuthenticodeSignature -FilePath $installer
      if ($sig.Status -ne "Valid" -or $sig.SignerCertificate.Subject -notmatch "Python Software Foundation") {
        Fail "El instalador de Python no tiene una firma válida de la Python Software Foundation: no se instala."
      }
      Say "  Instalando Python (puede tardar un par de minutos)..."
      $target = Join-Path $NativeDir "python"
      $installArgs = @("/quiet", "InstallAllUsers=0", "TargetDir=`"$target`"", "Include_launcher=0", "PrependPath=0",
                "Shortcuts=0", "Include_doc=0", "Include_test=0", "Include_tcltk=0", "AssociateFiles=0", "Include_pip=1")
      $proc = Start-Process -FilePath $installer -ArgumentList $installArgs -Wait -PassThru
      if ($proc.ExitCode -ne 0) { Fail "El instalador de Python terminó con el código $($proc.ExitCode)." }
      if (Usable-Python $Private) {
        $HostPython = $Private
      } else {
        # Ya había un Python $PythonVersion para este usuario en otra carpeta: se usa ese como base.
        $base = Find-Pythons | Where-Object { Usable-Python $_ } | Select-Object -First 1
        if (-not $base) { Fail "Python se instaló pero no se encuentra python.exe." }
        if (-not (Run $base @("-m", "venv", "--clear", (Join-Path $NativeDir "venv")))) { Fail "No se pudo crear el entorno de Python." }
        $HostPython = $Venv
      }
    }
  }

  # yt-dlp[default] trae yt-dlp-ejs (reto de YouTube); curl-cffi hace falta para TikTok.
  if (-not ((Has-Module $HostPython "yt_dlp") -and (Has-Module $HostPython "yt_dlp_ejs") -and (Has-Module $HostPython "curl_cffi"))) {
    Say "Instalando yt-dlp, yt-dlp-ejs y curl_cffi..."
    if (-not (Run $HostPython @("-I", "-m", "pip", "install", "--quiet", "--disable-pip-version-check", "--no-warn-script-location", "--upgrade", "yt-dlp[default,curl-cffi]"))) {
      Fail "No se pudo instalar yt-dlp con pip (¿hay conexión a Internet?)."
    }
  }
  if (-not (Has-Module $HostPython "yt_dlp")) { Fail "yt-dlp no quedó instalado en $HostPython" }

  # --- 2. ffmpeg -------------------------------------------------------------------------------
  $FfmpegExe = Join-Path $NativeDir "ffmpeg\bin\ffmpeg.exe"
  if (-not (Test-Path $FfmpegExe)) {
    Say "Instalando ffmpeg en native\ffmpeg (une video y audio, crea los MP3)..."
    $zip = Join-Path $Tmp "ffmpeg.zip"
    $sums = Join-Path $Tmp "checksums.sha256"
    Download $FfmpegSums $sums
    $line = Get-Content $sums | Where-Object { $_ -match "^([0-9a-fA-F]{64})\s+\*?ffmpeg-master-latest-win64-gpl\.zip$" } | Select-Object -First 1
    if (-not $line) { Fail "No se encontró la suma SHA-256 de ffmpeg." }
    $want = ($line -split "\s+")[0]
    Download $FfmpegUrl $zip
    Check-Sha256 $zip $want
    Extract-Files $zip @("ffmpeg.exe", "ffprobe.exe") (Join-Path $NativeDir "ffmpeg\bin")
  }

  # --- 3. Deno (entorno de JavaScript para el reto de YouTube) ---------------------------------
  $DenoExe = Join-Path $NativeDir "deno\deno.exe"
  $Js = ""
  foreach ($candidate in @($DenoExe, (Join-Path $env:USERPROFILE ".deno\bin\deno.exe"), (Join-Path $env:ProgramFiles "nodejs\node.exe"))) {
    if (Test-Path $candidate) { $Js = $candidate; break }
  }
  if (-not $Js) {
    Say "Instalando Deno en native\deno (YouTube lo necesita para entregar los videos)..."
    $zip = Join-Path $Tmp "deno.zip"
    $sum = Join-Path $Tmp "deno.zip.sha256sum"
    Download "$DenoUrl.sha256sum" $sum
    $want = [regex]::Match((Get-Content -Raw $sum), "[0-9a-fA-F]{64}").Value
    if (-not $want) { Fail "No se encontró la suma SHA-256 de Deno." }
    Download $DenoUrl $zip
    Check-Sha256 $zip $want
    Extract-Files $zip @("deno.exe") (Join-Path $NativeDir "deno")
    $Js = $DenoExe
  }

  # --- 4. Lanzador y registro en los navegadores ----------------------------------------------
  # Rutas relativas a esta carpeta (%~dp0): siguen valiendo si mueves la carpeta y no dependen de
  # caracteres especiales en el nombre de usuario.
  $relative = $HostPython.Substring($NativeDir.TrimEnd("\").Length + 1)
  $bat = "@echo off`r`nrem Generado por instalar.ps1: arranca el conector con el Python que tiene yt-dlp.`r`n" +
         "`"%~dp0$relative`" -I `"%~dp0belerofonte_ytdlp.py`" %*`r`n"
  [IO.File]::WriteAllText($HostBat, $bat, (New-Object Text.ASCIIEncoding))

  $json = [ordered]@{
    name = $Name
    description = "Belerofonte-Baycodec: descargas con yt-dlp"
    path = "host.bat"
    type = "stdio"
    allowed_origins = @("chrome-extension://$Id/")
  } | ConvertTo-Json
  [IO.File]::WriteAllText($Manifest, $json, (New-Object Text.UTF8Encoding $false))

  foreach ($key in $RegistryKeys) {
    New-Item -Path $key -Value $Manifest -Force | Out-Null
  }
  Say "Registrado para Chrome, Edge, Brave, Chromium y Vivaldi: $Manifest"

  # --- Resumen ---------------------------------------------------------------------------------
  $ErrorActionPreference = "Continue"
  $ytdlp = (& $HostPython -I -c "import yt_dlp; print(yt_dlp.version.__version__)" 2>$null | Select-Object -First 1)
  Say ""
  Say "ID de la extensión: $Id"
  Say "  (compruébalo en chrome://extensions; si no coincide: .\instalar.ps1 -Id <ID>)"
  Say "Python con yt-dlp:  $HostPython (yt-dlp $ytdlp)"
  Say "ffmpeg:             $FfmpegExe"
  Say "JavaScript:         $Js"
  Say ""
  Write-Host "Listo. Recarga la extensión en chrome://extensions (o edge://extensions) y vuelve a descargar." -ForegroundColor Green
} finally {
  Remove-Item -Recurse -Force -ErrorAction SilentlyContinue $Tmp
}
