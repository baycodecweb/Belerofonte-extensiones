@echo off
rem Instala el conector de descargas (yt-dlp, ffmpeg, Deno) para Windows: haz doble clic aqui.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1" %*
echo.
pause
