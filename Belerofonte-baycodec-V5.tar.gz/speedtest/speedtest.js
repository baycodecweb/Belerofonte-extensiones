// Prueba de velocidad: latencia, jitter, bajada y subida contra el servidor de Cloudflare más cercano
// (speed.cloudflare.com, el mismo que usa su propia prueba). Si se abre desde una pestaña, también
// mide la latencia al sitio que estaba viendo el usuario (?site=https://ejemplo.com).
//
// - Latencia: 20 peticiones vacías. De cada una se toma requestStart → responseStart (Resource Timing)
//   y se resta el tiempo que el servidor dice haber tardado (Server-Timing cfSpeedEdge + cfSpeedWorker):
//   lo que queda es la ida y vuelta por la red. Se da la mediana; el jitter es la media de las
//   diferencias entre mediciones seguidas.
// - Bajada y subida: varias conexiones en paralelo durante ~8 s (con una sola no se llena una fibra).
//   Se descartan los primeros instantes, mientras TCP acelera, y se divide lo transferido entre el tiempo.

const CF = 'https://speed.cloudflare.com';
const PING_COUNT = 20;
const DOWN = { streams: 6, seconds: 8, chunk: 25_000_000, cap: 300_000_000 };
const UP = { streams: 4, seconds: 8, chunk: 8_000_000, cap: 100_000_000 };
const WARMUP = 1.5; // segundos que no cuentan para el resultado final
const HISTORY_KEY = 'speedHistory';

const $ = (id) => document.getElementById(id);
const statusEl = $('status');
const fill = $('progress-fill');
const progressText = $('progress-text');
const startBtn = $('start');
const stopBtn = $('stop');
const copyBtn = $('copy');

const site = (() => {
  try {
    const url = new URL(new URLSearchParams(location.search).get('site') || '');
    return /^https?:$/.test(url.protocol) ? url.origin : null;
  } catch {
    return null;
  }
})();

let controller = null;
let lastResult = null;

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const median = (list) => {
  const sorted = [...list].sort((a, b) => a - b);
  const mid = sorted.length >> 1;
  return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
};
const mbpsText = (mbps) => (mbps == null ? '—' : mbps < 10 ? mbps.toFixed(2) : mbps < 100 ? mbps.toFixed(1) : Math.round(mbps).toString());
const msText = (ms) => (ms == null ? '—' : ms < 10 ? ms.toFixed(1) : Math.round(ms).toString());

function setProgress(fraction, text) {
  fill.style.width = `${Math.max(0, Math.min(1, fraction)) * 100}%`;
  if (text != null) progressText.textContent = text;
}

function activate(card) {
  for (const id of ['card-ping', 'card-jitter', 'card-down', 'card-up']) $(id).classList.toggle('active', id === card);
}

function rate(el, [text, level]) {
  el.textContent = text;
  el.className = `card__rating rating--${level}`;
}

const pingRating = (ms) => (ms < 30 ? ['Excelente', 'good'] : ms < 60 ? ['Buena', 'good'] : ms < 100 ? ['Aceptable', 'ok'] : ['Alta', 'bad']);
const jitterRating = (ms) => (ms < 5 ? ['Muy estable', 'good'] : ms < 15 ? ['Estable', 'good'] : ms < 30 ? ['Algo inestable', 'ok'] : ['Inestable', 'bad']);
const speedRating = (mbps) => (mbps >= 100 ? ['Muy rápida', 'good'] : mbps >= 25 ? ['Rápida', 'good'] : mbps >= 10 ? ['Normal', 'ok'] : ['Lenta', 'bad']);

// --- Latencia ---------------------------------------------------------------------------------

function serverTime(entry) {
  return (entry.serverTiming || [])
    .filter((t) => t.name.startsWith('cfSpeed'))
    .reduce((sum, t) => sum + (t.duration || 0), 0);
}

// IP, país y centro de datos de Cloudflare que atiende la prueba (código IATA del aeropuerto cercano).
// IPv4 e IPv6 por separado: 1.1.1.1 solo se alcanza por IPv4 y 2606:4700:4700::1111 solo por IPv6.
// El proveedor (ISP), su ASN y la ubicación aproximada salen de ipwho.is.
async function trace(url, signal) {
  const res = await fetch(url, { cache: 'no-store', signal: AbortSignal.any([signal, AbortSignal.timeout(6000)]) });
  return Object.fromEntries((await res.text()).trim().split('\n').map((line) => line.split('=')));
}

async function connectionInfo(meta, signal) {
  const [speed, v4, v6] = await Promise.allSettled([
    trace(`${CF}/cdn-cgi/trace`, signal),
    trace('https://1.1.1.1/cdn-cgi/trace', signal),
    trace('https://[2606:4700:4700::1111]/cdn-cgi/trace', signal),
  ]);
  const value = (r) => (r.status === 'fulfilled' ? r.value : {});
  meta.colo = value(speed).colo || '';
  meta.country = value(speed).loc || value(v4).loc || '';
  meta.ipv4 = /^[\d.]+$/.test(value(v4).ip || '') ? value(v4).ip : '';
  meta.ipv6 = (value(v6).ip || '').includes(':') ? value(v6).ip : '';
  const ip = meta.ipv4 || meta.ipv6 || meta.ip || value(speed).ip;
  if (!ip) return;
  try {
    const res = await fetch(`https://ipwho.is/${encodeURIComponent(ip)}?lang=es`, {
      cache: 'no-store', signal: AbortSignal.any([signal, AbortSignal.timeout(8000)]),
    });
    const data = await res.json();
    if (data.success === false) return;
    const c = data.connection || {};
    meta.isp = c.isp || c.org || '';
    meta.org = c.org && c.org !== c.isp ? c.org : '';
    meta.ispDomain = c.domain || '';
    meta.asn = c.asn || '';
    meta.place = [data.city, data.region, data.country].filter((v, i, all) => v && all.indexOf(v) === i).join(', ');
  } catch (err) {
    if (signal.aborted) throw err;
  }
}

// Nombre corto del proveedor: «claro.com.pe» → «Claro»; si no hay dominio, el nombre de la empresa.
function ispName(meta) {
  const brand = (meta.ispDomain || '').split('.')[0];
  return brand ? brand.charAt(0).toUpperCase() + brand.slice(1) : meta.isp || '';
}

async function measureLatency(signal, meta) {
  performance.setResourceTimingBufferSize(1000);
  performance.clearResourceTimings();
  const samples = [];
  for (let i = 0; i < PING_COUNT; i++) {
    if (signal.aborted) throw new DOMException('Cancelado', 'AbortError');
    const url = `${CF}/__down?bytes=0&measId=${Math.random().toString(36).slice(2)}`;
    const started = performance.now();
    const res = await fetch(url, { cache: 'no-store', signal });
    await res.arrayBuffer();
    const wall = performance.now() - started;
    if (i === 0) meta.ip = res.headers.get('cf-meta-ip') || '';
    // La primera abre la conexión (DNS, TCP, TLS): no cuenta.
    if (i === 0) continue;
    const entry = performance.getEntriesByName(url).pop();
    let ms = wall;
    if (entry && entry.requestStart > 0 && entry.responseStart > 0) {
      ms = entry.responseStart - entry.requestStart - serverTime(entry);
    }
    samples.push(Math.max(ms, 0.1));
    const ping = median(samples);
    $('ping').textContent = msText(ping);
    setProgress(0.1 * (i / PING_COUNT), `Midiendo la latencia… ${i}/${PING_COUNT - 1}`);
  }
  const ping = median(samples);
  let jitter = 0;
  for (let i = 1; i < samples.length; i++) jitter += Math.abs(samples[i] - samples[i - 1]);
  jitter /= Math.max(samples.length - 1, 1);
  return { ping, jitter };
}

// --- Transferencia (común a bajada y subida) ----------------------------------------------------
// counter.bytes lo actualizan las conexiones; aquí se muestrea cada 200 ms para la velocidad en vivo
// (último segundo) y para el resultado final (todo lo transferido después del calentamiento).

async function runTransfer({ seconds, cap }, signal, startStreams, onLive, progressFrom, label) {
  const counter = { bytes: 0 };
  const stop = new AbortController();
  const abortAll = () => stop.abort();
  signal.addEventListener('abort', abortAll, { once: true });

  const streams = startStreams(counter, stop.signal);
  const t0 = performance.now();
  const samples = [{ t: 0, bytes: 0 }];
  try {
    while (true) {
      await sleep(200);
      if (signal.aborted) throw new DOMException('Cancelado', 'AbortError');
      const t = (performance.now() - t0) / 1000;
      samples.push({ t, bytes: counter.bytes });
      const windowStart = samples.find((s) => s.t >= t - 1) || samples[0];
      const live = t > windowStart.t ? ((counter.bytes - windowStart.bytes) * 8) / ((t - windowStart.t) * 1e6) : 0;
      onLive(live);
      setProgress(progressFrom + 0.45 * Math.min(t / seconds, 1), `${label}… ${mbpsText(live)} Mbps`);
      if (t >= seconds || counter.bytes >= cap) break;
    }
  } finally {
    stop.abort();
    signal.removeEventListener('abort', abortAll);
    await Promise.allSettled(streams);
  }
  const end = samples[samples.length - 1];
  // Si se llegó al límite de datos antes de tiempo, el calentamiento se acorta en proporción.
  const warmup = Math.min(WARMUP, end.t / 4);
  const from = samples.find((s) => s.t >= warmup) || samples[0];
  if (end.t <= from.t || end.bytes <= from.bytes) return 0;
  return ((end.bytes - from.bytes) * 8) / ((end.t - from.t) * 1e6);
}

function downloadStreams(counter, signal) {
  const one = async () => {
    while (!signal.aborted) {
      try {
        const res = await fetch(`${CF}/__down?bytes=${DOWN.chunk}&measId=${Math.random().toString(36).slice(2)}`, { cache: 'no-store', signal });
        const reader = res.body.getReader();
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          counter.bytes += value.byteLength;
        }
      } catch (err) {
        if (signal.aborted) return;
        await sleep(300); // fallo puntual de red: se reintenta mientras dure la prueba
      }
    }
  };
  return Array.from({ length: DOWN.streams }, one);
}

// Datos aleatorios (no comprimibles) reutilizados en todas las subidas.
let uploadBody = null;
function getUploadBody() {
  if (uploadBody) return uploadBody;
  const block = new Uint8Array(65536);
  crypto.getRandomValues(block);
  uploadBody = new Blob(Array.from({ length: Math.ceil(UP.chunk / block.length) }, () => block), { type: 'text/plain' });
  return uploadBody;
}

function uploadStreams(counter, signal) {
  const body = getUploadBody();
  const one = () => new Promise((resolve) => {
    const next = () => {
      if (signal.aborted) return resolve();
      const xhr = new XMLHttpRequest();
      let sent = 0;
      const onAbort = () => xhr.abort();
      signal.addEventListener('abort', onAbort, { once: true });
      xhr.upload.onprogress = (event) => {
        counter.bytes += event.loaded - sent;
        sent = event.loaded;
      };
      xhr.onloadend = () => {
        signal.removeEventListener('abort', onAbort);
        if (signal.aborted) return resolve();
        setTimeout(next, xhr.status === 200 ? 0 : 300);
      };
      xhr.open('POST', `${CF}/__up?measId=${Math.random().toString(36).slice(2)}`);
      xhr.send(body);
    };
    next();
  });
  return Array.from({ length: UP.streams }, one);
}

// --- Latencia al sitio que se estaba viendo --------------------------------------------------

async function measureSite(signal) {
  const times = [];
  for (let i = 0; i < 6; i++) {
    if (signal.aborted) throw new DOMException('Cancelado', 'AbortError');
    const started = performance.now();
    try {
      // redirect: 'manual' para medir solo la respuesta de este servidor, sin seguir redirecciones.
      await fetch(`${site}/`, { method: 'HEAD', cache: 'no-store', credentials: 'omit', redirect: 'manual', signal });
    } catch (err) {
      if (signal.aborted) throw err;
      try {
        // Sin permiso sobre el sitio (CORS): una petición «opaca» también sirve para medir el tiempo.
        await fetch(`${site}/`, { method: 'HEAD', mode: 'no-cors', cache: 'no-store', credentials: 'omit', signal });
      } catch (again) {
        if (signal.aborted) throw again;
        return null;
      }
    }
    times.push(performance.now() - started);
  }
  return { first: times[0], warm: median(times.slice(1)) };
}

// --- Resultado ------------------------------------------------------------------------------

function renderUses({ down, up, ping }) {
  const uses = [
    [down >= 25, 'Video en 4K (25 Mbps)'],
    [down >= 5, 'Video en HD 1080p (5 Mbps)'],
    [down >= 1.5, 'Música y video en calidad básica'],
    [up >= 3 && down >= 3, 'Videollamadas en HD (3 Mbps de subida y bajada)'],
    [ping < 60 && up >= 1, 'Juegos en línea (latencia menor de 60 ms)'],
    [up >= 10, 'Subir videos y archivos grandes con fluidez (10 Mbps de subida)'],
    [down >= 100, 'Varias personas en 4K a la vez y descargas grandes rápidas'],
  ];
  $('uses').replaceChildren(...uses.map(([ok, text]) => {
    const li = document.createElement('li');
    li.textContent = `${ok ? '✅' : '❌'} ${text}`;
    return li;
  }));
  $('uses-panel').hidden = false;
}

function renderConnection(meta) {
  const brand = ispName(meta);
  $('conn-isp').textContent = meta.isp
    ? `${brand}${brand !== meta.isp ? ` · ${meta.isp}` : ''}${meta.org ? ` (${meta.org})` : ''}${meta.ispDomain ? ` — ${meta.ispDomain}` : ''}`
    : 'No se pudo consultar';
  $('conn-ipv4').textContent = meta.ipv4 || 'No tienes IPv4 pública (o no responde)';
  $('conn-ipv6').textContent = meta.ipv6 || 'No tienes IPv6';
  $('conn-asn').textContent = meta.asn ? `AS${meta.asn}` : '—';
  let country = meta.country || '';
  try {
    if (country) country = new Intl.DisplayNames(['es'], { type: 'region' }).of(country);
  } catch { /* código raro: se deja tal cual */ }
  $('conn-place').textContent = meta.place || country || '—';
  $('conn-server').textContent = meta.colo ? `Cloudflare · ${meta.colo}` : 'Cloudflare';
  $('conn-panel').hidden = false;
}

async function loadHistory() {
  try {
    return (await chrome.storage.local.get(HISTORY_KEY))[HISTORY_KEY] || [];
  } catch {
    return [];
  }
}

async function saveHistory(entry) {
  const list = [entry, ...(await loadHistory())].slice(0, 10);
  try {
    await chrome.storage.local.set({ [HISTORY_KEY]: list });
  } catch { /* sin almacenamiento: solo no se guarda el historial */ }
  renderHistory(list);
}

function renderHistory(list) {
  $('history-panel').hidden = !list.length;
  $('history').replaceChildren(...list.map((r) => {
    const tr = document.createElement('tr');
    const date = new Date(r.date).toLocaleString('es', { dateStyle: 'short', timeStyle: 'short' });
    for (const text of [date, `${msText(r.ping)} ms`, `${msText(r.jitter)} ms`, `${mbpsText(r.down)} Mbps`, `${mbpsText(r.up)} Mbps`, r.isp || '—', r.ip || '—']) {
      tr.append(Object.assign(document.createElement('td'), { textContent: text }));
    }
    return tr;
  }));
}

// --- Prueba completa ------------------------------------------------------------------------

function resetCards() {
  for (const id of ['ping', 'jitter', 'down', 'up']) {
    $(id).textContent = '—';
    $(`${id}-rating`).textContent = '';
  }
  $('uses-panel').hidden = true;
}

async function run() {
  controller = new AbortController();
  const { signal } = controller;
  startBtn.hidden = true;
  stopBtn.hidden = false;
  copyBtn.hidden = true;
  resetCards();
  statusEl.textContent = 'Midiendo… no uses internet en otras pestañas mientras tanto.';
  const meta = {};

  try {
    activate('card-ping');
    $('conn-panel').hidden = false;
    const info = connectionInfo(meta, signal).then(() => renderConnection(meta));
    const { ping, jitter } = await measureLatency(signal, meta);
    $('ping').textContent = msText(ping);
    $('jitter').textContent = msText(jitter);
    rate($('ping-rating'), pingRating(ping));
    rate($('jitter-rating'), jitterRating(jitter));

    activate('card-down');
    const down = await runTransfer(DOWN, signal, downloadStreams, (v) => ($('down').textContent = mbpsText(v)), 0.1, 'Midiendo la bajada');
    $('down').textContent = mbpsText(down);
    rate($('down-rating'), speedRating(down));

    activate('card-up');
    const up = await runTransfer(UP, signal, uploadStreams, (v) => ($('up').textContent = mbpsText(v)), 0.55, 'Midiendo la subida');
    $('up').textContent = mbpsText(up);
    rate($('up-rating'), speedRating(up));
    activate(null);

    let siteResult = null;
    if (site) {
      setProgress(1, `Midiendo la latencia a ${new URL(site).host}…`);
      siteResult = await measureSite(signal);
      $('site-first').textContent = siteResult ? `${msText(siteResult.first)} ms` : 'El sitio no respondió';
      $('site-warm').textContent = siteResult ? `${msText(siteResult.warm)} ms` : '—';
    }

    await info;
    lastResult = {
      date: Date.now(), ping, jitter, down, up, colo: meta.colo,
      isp: meta.isp, ispBrand: ispName(meta), asn: meta.asn, ipv4: meta.ipv4, ipv6: meta.ipv6, place: meta.place,
      ...(siteResult && { site, siteFirst: siteResult.first, siteWarm: siteResult.warm }),
    };
    renderUses(lastResult);
    await saveHistory({ date: lastResult.date, ping, jitter, down, up, colo: meta.colo, isp: lastResult.ispBrand, ip: meta.ipv4 || meta.ipv6 || '' });
    setProgress(1, 'Prueba terminada.');
    statusEl.textContent = `⬇ ${mbpsText(down)} Mbps · ⬆ ${mbpsText(up)} Mbps · ${msText(ping)} ms${lastResult.ispBrand ? ` · ${lastResult.ispBrand}` : ''}`;
    copyBtn.hidden = false;
  } catch (err) {
    activate(null);
    if (err.name === 'AbortError') {
      setProgress(0, 'Prueba detenida.');
      statusEl.textContent = 'Prueba detenida.';
    } else {
      setProgress(0, `No se pudo completar la prueba (${err.message}). Comprueba tu conexión e inténtalo otra vez.`);
      statusEl.textContent = 'Error en la prueba.';
    }
  } finally {
    controller = null;
    stopBtn.hidden = true;
    startBtn.hidden = false;
    startBtn.textContent = '🔁 Repetir prueba';
  }
}

startBtn.addEventListener('click', run);
stopBtn.addEventListener('click', () => controller?.abort());
copyBtn.addEventListener('click', async () => {
  if (!lastResult) return;
  const lines = [
    `Velocidad de internet (${new Date(lastResult.date).toLocaleString('es')})`,
    `Bajada: ${mbpsText(lastResult.down)} Mbps`,
    `Subida: ${mbpsText(lastResult.up)} Mbps`,
    `Latencia: ${msText(lastResult.ping)} ms · jitter ${msText(lastResult.jitter)} ms`,
    ...(lastResult.site ? [`Latencia a ${new URL(lastResult.site).host}: ${msText(lastResult.siteFirst)} ms la primera, ${msText(lastResult.siteWarm)} ms después`] : []),
    ...(lastResult.isp ? [`Proveedor: ${lastResult.ispBrand !== lastResult.isp ? `${lastResult.ispBrand} (${lastResult.isp})` : lastResult.isp}${lastResult.asn ? ` · AS${lastResult.asn}` : ''}`] : []),
    ...(lastResult.ipv4 ? [`IP pública (IPv4): ${lastResult.ipv4}`] : []),
    ...(lastResult.ipv6 ? [`IP pública (IPv6): ${lastResult.ipv6}`] : []),
    ...(lastResult.place ? [`Ubicación aproximada: ${lastResult.place}`] : []),
    `Servidor: Cloudflare${lastResult.colo ? ` ${lastResult.colo}` : ''}`,
  ];
  await navigator.clipboard.writeText(lines.join('\n'));
  copyBtn.textContent = '✓ Copiado';
  setTimeout(() => (copyBtn.textContent = '⧉ Copiar resultado'), 1500);
});

if (site) {
  $('site-host').textContent = new URL(site).host;
  $('site-panel').hidden = false;
}
loadHistory().then(renderHistory);
run();
