#!/bin/sh
# Generado por instalar.sh: arranca el conector con el Python que tiene yt-dlp.
exec "/run/media/baycodec/Disco-01/Proyectos/descargar-videos-youtube/venv/bin/python" -I "/run/media/baycodec/Disco-01/Proyectos/Belerofonte-baycodec/native/belerofonte_ytdlp.py" "$@"
