#!/usr/bin/env python3
"""Conector nativo de Belerofonte-Baycodec: descarga videos de YouTube y Vimeo con yt-dlp.

Chrome lo arranca cuando la extensión llama a chrome.runtime.connectNative() y se comunica por
stdin/stdout con mensajes JSON precedidos de su longitud (4 bytes). Si la extensión cierra la
conexión (botón Cancelar o pestaña cerrada), el conector borra el archivo a medias y termina.

Mensajes que recibe:
  {"action": "info"}                                   → versión de yt-dlp, ffmpeg y carpeta
  {"action": "download", "url", "solo_audio", "calidad", "subtitulos", "referer"}
                                                       → progreso… y al final done / error
  {"action": "reveal", "path"}                         → abre la carpeta del archivo
"""

import json
import os
import shutil
import struct
import subprocess
import sys
import threading
import time

# yt-dlp y ffmpeg escriben en stdout: el stdout real se reserva para los mensajes con Chrome.
_protocol_out = sys.stdout.buffer
sys.stdout = sys.stderr
_send_lock = threading.Lock()

CALIDADES_VIDEO = {"mejor", "1080", "720", "480", "360"}
CALIDADES_AUDIO = {"320", "192", "128"}

_current_tmp = {"path": None}


def send(message: dict) -> None:
    data = json.dumps(message, ensure_ascii=False).encode("utf-8")
    with _send_lock:
        _protocol_out.write(struct.pack("=I", len(data)))
        _protocol_out.write(data)
        _protocol_out.flush()


def read_message():
    header = sys.stdin.buffer.read(4)
    if len(header) < 4:
        return None
    (length,) = struct.unpack("=I", header)
    return json.loads(sys.stdin.buffer.read(length).decode("utf-8"))


def download_dir() -> str:
    """Carpeta de descargas del usuario (p. ej. ~/Descargas en español)."""
    folder = ""
    try:
        folder = subprocess.run(
            ["xdg-user-dir", "DOWNLOAD"], capture_output=True, text=True, timeout=5
        ).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        pass
    if not folder or os.path.realpath(folder) == os.path.realpath(os.path.expanduser("~")):
        folder = os.path.expanduser("~/Downloads")
    os.makedirs(folder, exist_ok=True)
    return folder


def video_format(calidad: str) -> str:
    # Vimeo entrega el audio aparte en .mp4 (no .m4a): sin el «bestvideo+bestaudio» genérico no
    # habría ningún formato válido. ffmpeg lo une todo en un MP4 (merge_output_format).
    if calidad not in CALIDADES_VIDEO or calidad == "mejor":
        return "bestvideo[ext=mp4]+bestaudio[ext=m4a]/bestvideo+bestaudio/best[ext=mp4]/best"
    return (
        f"bestvideo[height<={calidad}][ext=mp4]+bestaudio[ext=m4a]/"
        f"bestvideo[height<={calidad}]+bestaudio/"
        f"best[height<={calidad}][ext=mp4]/best[height<={calidad}]"
    )


# YouTube exige resolver un reto en JavaScript para entregar el video; sin un entorno de JS,
# yt-dlp recibe "HTTP Error 403: Forbidden". Chrome arranca el conector con un PATH mínimo, así
# que se buscan también las rutas de instalación habituales.
JS_RUNTIME_PATHS = {
    "deno": ["~/.deno/bin/deno", "/usr/local/bin/deno", "/usr/bin/deno"],
    "node": ["/usr/local/bin/node", "/usr/bin/node", "/usr/bin/nodejs"],
    "bun": ["~/.bun/bin/bun", "/usr/local/bin/bun"],
}


def js_runtimes() -> dict:
    found = {}
    for name, candidates in JS_RUNTIME_PATHS.items():
        for path in [shutil.which(name)] + [os.path.expanduser(c) for c in candidates]:
            if path and os.access(path, os.X_OK):
                found[name] = {"path": path}
                break
    return found


class Logger:
    """Los avisos de yt-dlp van a stderr (Chrome los muestra en su registro), nunca a stdout."""

    def debug(self, msg):
        pass

    def info(self, msg):
        pass

    def warning(self, msg):
        print(msg, file=sys.stderr)

    def error(self, msg):
        print(msg, file=sys.stderr)


def info() -> dict:
    try:
        import yt_dlp

        version = yt_dlp.version.__version__
    except ImportError:
        version = None
    try:
        import yt_dlp_ejs  # noqa: F401  (scripts que resuelven el reto de YouTube)

        ejs = True
    except ImportError:
        ejs = False
    return {
        "type": "info",
        "ytdlp": version,
        "js": {name: conf["path"] for name, conf in js_runtimes().items()},
        "ejs": ejs,
        "ffmpeg": bool(shutil.which("ffmpeg")),
        "carpeta": download_dir(),
        "python": sys.executable,
    }


def download(message: dict) -> dict:
    import yt_dlp

    url = (message.get("url") or "").strip()
    solo_audio = bool(message.get("solo_audio"))
    calidad = str(message.get("calidad") or ("192" if solo_audio else "mejor"))
    subtitulos = bool(message.get("subtitulos"))
    if not url.startswith(("http://", "https://")):
        return {"type": "error", "mensaje": "El enlace no es válido."}

    last_sent = [0.0]

    def progress(state: dict) -> None:
        if state.get("tmpfilename"):
            _current_tmp["path"] = state["tmpfilename"]
        if state["status"] == "downloading":
            now = time.monotonic()
            if now - last_sent[0] < 0.4:
                return
            last_sent[0] = now
            total = state.get("total_bytes") or state.get("total_bytes_estimate")
            done = state.get("downloaded_bytes") or 0
            send({
                "type": "progress",
                "porcentaje": round(done / total * 100, 1) if total else 0,
                "velocidad": speed if "Unknown" not in (speed := (state.get("_speed_str") or "").strip()) else "",
                "descargado": done,
                "total": total,
                # Con video y audio por separado, yt-dlp baja dos archivos seguidos.
                "parte": (state.get("info_dict") or {}).get("format_id", ""),
            })
        elif state["status"] == "finished":
            send({"type": "progress", "porcentaje": 100, "mensaje": "Procesando archivo…"})

    options = {
        "outtmpl": os.path.join(download_dir(), "%(title)s [%(id)s].%(ext)s"),
        "windowsfilenames": True,
        "noplaylist": True,
        "progress_hooks": [progress],
        "logger": Logger(),
        "js_runtimes": js_runtimes() or {"deno": {}},
        "quiet": True,
        "noprogress": True,
    }
    # Videos de Vimeo insertados que solo se pueden ver desde la web que los inserta.
    referer = (message.get("referer") or "").strip()
    if referer.startswith(("http://", "https://")):
        options["http_headers"] = {"Referer": referer}
    if solo_audio:
        options.update({
            # Nombre propio: si no, yt-dlp toma el video ya descargado con el mismo nombre como
            # "ya descargado", lo convierte a MP3 y lo borra.
            "outtmpl": os.path.join(download_dir(), "%(title)s [%(id)s] - audio.%(ext)s"),
            "format": "bestaudio/best",
            "postprocessors": [{
                "key": "FFmpegExtractAudio",
                "preferredcodec": "mp3",
                "preferredquality": calidad if calidad in CALIDADES_AUDIO else "192",
            }],
        })
    else:
        options["format"] = video_format(calidad)
        options["merge_output_format"] = "mp4"
        if subtitulos:
            options.update({
                "writesubtitles": True,
                "writeautomaticsub": True,
                "subtitleslangs": ["es", "es-*", "en"],
                "postprocessors": [{"key": "FFmpegEmbedSubtitle"}],
            })

    send({"type": "progress", "porcentaje": 0, "mensaje": "Leyendo el video…"})
    try:
        with yt_dlp.YoutubeDL(options) as ydl:
            result = ydl.extract_info(url, download=True)
            downloads = result.get("requested_downloads") or []
            path = downloads[-1].get("filepath") if downloads else None
            if not path:
                path = ydl.prepare_filename(result)
            if solo_audio:
                path = os.path.splitext(path)[0] + ".mp3"
    except yt_dlp.utils.DownloadError as error:
        return {"type": "error", "mensaje": str(error).removeprefix("ERROR: ")}
    _current_tmp["path"] = None
    return {
        "type": "done",
        "archivo": os.path.basename(path),
        "ruta": path,
        "tamano": os.path.getsize(path) if os.path.exists(path) else None,
        "titulo": result.get("title"),
    }


def reveal(message: dict) -> dict:
    path = message.get("path") or ""
    folder = os.path.dirname(path) if os.path.isfile(path) else download_dir()
    subprocess.Popen(["xdg-open", folder], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return {"type": "ok"}


def handle(message: dict) -> None:
    action = message.get("action")
    try:
        if action == "info":
            send(info())
        elif action == "download":
            send(download(message))
        elif action == "reveal":
            send(reveal(message))
        else:
            send({"type": "error", "mensaje": f"Acción desconocida: {action}"})
    except ImportError:
        send({"type": "error", "mensaje": "yt-dlp no está instalado para el Python del conector. Vuelve a ejecutar native/instalar.sh."})
    except Exception as error:  # cualquier fallo se informa a la extensión en lugar de cortar la conexión
        send({"type": "error", "mensaje": f"{type(error).__name__}: {error}"})


def main() -> None:
    # Cada mensaje se atiende en un hilo; el principal solo lee. Cuando Chrome cierra la conexión
    # (stdin termina): una descarga en curso se cancela (se borra el archivo a medias); las demás
    # peticiones (info, reveal) terminan y responden antes de salir.
    workers = []
    while True:
        message = read_message()
        if message is None:
            break
        worker = threading.Thread(target=handle, args=(message,), daemon=True)
        worker.start()
        workers.append((worker, message.get("action")))

    downloading = any(w.is_alive() and action == "download" for w, action in workers)
    if not downloading:
        for worker, _ in workers:
            worker.join(timeout=15)
    tmp = _current_tmp["path"]
    if tmp and os.path.exists(tmp):
        try:
            os.remove(tmp)
        except OSError:
            pass
    os._exit(0)


if __name__ == "__main__":
    main()
