// Identificar fuente: al pasar el cursor sobre la página se resalta el elemento y se muestra la
// fuente con la que se pinta; al hacer clic, una tarjeta con familia, tamaño, peso, interlineado,
// color y el CSS listo para copiar. La interfaz va en un Shadow DOM cerrado (no le afecta el CSS
// de la página).

// --- Función que se ejecuta dentro de la página ---------------------------------------

function inspectFonts() {
  // Si ya estaba abierto (otra llamada desde el popup o el menú), se cierra el anterior.
  document.getElementById('__fontinspector')?.__close?.();

  const clean = (name) => name.trim().replace(/^["']|["']$/g, '');
  const GENERIC = new Set(['serif', 'sans-serif', 'monospace', 'cursive', 'fantasy', 'system-ui', 'ui-sans-serif',
    'ui-serif', 'ui-monospace', 'ui-rounded', 'emoji', 'math', 'fangsong']);
  const WEIGHTS = { 100: 'Thin', 200: 'ExtraLight', 300: 'Light', 400: 'Regular', 500: 'Medium', 600: 'SemiBold',
    700: 'Bold', 800: 'ExtraBold', 900: 'Black' };

  // --- Qué fuente de la pila se pinta de verdad ---
  // Se mide un texto con la fuente seguida de tres genéricas distintas: si alguna medida cambia
  // respecto a la genérica sola, la fuente está disponible (instalada o webfont ya cargada).
  const ctx = document.createElement('canvas').getContext('2d');
  const SAMPLE = 'mmmmmmmmmmlli1WQ@#';
  const FALLBACKS = ['monospace', 'serif', 'sans-serif'];
  const measure = (font) => {
    ctx.font = font;
    return ctx.measureText(SAMPLE).width;
  };
  const base = Object.fromEntries(FALLBACKS.map((g) => [g, measure(`72px ${g}`)]));
  const availability = new Map();
  const isAvailable = (family) => {
    if (!availability.has(family)) {
      const quoted = `"${family.replace(/["\\]/g, '\\$&')}"`;
      availability.set(family, FALLBACKS.some((g) => measure(`72px ${quoted}, ${g}`) !== base[g]));
    }
    return availability.get(family);
  };
  const loadedWebfonts = () => {
    const names = new Set();
    for (const face of document.fonts) if (face.status === 'loaded') names.add(clean(face.family).toLowerCase());
    return names;
  };

  function describe(el) {
    const style = getComputedStyle(el);
    const stack = style.fontFamily.split(',').map(clean).filter(Boolean);
    const webfonts = loadedWebfonts();
    let rendered = null;
    let source = '';
    for (const family of stack) {
      if (GENERIC.has(family.toLowerCase())) {
        rendered = family;
        source = 'Genérica: el navegador elige la fuente del sistema';
        break;
      }
      if (webfonts.has(family.toLowerCase())) {
        rendered = family;
        source = 'Webfont descargada por la página';
        break;
      }
      if (isAvailable(family)) {
        rendered = family;
        source = 'Instalada en tu equipo';
        break;
      }
    }
    if (!rendered) {
      rendered = stack[0] || 'desconocida';
      source = 'No disponible: se usa la fuente por defecto del navegador';
    }

    const rootSize = parseFloat(getComputedStyle(document.documentElement).fontSize) || 16;
    const size = parseFloat(style.fontSize);
    const weight = Math.round(parseFloat(style.fontWeight) / 100) * 100;
    const lineHeight = style.lineHeight === 'normal' ? 'normal'
      : `${style.lineHeight} (${(parseFloat(style.lineHeight) / size).toFixed(2).replace(/\.?0+$/, '')})`;

    return {
      rendered,
      source,
      stack: style.fontFamily,
      size: `${style.fontSize} (${+(size / rootSize).toFixed(3)}rem)`,
      weight: `${style.fontWeight}${WEIGHTS[weight] ? ` · ${WEIGHTS[weight]}` : ''}`,
      style: style.fontStyle,
      lineHeight,
      letterSpacing: style.letterSpacing,
      color: style.color,
      hex: toHex(style.color),
      css: [
        `font-family: ${style.fontFamily};`,
        `font-size: ${style.fontSize};`,
        `font-weight: ${style.fontWeight};`,
        style.fontStyle !== 'normal' ? `font-style: ${style.fontStyle};` : '',
        `line-height: ${style.lineHeight};`,
        style.letterSpacing !== 'normal' ? `letter-spacing: ${style.letterSpacing};` : '',
        `color: ${toHex(style.color) || style.color};`,
      ].filter(Boolean).join('\n'),
    };
  }

  function toHex(color) {
    const m = color.match(/^rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)(?:\s*[,/]\s*([\d.]+%?))?/);
    if (!m) return '';
    const alpha = m[4] == null ? 1 : m[4].endsWith('%') ? parseFloat(m[4]) / 100 : parseFloat(m[4]);
    const parts = [m[1], m[2], m[3]].map(Number);
    if (alpha < 1) parts.push(Math.round(alpha * 255));
    return '#' + parts.map((v) => v.toString(16).padStart(2, '0')).join('').toUpperCase();
  }

  async function copy(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      // Páginas http:// o sin foco: método clásico.
      const area = Object.assign(document.createElement('textarea'), { value: text });
      area.style.cssText = 'position:fixed;opacity:0;';
      document.body.append(area);
      area.select();
      const ok = document.execCommand('copy');
      area.remove();
      return ok;
    }
  }

  const escape = (text) => String(text).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);

  const host = document.createElement('div');
  host.id = '__fontinspector';
  const shadow = host.attachShadow({ mode: 'closed' });
  shadow.innerHTML = `
    <style>
      * { box-sizing: border-box; }
      .box { position: fixed; z-index: 2147483646; pointer-events: none; display: none;
             border: 2px solid #4f46e5; background: rgba(79,70,229,.08); border-radius: 3px; }
      .tip { position: fixed; z-index: 2147483647; pointer-events: none; display: none; max-width: 320px;
             padding: 6px 10px; border-radius: 8px; background: #17171c; color: #ececf1;
             box-shadow: 0 6px 18px rgba(0,0,0,.35); font: 12px/1.35 system-ui, sans-serif; }
      .tip b { display: block; font-size: 13px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
      .tip span { color: #a5a5b4; }
      .hint { position: fixed; top: 16px; left: 50%; transform: translateX(-50%); z-index: 2147483647;
              padding: 8px 14px; border-radius: 8px; background: #17171c; color: #ececf1;
              font: 13px/1.4 system-ui, sans-serif; pointer-events: none; white-space: nowrap; }
      .card { position: fixed; top: 16px; right: 16px; z-index: 2147483647; width: 320px; max-height: calc(100vh - 32px);
              overflow: auto; padding: 14px; border-radius: 12px; background: #fff; color: #1c1c22;
              border: 1px solid #e4e4ea; box-shadow: 0 12px 32px rgba(0,0,0,.25); font: 13px/1.4 system-ui, sans-serif; }
      .card__head { display: flex; align-items: flex-start; gap: 10px; margin-bottom: 8px; }
      .card__title { flex: 1; min-width: 0; font-weight: 700; font-size: 15px; overflow-wrap: anywhere; }
      .card__title small { display: block; font-weight: 400; font-size: 12px; color: #6b6b78; }
      .close { border: 0; background: none; font-size: 18px; line-height: 1; color: #6b6b78; cursor: pointer; padding: 4px; }
      .sample { margin: 0 0 10px; padding: 10px; border-radius: 8px; background: #f5f5f7; font-size: 26px; line-height: 1.2;
                overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
      .row { display: flex; gap: 8px; padding: 5px 0; border-top: 1px solid #f0f0f4; }
      .row b { flex: 0 0 82px; font-size: 11.5px; color: #6b6b78; font-weight: 600; }
      .row code { flex: 1; min-width: 0; font: 12px ui-monospace, Menlo, Consolas, monospace; overflow-wrap: anywhere; }
      .dot { display: inline-block; width: 11px; height: 11px; margin-right: 5px; vertical-align: -1px;
             border-radius: 3px; border: 1px solid rgba(0,0,0,.2); }
      .actions { display: flex; gap: 8px; margin-top: 10px; }
      .btn { flex: 1; padding: 7px 9px; border: 1px solid #e4e4ea; border-radius: 6px; background: #f5f5f7; color: #1c1c22;
             font: 600 12px system-ui, sans-serif; cursor: pointer; }
      .btn:hover { border-color: #4f46e5; color: #4f46e5; }
      .btn--main { border-color: #4f46e5; background: #4f46e5; color: #fff; }
      .btn--main:hover { color: #fff; filter: brightness(1.1); }
      .foot { margin-top: 8px; font-size: 11.5px; color: #6b6b78; }
      @media (prefers-color-scheme: dark) {
        .card { background: #17171c; color: #ececf1; border-color: #2e2e37; }
        .card__title small, .row b, .close, .foot { color: #9a9aa8; }
        .row { border-top-color: #2e2e37; }
        .sample { background: #212128; }
        .btn { background: #212128; color: #ececf1; border-color: #2e2e37; }
        .btn--main { background: #4f46e5; border-color: #4f46e5; color: #fff; }
      }
    </style>
    <div class="box"></div>
    <div class="tip"><b></b><span></span></div>
    <div class="hint">Pasa el cursor sobre un texto · clic para ver los detalles · Esc para salir</div>`;

  const box = shadow.querySelector('.box');
  const tip = shadow.querySelector('.tip');
  const tipName = tip.querySelector('b');
  const tipInfo = tip.querySelector('span');
  const hint = shadow.querySelector('.hint');
  let card = null;
  let current = null;

  const inOverlay = (event) => event.composedPath().includes(host);

  function highlight(el) {
    const rect = el.getBoundingClientRect();
    Object.assign(box.style, {
      display: 'block',
      left: `${rect.left - 2}px`,
      top: `${rect.top - 2}px`,
      width: `${rect.width + 4}px`,
      height: `${rect.height + 4}px`,
    });
  }

  function onMove(event) {
    if (inOverlay(event)) return;
    const el = event.target instanceof Element ? event.target : null;
    if (!el) return;
    if (el !== current) {
      current = el;
      const info = describe(el);
      tipName.textContent = info.rendered;
      tipInfo.textContent = `${info.size.split(' ')[0]} · ${info.weight}`;
      highlight(el);
    }
    hint.style.display = 'none';
    tip.style.display = 'block';
    // El recuadro sigue al cursor y se da la vuelta cerca de los bordes.
    const w = tip.offsetWidth;
    const h = tip.offsetHeight;
    const x = event.clientX;
    const y = event.clientY;
    tip.style.left = `${x + 16 + w > window.innerWidth ? x - 16 - w : x + 16}px`;
    tip.style.top = `${y + 20 + h > window.innerHeight ? y - 12 - h : y + 20}px`;
  }

  function showCard(el) {
    const info = describe(el);
    card?.remove();
    card = document.createElement('div');
    card.className = 'card';
    const rows = [
      ['Pila CSS', escape(info.stack)],
      ['Tamaño', escape(info.size)],
      ['Peso', escape(info.weight)],
      ['Estilo', escape(info.style)],
      ['Interlineado', escape(info.lineHeight)],
      ['Espaciado', escape(info.letterSpacing)],
      ['Color', `<span class="dot" style="background:${escape(info.color)}"></span>${escape(info.hex || info.color)}`],
    ];
    card.innerHTML = `
      <div class="card__head">
        <div class="card__title"></div>
        <button class="close" title="Cerrar" aria-label="Cerrar">×</button>
      </div>
      <div class="sample">Aa Bb Cc 123 ¿Qué?</div>
      ${rows.map(([name, value]) => `<div class="row"><b>${name}</b><code>${value}</code></div>`).join('')}
      <div class="actions">
        <button class="btn btn--main" data-copy="name">Copiar nombre</button>
        <button class="btn" data-copy="css">Copiar CSS</button>
      </div>
      <div class="foot">Haz clic en otro texto para verlo · Esc para salir</div>`;

    const title = card.querySelector('.card__title');
    title.textContent = info.rendered;
    title.append(Object.assign(document.createElement('small'), { textContent: info.source }));
    // La muestra se pinta con la misma fuente, peso y estilo que el elemento.
    const style = getComputedStyle(el);
    Object.assign(card.querySelector('.sample').style, {
      fontFamily: style.fontFamily,
      fontWeight: style.fontWeight,
      fontStyle: style.fontStyle,
    });
    const sample = el.textContent.trim().replace(/\s+/g, ' ').slice(0, 60);
    if (sample) card.querySelector('.sample').textContent = sample;

    for (const button of card.querySelectorAll('[data-copy]')) {
      const label = button.textContent;
      button.addEventListener('click', async () => {
        const ok = await copy(button.dataset.copy === 'css' ? info.css : info.rendered);
        button.textContent = ok ? '✓ Copiado' : '✗ No se pudo copiar';
        setTimeout(() => (button.textContent = label), 1200);
      });
    }
    card.querySelector('.close').addEventListener('click', close);
    shadow.append(card);
  }

  // Los clics sobre la página no deben seguir enlaces ni activar botones mientras se inspecciona.
  function onClick(event) {
    if (inOverlay(event)) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (event.type === 'click' && event.target instanceof Element) showCard(event.target);
  }
  function onKey(event) {
    if (event.key !== 'Escape') return;
    event.preventDefault();
    event.stopPropagation();
    close();
  }
  function onScroll() {
    if (current) highlight(current);
  }

  const BLOCKED = ['click', 'mousedown', 'mouseup', 'pointerdown', 'pointerup', 'auxclick', 'dblclick', 'contextmenu'];
  function close() {
    host.remove();
    document.removeEventListener('pointermove', onMove, true);
    document.removeEventListener('keydown', onKey, true);
    window.removeEventListener('scroll', onScroll, true);
    for (const type of BLOCKED) document.removeEventListener(type, onClick, true);
  }
  host.__close = close;

  document.addEventListener('pointermove', onMove, true);
  document.addEventListener('keydown', onKey, true);
  window.addEventListener('scroll', onScroll, true);
  for (const type of BLOCKED) document.addEventListener(type, onClick, true);
  document.documentElement.append(host);
}

// --- Service worker -----------------------------------------------------------------

// Desde el popup ({ tabId }) o desde el menú contextual.
export async function startFontInspector(message) {
  const tab = await chrome.tabs.get(message.tabId);
  if (!/^https?:/i.test(tab.url || '')) throw new Error('Solo se puede usar en páginas http:// o https://.');
  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: inspectFonts });
  } catch (err) {
    throw new Error(`No se pudo abrir el identificador de fuentes (${err.message}).`);
  }
  return {};
}

export const FONT_MENU_ID = 'font-inspect';

export function setupFontMenu() {
  chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
      id: FONT_MENU_ID,
      title: 'Identificar fuente',
      contexts: ['all'],
      documentUrlPatterns: ['http://*/*', 'https://*/*'],
    });
  });
  chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === FONT_MENU_ID && tab?.id >= 0) startFontInspector({ tabId: tab.id }).catch(() => {});
  });
}
