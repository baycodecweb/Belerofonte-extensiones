// Capturas de pantalla: área visible, página completa (desplazando y uniendo tramos) y selección.

// Chrome admite como mucho 2 llamadas por segundo a captureVisibleTab.
const CAPTURE_INTERVAL = 600;
// Límites del lienzo: más allá los navegadores fallan o tardan demasiado en codificar el PNG.
const MAX_CANVAS_SIDE = 32_000;
const MAX_CANVAS_PIXELS = 100_000_000;
// Se guardan solo las últimas capturas, en memoria, hasta que la pestaña de vista previa las pide.
const MAX_STORED = 3;
// Cada tramo se solapa con el anterior (px CSS) para que el redondeo con escalas como 125 % no
// deje líneas sin pintar entre tramos.
const OVERLAP = 2;
// Tope del recorrido previo por la página (para webs con scroll infinito).
const PREPARE_TIME_LIMIT = 15_000;

const captures = new Map();
let lastGrab = 0;

const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function grab(windowId) {
  const delay = lastGrab + CAPTURE_INTERVAL - Date.now();
  if (delay > 0) await wait(delay);
  lastGrab = Date.now();
  return chrome.tabs.captureVisibleTab(windowId, { format: 'png' });
}

const toBitmap = async (dataUrl) => createImageBitmap(await (await fetch(dataUrl)).blob());

async function toDataUrl(blob) {
  const bytes = new Uint8Array(await blob.arrayBuffer());
  let binary = '';
  for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return `data:${blob.type};base64,${btoa(binary)}`;
}

const canvasToDataUrl = async (canvas) => toDataUrl(await canvas.convertToBlob({ type: 'image/png' }));

// --- Funciones que se ejecutan dentro de la página ----------------------------------

function pageMetrics() {
  const doc = document.documentElement;
  return {
    scrollX: window.scrollX,
    scrollY: window.scrollY,
    innerWidth: window.innerWidth,
    // clientWidth/clientHeight excluyen las barras de desplazamiento.
    width: Math.min(doc.clientWidth || window.innerWidth, window.innerWidth),
    viewHeight: Math.min(doc.clientHeight || window.innerHeight, window.innerHeight),
    fullHeight: Math.max(doc.scrollHeight, document.body?.scrollHeight || 0),
  };
}

// Desplaza la página y espera a que se pinte. Con hideFixed oculta los elementos fijos o sticky
// para que no se repitan en cada tramo. Se buscan en cada paso porque muchas webs vuelven fija la
// cabecera (con su sombra) solo después de bajar.
async function scrollPage(y, hideFixed) {
  // Dos fotogramas para que se pinte la nueva posición (con tope por si no llegan a pintarse).
  const frame = () => new Promise((resolve) => {
    setTimeout(resolve, 300);
    requestAnimationFrame(() => requestAnimationFrame(resolve));
  });

  window.scrollTo({ left: 0, top: y, behavior: 'instant' });
  await frame();

  if (hideFixed) {
    const hidden = (window.__captureHidden ||= []);
    const known = (window.__captureHiddenNodes ||= new WeakSet());
    let added = false;
    for (const node of document.querySelectorAll('body *')) {
      if (known.has(node)) continue;
      const { position } = getComputedStyle(node);
      if (position !== 'fixed' && position !== 'sticky') continue;
      known.add(node);
      hidden.push([node, node.style.getPropertyValue('visibility'), node.style.getPropertyPriority('visibility')]);
      node.style.setProperty('visibility', 'hidden', 'important');
      added = true;
    }
    if (added) await frame();
  }
  return window.scrollY;
}

// Antes de capturar: congela animaciones y transiciones, recorre la página para que se disparen
// las animaciones de aparición y la carga diferida de imágenes, y vuelve arriba.
async function preparePage(maxHeight, timeLimit) {
  const style = document.createElement('style');
  style.id = '__capture-style';
  style.textContent = `
    *, *::before, *::after {
      transition-duration: 0s !important; transition-delay: 0s !important;
      animation-duration: 0s !important; animation-delay: 0s !important;
      caret-color: transparent !important;
    }
    html { scroll-behavior: auto !important; }`;
  document.documentElement.append(style);

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const height = () => Math.max(document.documentElement.scrollHeight, document.body?.scrollHeight || 0);
  const start = performance.now();
  // El alto se vuelve a medir en cada paso: así se incluye el contenido que aparece al bajar.
  for (let y = 0; y < Math.min(height(), maxHeight) && performance.now() - start < timeLimit; y += window.innerHeight) {
    window.scrollTo({ left: 0, top: y, behavior: 'instant' });
    await sleep(150);
  }
  window.scrollTo({ left: 0, top: height(), behavior: 'instant' });
  await sleep(300);

  const pending = [...document.images].filter((img) => !img.complete);
  await Promise.race([
    Promise.all(pending.map((img) => new Promise((resolve) => {
      img.addEventListener('load', resolve, { once: true });
      img.addEventListener('error', resolve, { once: true });
    }))),
    sleep(3000),
  ]);

  window.scrollTo({ left: 0, top: 0, behavior: 'instant' });
  await sleep(200);
}

function restorePage(x, y) {
  for (const [node, value, priority] of window.__captureHidden || []) {
    if (value) node.style.setProperty('visibility', value, priority);
    else node.style.removeProperty('visibility');
  }
  window.__captureHidden = null;
  window.__captureHiddenNodes = null;
  document.getElementById('__capture-style')?.remove();
  window.scrollTo({ left: x, top: y, behavior: 'instant' });
}

// Capa para elegir una región arrastrando. Al soltar, avisa al service worker.
function selectRegion() {
  if (document.getElementById('__capture-region')) return;

  const host = document.createElement('div');
  host.id = '__capture-region';
  const shadow = host.attachShadow({ mode: 'closed' });
  shadow.innerHTML = `
    <style>
      .layer { position: fixed; inset: 0; z-index: 2147483647; cursor: crosshair; background: rgba(0,0,0,.4); }
      .layer.dragging { background: transparent; }
      .box { position: fixed; display: none; border: 2px solid #8b85ff; box-shadow: 0 0 0 100vmax rgba(0,0,0,.4); }
      .size { position: absolute; left: 0; bottom: -24px; padding: 2px 6px; border-radius: 4px;
              background: #4f46e5; color: #fff; font: 600 11px/16px system-ui, sans-serif; white-space: nowrap; }
      .hint { position: fixed; top: 16px; left: 50%; transform: translateX(-50%); padding: 8px 14px; border-radius: 8px;
              background: #17171c; color: #ececf1; font: 13px/1.4 system-ui, sans-serif; pointer-events: none; }
    </style>
    <div class="layer">
      <div class="hint">Arrastra para seleccionar la región · Esc para cancelar</div>
      <div class="box"><span class="size"></span></div>
    </div>`;
  const layer = shadow.querySelector('.layer');
  const box = shadow.querySelector('.box');
  const size = shadow.querySelector('.size');
  const hint = shadow.querySelector('.hint');
  let start = null;
  let rect = null;

  const close = () => {
    host.remove();
    document.removeEventListener('keydown', onKey, true);
  };
  const onKey = (event) => {
    if (event.key !== 'Escape') return;
    event.preventDefault();
    event.stopPropagation();
    close();
  };

  layer.addEventListener('pointerdown', (event) => {
    if (event.button !== 0) return;
    start = { x: event.clientX, y: event.clientY };
    layer.setPointerCapture(event.pointerId);
    layer.classList.add('dragging');
    hint.style.display = 'none';
  });
  layer.addEventListener('pointermove', (event) => {
    if (!start) return;
    const x = Math.max(0, Math.min(start.x, event.clientX));
    const y = Math.max(0, Math.min(start.y, event.clientY));
    rect = {
      x,
      y,
      width: Math.min(window.innerWidth, Math.max(start.x, event.clientX)) - x,
      height: Math.min(window.innerHeight, Math.max(start.y, event.clientY)) - y,
    };
    Object.assign(box.style, { display: 'block', left: `${x}px`, top: `${y}px`, width: `${rect.width}px`, height: `${rect.height}px` });
    size.textContent = `${Math.round(rect.width)} × ${Math.round(rect.height)}`;
  });
  layer.addEventListener('pointerup', () => {
    if (!start) return;
    start = null;
    close();
    if (!rect || rect.width < 5 || rect.height < 5) return;
    // Se espera a que desaparezca la capa antes de capturar.
    requestAnimationFrame(() =>
      requestAnimationFrame(() => chrome.runtime.sendMessage({ type: 'capture-region', rect, innerWidth: window.innerWidth })),
    );
  });

  document.addEventListener('keydown', onKey, true);
  document.documentElement.append(host);
}

// --- Modos de captura -----------------------------------------------------------------

async function captureVisible(tab) {
  const dataUrl = await grab(tab.windowId);
  const bitmap = await toBitmap(dataUrl);
  const result = { dataUrl, width: bitmap.width, height: bitmap.height };
  bitmap.close();
  return result;
}

async function captureFull(tab) {
  const target = { tabId: tab.id };
  const run = async (func, args = []) => (await chrome.scripting.executeScript({ target, func, args }))[0].result;

  const original = await run(pageMetrics);
  let canvas, ctx, scale;
  let truncated = false;

  try {
    // Alto máximo útil en px CSS, según el límite del lienzo (aprox. con la escala de la pantalla).
    const dpr = await run(() => window.devicePixelRatio || 1);
    await run(preparePage, [Math.floor(MAX_CANVAS_SIDE / dpr), PREPARE_TIME_LIMIT]);
    const metrics = await run(pageMetrics);

    let y = 0;
    let previousY = -1;
    for (let step = 0; ; step++) {
      // El primer tramo se captura tal cual; desde el segundo se ocultan los elementos fijos.
      const actualY = await run(scrollPage, [y, step > 0]);
      const bitmap = await toBitmap(await grab(tab.windowId));

      if (!canvas) {
        scale = bitmap.width / metrics.innerWidth;
        const width = Math.round(metrics.width * scale);
        const fullHeight = Math.round(metrics.fullHeight * scale);
        const maxHeight = Math.min(MAX_CANVAS_SIDE, Math.floor(MAX_CANVAS_PIXELS / width));
        truncated = fullHeight > maxHeight;
        canvas = new OffscreenCanvas(width, Math.min(fullHeight, maxHeight));
        ctx = canvas.getContext('2d');
        ctx.fillStyle = '#fff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }
      ctx.drawImage(bitmap, 0, Math.round(actualY * scale));
      bitmap.close();

      const bottom = actualY + metrics.viewHeight;
      // Se para al llegar al final, al límite del lienzo o si la página ya no se desplaza.
      if (bottom >= metrics.fullHeight || bottom * scale >= canvas.height || actualY <= previousY) break;
      previousY = actualY;
      y = bottom - OVERLAP;
    }
  } finally {
    await run(restorePage, [original.scrollX, original.scrollY]).catch(() => {});
  }

  return { dataUrl: await canvasToDataUrl(canvas), width: canvas.width, height: canvas.height, truncated };
}

async function captureRegion(tab, rect, innerWidth) {
  const bitmap = await toBitmap(await grab(tab.windowId));
  const scale = bitmap.width / innerWidth;
  const sx = Math.round(rect.x * scale);
  const sy = Math.round(rect.y * scale);
  const width = Math.max(1, Math.min(Math.round(rect.width * scale), bitmap.width - sx));
  const height = Math.max(1, Math.min(Math.round(rect.height * scale), bitmap.height - sy));

  const canvas = new OffscreenCanvas(width, height);
  canvas.getContext('2d').drawImage(bitmap, sx, sy, width, height, 0, 0, width, height);
  bitmap.close();
  return { dataUrl: await canvasToDataUrl(canvas), width, height };
}

// --- Vista previa ---------------------------------------------------------------------

async function openPreview(tab, mode, image) {
  const id = crypto.randomUUID();
  captures.set(id, { ...image, mode, url: tab.url, title: tab.title, takenAt: Date.now() });
  while (captures.size > MAX_STORED) captures.delete(captures.keys().next().value);

  await chrome.tabs.create({
    url: chrome.runtime.getURL(`capture/capture.html?id=${id}`),
    windowId: tab.windowId,
    index: tab.index + 1,
    openerTabId: tab.id,
  });
  return { id };
}

// senderUrl: URL de la página de la extensión que pide la captura (p. ej. el simulador). Se usa
// la del remitente porque, sin el permiso "tabs", tab.url llega vacío en las páginas propias.
async function capturableTab(tabId, { senderUrl = '' } = {}) {
  const tab = await chrome.tabs.get(tabId);
  const ownPage = senderUrl.startsWith(chrome.runtime.getURL(''));
  if (!ownPage && !/^https?:/i.test(tab.url || '')) throw new Error('Solo se pueden capturar páginas http:// o https://.');
  // captureVisibleTab solo ve la pestaña activa de la ventana.
  if (!tab.active) throw new Error('La pestaña tiene que estar visible para capturarla.');
  return tab;
}

// Desde el popup: { mode: 'visible' | 'full' | 'region', tabId }
export async function startCapture({ mode, tabId }) {
  const tab = await capturableTab(tabId);
  try {
    if (mode === 'visible') return openPreview(tab, mode, await captureVisible(tab));
    if (mode === 'full') return openPreview(tab, mode, await captureFull(tab));
    if (mode === 'region') {
      await chrome.scripting.executeScript({ target: { tabId }, func: selectRegion });
      return { waiting: true };
    }
  } catch (err) {
    throw new Error(`No se pudo capturar la página (${err.message}).`);
  }
  throw new Error(`Modo de captura desconocido: ${mode}`);
}

// Desde la capa de selección, cuando el usuario suelta el ratón.
// También desde el simulador de dispositivos (página de la extensión), que indica la URL y el
// título del sitio simulado para nombrar el archivo.
export async function finishRegion({ rect, innerWidth, url, title }, sender) {
  const tab = await capturableTab(sender.tab.id, { senderUrl: sender.url });
  const image = await captureRegion(tab, rect, innerWidth);
  return openPreview({ ...tab, url: url || tab.url, title: title || tab.title }, 'region', image);
}

// Desde la pestaña de vista previa.
export async function getCapture({ id }) {
  const capture = captures.get(id);
  if (!capture) throw new Error('La captura ya no está disponible. Vuelve a capturar la página.');
  return capture;
}
