// Videos de OK.ru (Odnoklassniki). La página de su reproductor (ok.ru/videoembed/ID) publica los
// enlaces MP4 de cada calidad; se piden desde el propio navegador porque van atados a su IP y a su
// User-Agent (srcIp, srcAg). No llevan cifrado: se descargan tal cual. yt-dlp no sirve aquí porque su
// extractor de OK.ru dejó de funcionar al cambiar el formato de esa página.

const TIMEOUT = 15_000;

// Nombre de cada calidad en OK.ru → altura en píxeles.
const QUALITY = { mobile: 144, lowest: 240, low: 360, sd: 480, hd: 720, full: 1080, quad: 1440, ultra: 2160 };

// ok.ru/video/123 · m.ok.ru/video/123 · ok.ru/videoembed/123 · ok.ru/live/123 → "123".
export function okruId(url) {
  try {
    const parsed = new URL(url);
    if (!/(^|\.)ok\.ru$/i.test(parsed.hostname)) return null;
    return parsed.pathname.match(/^\/(?:video|videoembed|live)\/(\d+)/)?.[1] || null;
  } catch {
    return null;
  }
}

// El service worker no tiene DOMParser: solo hacen falta las entidades de un atributo HTML.
function decodeEntities(text) {
  const named = { quot: '"', amp: '&', apos: "'", lt: '<', gt: '>' };
  return text.replace(/&(#x[\da-f]+|#\d+|\w+);/gi, (entity, code) => {
    if (code[0] !== '#') return named[code.toLowerCase()] ?? entity;
    return String.fromCodePoint(code[1].toLowerCase() === 'x' ? parseInt(code.slice(2), 16) : parseInt(code.slice(1), 10));
  });
}

// Nombre de archivo válido en cualquier sistema.
export const safeFileName = (name) =>
  name.replace(/[\\/:*?"<>|\u0000-\u001f]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 120) || 'video';

// { id, title, duration, live, hls, qualities: [{ name, height, url }] } (de mayor a menor calidad).
export async function okruVideo(id) {
  const res = await fetch(`https://ok.ru/videoembed/${id}`, { credentials: 'include', signal: AbortSignal.timeout(TIMEOUT) });
  if (!res.ok) throw new Error(`OK.ru respondió ${res.status}.`);
  const raw = (await res.text()).match(/data-options="([^"]+)"/)?.[1];
  if (!raw) throw new Error('No se encontró el reproductor de OK.ru: el video puede ser privado o haber sido eliminado.');

  const flashvars = JSON.parse(decodeEntities(raw)).flashvars || {};
  let meta = flashvars.metadata;
  if (typeof meta === 'string') meta = JSON.parse(meta);
  // Formato antiguo: los datos se piden aparte.
  if (!meta && flashvars.metadataUrl) {
    const extra = await fetch(decodeURIComponent(flashvars.metadataUrl), { method: 'POST', credentials: 'include', signal: AbortSignal.timeout(TIMEOUT) });
    meta = await extra.json();
  }
  const movie = meta?.movie || {};
  if (movie.status && movie.status !== 'OK') throw new Error(movie.statusText || `El video no está disponible (${movie.status}).`);

  const qualities = (meta?.videos || [])
    .filter((v) => v.url && !v.disallowed)
    .map((v) => ({ name: v.name, height: QUALITY[v.name] || 0, url: v.url }))
    .sort((a, b) => b.height - a.height);
  const hls = meta?.hlsManifestUrl || meta?.hlsMasterPlaylistUrl || null;
  if (!qualities.length && !hls) throw new Error('OK.ru no ofrece ningún enlace de este video.');

  return {
    id,
    title: movie.title ? decodeEntities(movie.title) : `OK.ru ${id}`,
    duration: Number(movie.duration) || null,
    live: !!movie.isLive,
    hls,
    qualities,
  };
}

// La calidad pedida ("mejor", "1080", "720"…): la más alta que no la supere, o la más baja que haya.
export function pickQuality(qualities, calidad) {
  if (!qualities.length) return null;
  const max = Number(calidad);
  if (!max) return qualities[0];
  return qualities.find((q) => q.height <= max) || qualities[qualities.length - 1];
}
