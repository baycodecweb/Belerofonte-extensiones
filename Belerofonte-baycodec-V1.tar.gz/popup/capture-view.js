// Sección "Capturar" del popup: área visible, página completa o selección.

const MESSAGES = {
  visible: 'Capturando el área visible…',
  full: 'Capturando la página completa… no la desplaces mientras tanto.',
  region: 'Arrastra sobre la página para elegir la región.',
};

export function setupCapture(getTabId) {
  const buttons = [...document.querySelectorAll('.capture__btn')];
  const status = document.getElementById('capture-status');

  const setStatus = (text, isError = false) => {
    status.hidden = !text;
    status.textContent = text;
    status.classList.toggle('warn', isError);
  };

  for (const button of buttons) {
    button.addEventListener('click', async () => {
      const { mode } = button.dataset;
      buttons.forEach((b) => (b.disabled = true));
      setStatus(MESSAGES[mode]);

      const response = await chrome.runtime.sendMessage({ type: 'capture', mode, tabId: getTabId() });
      if (response?.ok && mode === 'region') {
        // Se cierra el popup para que el usuario pueda arrastrar sobre la página.
        window.close();
        return;
      }
      // Si todo fue bien se abre la pestaña de vista previa y el popup se cierra solo.
      buttons.forEach((b) => (b.disabled = false));
      if (!response?.ok) setStatus(response?.error || 'No se pudo capturar la página.', true);
    });
  }
}
