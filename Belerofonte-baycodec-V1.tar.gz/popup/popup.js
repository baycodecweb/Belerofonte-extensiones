import { setupDomain } from './domain-view.js';
import { setupCapture } from './capture-view.js';
import { setupPicker } from './picker-view.js';
import { setupFont } from './font-view.js';
import { setupVideos } from './video-view.js';
import { setupWordPress } from './wordpress-view.js';

const content = document.getElementById('content');
const hostEl = document.getElementById('host');
const footer = document.getElementById('footer');
const copyBtn = document.getElementById('copy');

let lastResult = null;
let tabId = null;
const getDomainProfile = setupDomain(() => tabId);
const getWordPressProfile = setupWordPress(() => tabId);
setupCapture(() => tabId);
setupPicker(() => tabId);
setupFont(() => tabId);

document.getElementById('sim-btn').addEventListener('click', async () => {
  const response = await chrome.runtime.sendMessage({ type: 'sim-open', tabId });
  if (response?.ok) return window.close();
  const status = document.getElementById('sim-status');
  status.hidden = false;
  status.textContent = response?.error || 'No se pudo abrir el simulador.';
});
const loadVideos = setupVideos();

function el(tag, props = {}, children = []) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children);
  return node;
}

function showState(text, isError = false) {
  content.replaceChildren(el('p', { className: `state${isError ? ' state--error' : ''}`, textContent: text }));
}

// Color estable por tecnología, para que el avatar siempre sea el mismo.
function colorFor(name) {
  let hash = 0;
  for (const ch of name) hash = (hash * 31 + ch.charCodeAt(0)) | 0;
  return `hsl(${Math.abs(hash) % 360} 55% 45%)`;
}

function renderTech(tech) {
  const nameRow = el('div', { className: 'tech__name' }, [
    el('a', { href: tech.website || '#', target: '_blank', rel: 'noopener', textContent: tech.name, title: tech.description }),
  ]);
  if (tech.version) nameRow.append(el('span', { className: 'chip', textContent: tech.version }));
  if (tech.confidence < 100) {
    nameRow.append(el('span', { className: 'chip chip--low', textContent: `${tech.confidence}%`, title: 'Nivel de confianza' }));
  }

  return el('li', { className: 'tech' }, [
    renderAvatar(tech),
    el('div', { className: 'tech__body' }, [
      nameRow,
      el('div', { className: 'tech__evidence', textContent: `Detectado por: ${tech.evidence.join(', ')}` }),
      ...(tech.note ? [el('div', { className: 'tech__note', textContent: `ℹ ${tech.note}` })] : []),
    ]),
  ]);
}

// Logo de la tecnología (icons/tech/<slug>.svg); sin logo, sus iniciales sobre un color propio.
function renderAvatar(tech) {
  const initials = () => {
    const avatar = el('span', { className: 'avatar', textContent: tech.name.slice(0, 2) });
    avatar.style.background = colorFor(tech.name);
    return avatar;
  };
  if (!tech.icon) return initials();

  // "logos:magento" → logos-magento.svg (mismo nombre que genera tools/build-icons.py).
  const img = el('img', { className: 'avatar avatar--logo', src: `../icons/tech/${tech.icon.replace(':', '-')}.svg`, alt: '' });
  if (tech.icon.startsWith('lucide:')) img.title = 'Icono de referencia: no hay logo oficial disponible';
  img.addEventListener('error', () => img.replaceWith(initials()), { once: true });
  return img;
}

// Muestra "Aa" con la propia fuente. Las de Google Fonts se piden a Google para la vista
// previa; las locales solo se ven si también están instaladas en este equipo.
function loadPreview(font) {
  if (font.source !== 'Google Fonts') return;
  const family = encodeURIComponent(font.family).replace(/%20/g, '+');
  document.head.append(el('link', { rel: 'stylesheet', href: `https://fonts.googleapis.com/css2?family=${family}&display=swap` }));
}

function renderFont(font) {
  loadPreview(font);
  const sample = el('span', { className: 'font-sample', textContent: font.icon ? '★' : 'Aa' });
  sample.style.fontFamily = `"${font.family}", system-ui, sans-serif`;

  const chips = [
    ...font.roles.map((role) => el('span', { className: 'chip', textContent: role })),
    el('span', { className: `chip ${font.webfont ? 'chip--source' : 'chip--muted'}`, textContent: font.source }),
  ];

  const details = [];
  if (font.weights.length) details.push(`Pesos: ${font.weights.join(' · ')}`);
  if (!font.icon) details.push(font.usage > 0 && font.usage < 1 ? '<1% del texto' : `${font.usage}% del texto`);

  const bar = el('div', { className: 'usage' }, [el('div', { className: 'usage__fill' })]);
  bar.firstChild.style.width = `${font.icon ? 0 : font.usage}%`;

  return el('li', { className: 'font' }, [
    sample,
    el('div', { className: 'tech__body' }, [
      el('div', { className: 'tech__name' }, [el('strong', { textContent: font.family }), ...chips]),
      el('div', { className: 'tech__evidence', textContent: details.join(' · ') }),
      font.icon ? '' : bar,
    ]),
  ]);
}

function render(result) {
  const { technologies, fonts = [] } = result;
  hostEl.textContent = new URL(result.url).host;
  footer.textContent = `${technologies.length} tecnologías · ${fonts.length} fuentes · ${result.rules} reglas`;

  if (!technologies.length && !fonts.length) {
    showState('No se detectó ninguna tecnología conocida en esta página.');
    return;
  }

  // Una tecnología aparece en cada una de sus categorías (p. ej. Next.js en JS y frameworks web).
  const groups = new Map();
  for (const tech of technologies) {
    for (const cat of tech.categories) {
      if (!groups.has(cat.id)) groups.set(cat.id, { name: cat.name, priority: cat.priority, items: [] });
      groups.get(cat.id).items.push(tech);
    }
  }

  const sections = [...groups.values()]
    .sort((a, b) => a.priority - b.priority || a.name.localeCompare(b.name))
    .map((group) =>
      el('section', { className: 'category' }, [
        el('h2', { textContent: group.name }),
        el('ul', {}, group.items.map(renderTech)),
      ]),
    );

  if (fonts.length) {
    sections.unshift(
      el('section', { className: 'category' }, [el('h2', { textContent: 'Tipografía' }), el('ul', {}, fonts.map(renderFont))]),
    );
  }

  content.replaceChildren(...sections);
}

async function run() {
  showState('Analizando la página…');
  copyBtn.disabled = true;

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return showState('No hay ninguna pestaña activa.', true);
  tabId = tab.id;
  loadVideos(tab.id);

  const result = await chrome.runtime.sendMessage({ type: 'analyze', tabId: tab.id });
  if (!result?.ok) {
    hostEl.textContent = tab.url ? tab.url.split('/')[2] || tab.url : '—';
    return showState(result?.error || 'No se pudo analizar la página.', true);
  }

  lastResult = result;
  copyBtn.disabled = false;
  render(result);
}

document.getElementById('refresh').addEventListener('click', run);

copyBtn.addEventListener('click', async () => {
  if (!lastResult) return;
  const data = lastResult.technologies.map(({ name, version, confidence, categories }) => ({
    name,
    version,
    confidence,
    categories: categories.map((c) => c.name),
  }));
  const fonts = lastResult.fonts.map(({ family, usage, roles, weights, source }) => ({ family, usage, roles, weights, source }));
  const domain = getDomainProfile();
  const wordpress = getWordPressProfile();
  await navigator.clipboard.writeText(
    JSON.stringify({ url: lastResult.url, technologies: data, fonts, ...(domain && { domain }), ...(wordpress && { wordpress }) }, null, 2),
  );
  copyBtn.textContent = '✓';
  setTimeout(() => (copyBtn.textContent = '⧉'), 1200);
});

run();
