// Sección "Antigüedad del dominio" del popup: pide el perfil al service worker y lo muestra en español.

import { estimate } from '../domain.js';

const dateLong = new Intl.DateTimeFormat('es', { dateStyle: 'long' });
const monthYear = new Intl.DateTimeFormat('es', { month: 'long', year: 'numeric' });
const integer = new Intl.NumberFormat('es-ES', { useGrouping: 'always' });
const relative = new Intl.RelativeTimeFormat('es', { numeric: 'auto' });
const DAY = 86_400_000;

// Estados EPP (RFC 5731 / RDAP) traducidos.
const STATUS = {
  active: 'Activo',
  ok: 'Activo',
  inactive: 'Inactivo (sin servidores de nombres)',
  clienttransferprohibited: 'Transferencia bloqueada por el registrador',
  servertransferprohibited: 'Transferencia bloqueada por el registro',
  transferprohibited: 'Transferencia bloqueada',
  clientdeleteprohibited: 'Eliminación bloqueada por el registrador',
  serverdeleteprohibited: 'Eliminación bloqueada por el registro',
  deleteprohibited: 'Eliminación bloqueada',
  clientupdateprohibited: 'Modificación bloqueada por el registrador',
  serverupdateprohibited: 'Modificación bloqueada por el registro',
  updateprohibited: 'Modificación bloqueada',
  clientrenewprohibited: 'Renovación bloqueada por el registrador',
  serverrenewprohibited: 'Renovación bloqueada por el registro',
  renewprohibited: 'Renovación bloqueada',
  clienthold: 'Suspendido por el registrador (no resuelve)',
  serverhold: 'Suspendido por el registro (no resuelve)',
  pendingcreate: 'Creación pendiente',
  pendingdelete: 'Pendiente de eliminación',
  pendingrenew: 'Renovación pendiente',
  pendingtransfer: 'Transferencia pendiente',
  pendingupdate: 'Modificación pendiente',
  redemptionperiod: 'Periodo de recuperación (caducado)',
  autorenewperiod: 'Periodo de gracia por renovación automática',
  addperiod: 'Periodo de gracia tras el registro',
  renewperiod: 'Periodo de gracia tras la renovación',
  transferperiod: 'Periodo de gracia tras la transferencia',
  locked: 'Bloqueado',
  associated: 'Asociado',
};

function el(tag, props = {}, children = []) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children.filter((c) => c != null && c !== false));
  return node;
}

const link = (href, text) => el('a', { href, target: '_blank', rel: 'noopener', textContent: text });
const muted = (text) => el('span', { className: 'muted', textContent: text });

// "7 años y 10 meses", "3 meses", "12 días".
function duration(from, to = new Date()) {
  from = new Date(from);
  to = new Date(to);
  let months = (to.getFullYear() - from.getFullYear()) * 12 + to.getMonth() - from.getMonth();
  if (to.getDate() < from.getDate()) months--;
  const years = Math.floor(months / 12);
  const rest = months % 12;
  const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;
  if (years > 0) return rest ? `${plural(years, 'año', 'años')} y ${plural(rest, 'mes', 'meses')}` : plural(years, 'año', 'años');
  if (months > 0) return plural(months, 'mes', 'meses');
  return plural(Math.max(0, Math.floor((to - from) / DAY)), 'día', 'días');
}

const days = (from, to = new Date()) => Math.floor((new Date(to) - new Date(from)) / DAY);

// "en 43 días", "hace 2 meses", "en 3 años".
function fromNow(date) {
  const diff = Math.round((new Date(date) - Date.now()) / DAY);
  if (Math.abs(diff) < 60) return relative.format(diff, 'day');
  if (Math.abs(diff) < 730) return relative.format(Math.round(diff / 30.44), 'month');
  return relative.format(Math.round(diff / 365.25), 'year');
}

function estimateView(est, pending) {
  const basisText = (e) =>
    e.basis === 'archive' ? `la primera captura en archive.org (${dateLong.format(new Date(e.to))})`
      : `el copyright más antiguo de la página (© ${e.year})`;
  const when = (e) => (e.basis === 'copyright' ? String(e.year) : monthYear.format(new Date(e.to)));

  let title, detail, note;
  switch (est.kind) {
    case 'range': {
      const span = days(est.from, est.to);
      title = span < 62 ? `Creado alrededor de ${monthYear.format(new Date(est.from))}`
        : `Creado entre ${monthYear.format(new Date(est.from))} y ${when(est)}`;
      const ageMax = duration(est.from);
      const ageMin = duration(est.to);
      detail = span < 62 ? `Antigüedad estimada: ${ageMax}.` : `Antigüedad estimada: mínimo ${ageMin} · máximo ${ageMax}.`;
      note = `Entre el registro del dominio (${dateLong.format(new Date(est.from))}) y ${basisText(est)}.`;
      break;
    }
    case 'before-registration':
      title = `El sitio existe al menos desde ${when(est)}`;
      detail = `Antigüedad estimada: más de ${duration(est.to)}.`;
      note = `Esa fecha es anterior al registro actual del dominio (${dateLong.format(new Date(est.registered))}): el dominio pudo caducar y volver a registrarse` +
        (est.basis === 'copyright' ? ', o el año del copyright corresponde a la empresa y no al sitio.' : '.');
      break;
    case 'not-before':
      title = `Creado a partir de ${monthYear.format(new Date(est.from))}`;
      detail = `Antigüedad máxima: ${duration(est.from)}.`;
      note = 'No hay capturas en archive.org ni copyright en la página; solo se conoce la fecha de registro del dominio.';
      break;
    case 'at-least':
      title = `El sitio existe al menos desde ${when(est)}`;
      detail = `Antigüedad estimada: más de ${duration(est.to)}.`;
      note = `Basado en ${basisText(est)}. No hay datos de registro del dominio.`;
      break;
    default:
      title = 'No hay datos suficientes para estimarlo';
      note = 'Ni el registro del dominio, ni archive.org, ni la página dan pistas de su antigüedad.';
  }

  return el('div', { className: 'estimate' }, [
    el('div', { className: 'estimate__label', textContent: 'Estimación de creación del sitio' }),
    el('div', { className: 'estimate__title', textContent: title }),
    detail && el('div', { className: 'estimate__detail', textContent: detail }),
    el('div', { className: 'estimate__note', textContent: note }),
    pending && el('div', { className: 'estimate__note', textContent: '⏳ Esperando a archive.org para afinar la estimación…' }),
  ]);
}

function row(label, ...value) {
  return [el('dt', { textContent: label }), el('dd', {}, value)];
}

function errorRow(label, error) {
  return row(label, el('span', { className: 'warn', textContent: error }));
}

function render(profile) {
  const { rdap, ipInfo, network, asn, wayback, hints } = profile;
  const rows = [];

  if (rdap.error) {
    rows.push(...errorRow('Registro', rdap.error));
  } else {
    if (rdap.created) {
      rows.push(...row('Antigüedad del dominio', `${duration(rdap.created)} `, muted(`(${integer.format(days(rdap.created))} días)`)));
      rows.push(...row('Creado el', dateLong.format(new Date(rdap.created))));
    }
    if (rdap.expires) {
      const expired = new Date(rdap.expires) < new Date();
      rows.push(...row('Vence el', `${dateLong.format(new Date(rdap.expires))} `,
        el('span', { className: expired ? 'warn' : 'muted', textContent: `(${expired ? 'venció ' : ''}${fromNow(rdap.expires)})` })));
    }
    if (rdap.updated) rows.push(...row('Actualizado el', dateLong.format(new Date(rdap.updated))));
    if (rdap.registrar) {
      const r = rdap.registrar;
      rows.push(...row('Registrador', r.name,
        r.ianaId && muted(` · ID IANA ${r.ianaId}`),
        r.url && el('div', {}, [link(r.url, r.url.replace(/^https?:\/\//, '').replace(/\/$/, ''))])));
      if (r.whois) rows.push(...row('Servidor WHOIS', r.whois));
    }
    if (rdap.status.length) {
      rows.push(...row('Estado del registro', ...rdap.status.map((s) => {
        const key = s.toLowerCase().replace(/[\s_-]/g, '');
        return el('div', {}, [STATUS[key] || s, STATUS[key] ? muted(` (${s})`) : null]);
      })));
    }
    if (rdap.nameservers.length) {
      rows.push(...row('Servidores de nombres', ...rdap.nameservers.map((ns) => el('div', { textContent: ns }))));
    }
    if (rdap.dnssec !== null) rows.push(...row('DNSSEC', rdap.dnssec ? 'Activado' : 'Desactivado'));
  }

  if (profile.ip) rows.push(...row('Dirección IP', profile.ip));
  if (ipInfo?.error) rows.push(...errorRow('Ubicación de la IP', ipInfo.error));
  else if (ipInfo) {
    rows.push(...row('Ubicación de la IP', `${ipInfo.flag} ${[ipInfo.country, ipInfo.region, ipInfo.city].filter(Boolean).join(' – ')}`.trim()));
  }
  if (network && !network.error && network.name) {
    rows.push(...row('Titular de la red', network.name, network.address && muted(` · ${network.address}`)));
  }
  if (asn) {
    rows.push(...row('ASN', `AS${asn.number} ${asn.org || asn.name || ''}`,
      asn.registered && muted(` (registrado el ${dateLong.format(new Date(asn.registered))})`)));
  }

  if (!wayback) rows.push(...row('Primera captura en archive.org', muted('Consultando… (puede tardar hasta un minuto)')));
  else if (wayback.error) rows.push(...errorRow('Primera captura en archive.org', wayback.error));
  else if (wayback.firstCapture) {
    rows.push(...row('Primera captura en archive.org', `${dateLong.format(new Date(wayback.firstCapture))} · `, link(wayback.url, 'ver captura')));
  } else {
    rows.push(...row('Primera captura en archive.org', muted('Sin capturas')));
  }
  if (hints.copyrightYear) rows.push(...row('Copyright más antiguo', `© ${hints.copyrightYear}`));
  if (hints.foundingYear) rows.push(...row('Año de fundación (schema.org)', String(hints.foundingYear)));
  if (profile.lastModified) {
    const date = new Date(profile.lastModified);
    if (!Number.isNaN(date.getTime())) rows.push(...row('Última modificación de la página', dateLong.format(date)));
  }
  rows.push(...row('Estado del dominio', rdap.error ? 'Sitio web activo' : 'Registrado · sitio web activo'));

  const checked = new Date(profile.checkedAt);
  return el('div', { className: 'domain__card' }, [
    el('div', { className: 'domain__title' }, [el('strong', { textContent: profile.domain }), muted(' · perfil del dominio')]),
    estimateView(
      estimate({ created: rdap.created, firstCapture: wayback?.firstCapture, copyrightYear: hints.copyrightYear }),
      !wayback,
    ),
    el('dl', { className: 'domain__list' }, rows),
    el('p', {
      className: 'domain__sources muted',
      textContent: `Fuentes: RDAP (WHOIS), Wayback Machine, ipwho.is y DNS de Cloudflare · ` +
        (profile.cached ? `en caché desde las ${checked.toLocaleTimeString('es', { hour: '2-digit', minute: '2-digit' })}` : 'consultado ahora'),
    }),
  ]);
}

const stripOk = ({ ok, ...rest }) => rest;

export function setupDomain(getTabId) {
  const button = document.getElementById('domain-btn');
  const result = document.getElementById('domain-result');
  const note = document.getElementById('domain-note');
  const toggle = document.getElementById('domain-toggle');
  let profile = null;

  const setExpanded = (expanded) => {
    result.hidden = !expanded;
    toggle.setAttribute('aria-expanded', String(expanded));
    toggle.textContent = expanded ? '▴ Ocultar' : '▾ Mostrar';
  };
  toggle.addEventListener('click', () => setExpanded(result.hidden));

  button.addEventListener('click', async () => {
    const refresh = !!profile;
    button.disabled = true;
    button.textContent = 'Consultando registro del dominio e IP…';
    result.replaceChildren();
    setExpanded(true);
    toggle.hidden = true;

    const response = await chrome.runtime.sendMessage({ type: 'domain', tabId: getTabId(), refresh });
    button.disabled = false;
    if (!response?.ok) {
      button.textContent = '🕰 Reintentar';
      result.replaceChildren(el('p', { className: 'state state--error', textContent: response?.error || 'No se pudo consultar el dominio.' }));
      return;
    }

    profile = response;
    note.hidden = true;
    button.textContent = '↻ Actualizar datos del dominio';
    toggle.hidden = false;
    result.replaceChildren(render(profile));

    // archive.org llega después; se vuelve a pintar la tarjeta con la estimación afinada.
    const current = profile;
    const wayback = await chrome.runtime.sendMessage({ type: 'wayback', domain: current.domain, refresh });
    if (profile !== current) return; // el usuario pulsó "Actualizar" mientras tanto
    current.wayback = wayback?.ok ? stripOk(wayback) : { error: wayback?.error || 'No se pudo consultar archive.org.' };
    result.replaceChildren(render(current));
  });

  return () => profile;
}
