// Sección "Analizar WordPress" del popup: versión del núcleo, tema y plugins, y si están al día.

const dateShort = new Intl.DateTimeFormat('es', { dateStyle: 'medium' });

function el(tag, props = {}, children = []) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children.filter((c) => c != null && c !== false));
  return node;
}

const muted = (text) => el('span', { className: 'muted', textContent: text });
const chip = (text, variant = '', title = '') => el('span', { className: `chip${variant ? ` chip--${variant}` : ''}`, textContent: text, title });

// Estado frente a WordPress.org.
function statusChip(item) {
  if (item.status === 'current') return chip('✓ Al día', 'ok', `Es la última versión publicada (${item.latest})`);
  if (item.status === 'outdated') return chip(`⚠ Desactualizado · última ${item.latest}`, 'old', 'Hay una versión más nueva en WordPress.org');
  if (item.inDirectory === false) return chip('Premium o propio', 'muted', 'No está en el directorio de WordPress.org: no se puede comparar');
  if (item.latest) return chip(`Última: ${item.latest}`, 'muted', 'No se pudo saber qué versión tiene instalada este sitio');
  return null;
}

const sourcesText = (sources) => (sources.length ? `Versión según: ${[...new Set(sources.map((s) => s.source))].join(', ')}` : 'Versión oculta');

function coreView(core) {
  const { version, latest, status, sources } = core;
  const title = version ? `WordPress ${version}` : 'WordPress (versión oculta)';
  let detail;
  if (status === 'current') detail = '✓ Es la última versión.';
  else if (status === 'outdated') detail = `⚠ Desactualizado: la última versión es ${latest}.`;
  else if (latest) detail = `La última versión publicada es ${latest}.`;

  // Si las fuentes no coinciden, se enseñan todas.
  const distinct = [...new Set(sources.map((s) => s.version))];
  const note = !sources.length
    ? 'El sitio oculta la versión (sin generator, feed ni ?ver= del núcleo).'
    : distinct.length > 1
      ? sources.map((s) => `${s.source}: ${s.version}`).join(' · ')
      : `Detectado por: ${sources.map((s) => s.source).join(', ')}.`;

  return el('div', { className: `estimate${status === 'outdated' ? ' estimate--warn' : ''}` }, [
    el('div', { className: 'estimate__label', textContent: 'Núcleo de WordPress' }),
    el('div', { className: 'estimate__title', textContent: title }),
    detail && el('div', { className: 'estimate__detail', textContent: detail }),
    el('div', { className: 'estimate__note', textContent: note }),
  ]);
}

function itemView({ name, version, slug, extra = [], evidence, status }) {
  return el('li', { className: 'tech' }, [
    el('div', { className: 'tech__body' }, [
      el('div', { className: 'tech__name' }, [
        el('strong', { textContent: name, title: slug }),
        version ? chip(version) : chip('versión oculta', 'muted'),
        status,
      ]),
      ...extra.map((text) => el('div', { className: 'tech__evidence', textContent: text })),
      el('div', { className: 'tech__evidence', textContent: evidence }),
    ]),
  ]);
}

const listShort = (items, max = 12) => items.slice(0, max).join(', ') + (items.length > max ? ` y ${items.length - max} más` : '');

const ROLE = { active: 'Tema activo', parent: 'Tema padre', other: 'Tema' };

function themeView(theme, themes) {
  const parent = theme.parent && themes.find((t) => t.slug === theme.parent);
  const role = [ROLE[theme.role], parent && `hijo de ${parent.name}`, theme.author && `de ${theme.author.replace(/<[^>]+>/g, '')}`]
    .filter(Boolean)
    .join(' · ');
  return itemView({
    name: theme.name,
    slug: theme.slug,
    version: theme.version,
    extra: [role],
    evidence: `${sourcesText(theme.sources)} · carpeta: ${theme.slug}`,
    status: statusChip(theme),
  });
}

function pluginView(plugin) {
  const where = [plugin.mu && 'mu-plugin', plugin.slug !== plugin.name && `carpeta: ${plugin.slug}`].filter(Boolean).join(' · ');
  return itemView({
    name: plugin.name,
    slug: plugin.slug,
    version: plugin.version,
    extra: where ? [where] : [],
    evidence: `Detectado por: ${plugin.evidence.join(', ')}${plugin.sources.length ? ` · ${sourcesText(plugin.sources)}` : ''}`,
    status: statusChip(plugin),
  });
}

function render(profile) {
  if (!profile.isWordPress) {
    return el('p', { className: 'state', textContent: 'Esta página no parece estar hecha con WordPress (no hay rastros de wp-content, wp-includes, API REST ni feed).' });
  }

  const { core, themes, plugins } = profile;
  const outdated = [core, ...themes, ...plugins].filter((i) => i.status === 'outdated').length;
  const checked = new Date(profile.checkedAt);

  return el('div', { className: 'domain__card' }, [
    el('div', { className: 'domain__title' }, [
      el('strong', { textContent: profile.siteName || new URL(profile.root).host }),
      muted(' · análisis de WordPress'),
    ]),
    coreView(core),
    outdated > 0 && el('p', { className: 'wp__summary warn', textContent: `⚠ ${outdated} ${outdated === 1 ? 'elemento desactualizado' : 'elementos desactualizados'}: conviene actualizar.` }),

    el('section', { className: 'category wp__group' }, [
      el('h2', { textContent: themes.length > 1 ? `Temas (${themes.length})` : 'Tema' }),
      themes.length
        ? el('ul', {}, themes.map((t) => themeView(t, themes)))
        : el('p', { className: 'wp__empty muted', textContent: 'No se encontró la carpeta del tema (puede ser un tema de bloques sin archivos propios o estar oculto).' }),
    ]),

    el('section', { className: 'category wp__group' }, [
      el('h2', { textContent: `Plugins (${plugins.length})` }),
      plugins.length
        ? el('ul', {}, plugins.map(pluginView))
        : el('p', { className: 'wp__empty muted', textContent: 'No se detectó ningún plugin en esta página.' }),
    ]),

    profile.otherNamespaces.length > 0 && el('p', { className: 'wp__empty muted', textContent: `Otras API REST registradas (posibles plugins): ${listShort(profile.otherNamespaces)}` }),

    el('p', {
      className: 'domain__sources muted',
      textContent: 'Solo aparecen los plugins que dejan rastro en esta página o en la API REST: puede haber más. ' +
        'Fuentes: HTML de la página, feed RSS, style.css, readme.txt, API REST y WordPress.org · ' +
        (profile.cached ? `en caché desde las ${checked.toLocaleTimeString('es', { hour: '2-digit', minute: '2-digit' })}` : `consultado el ${dateShort.format(checked)}`),
    }),
  ]);
}

export function setupWordPress(getTabId) {
  const button = document.getElementById('wp-btn');
  const result = document.getElementById('wp-result');
  const note = document.getElementById('wp-note');
  const toggle = document.getElementById('wp-toggle');
  let profile = null;

  const setExpanded = (expanded) => {
    result.hidden = !expanded;
    toggle.setAttribute('aria-expanded', String(expanded));
    toggle.textContent = expanded ? '▴ Ocultar' : '▾ Mostrar';
  };
  toggle.addEventListener('click', () => setExpanded(result.hidden));

  button.addEventListener('click', async () => {
    const refresh = !!profile;
    button.disabled = true;
    button.textContent = 'Analizando WordPress, tema y plugins…';
    result.replaceChildren();
    setExpanded(true);
    toggle.hidden = true;

    const response = await chrome.runtime.sendMessage({ type: 'wordpress', tabId: getTabId(), refresh });
    button.disabled = false;
    if (!response?.ok) {
      button.textContent = '🧩 Reintentar';
      result.replaceChildren(el('p', { className: 'state state--error', textContent: response?.error || 'No se pudo analizar el sitio.' }));
      return;
    }

    const { ok, ...data } = response;
    profile = data;
    note.hidden = true;
    button.textContent = '↻ Volver a analizar WordPress';
    toggle.hidden = false;
    result.replaceChildren(render(profile));
  });

  return () => profile;
}
