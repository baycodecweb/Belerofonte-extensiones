// Sección "Cuentagotas" del popup: abre el cuentagotas en la página y muestra los colores recientes.

const HISTORY_KEY = 'eyedropperColors';

export function setupPicker(getTabId) {
  const button = document.getElementById('picker-btn');
  const recent = document.getElementById('picker-recent');
  const status = document.getElementById('picker-status');

  const setStatus = (text, isError = false) => {
    status.hidden = !text;
    status.textContent = text;
    status.classList.toggle('warn', isError);
  };

  async function renderRecent() {
    const colors = (await chrome.storage.local.get(HISTORY_KEY))[HISTORY_KEY] || [];
    recent.hidden = !colors.length;
    recent.replaceChildren(...colors.map((color) => {
      const swatch = document.createElement('button');
      swatch.className = 'swatch-btn';
      swatch.style.background = color;
      swatch.title = `${color} · clic para copiar`;
      swatch.setAttribute('aria-label', `Copiar ${color}`);
      swatch.addEventListener('click', async () => {
        await navigator.clipboard.writeText(color);
        setStatus(`${color} copiado al portapapeles`);
      });
      return swatch;
    }));
  }

  button.addEventListener('click', async () => {
    button.disabled = true;
    setStatus('');
    const response = await chrome.runtime.sendMessage({ type: 'eyedropper', tabId: getTabId() });
    if (response?.ok) {
      // Se cierra el popup para que el usuario pueda hacer clic en la página.
      window.close();
      return;
    }
    button.disabled = false;
    setStatus(response?.error || 'No se pudo abrir el cuentagotas.', true);
  });

  renderRecent();
}
