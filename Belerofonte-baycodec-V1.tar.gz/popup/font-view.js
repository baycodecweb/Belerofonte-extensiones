// Sección "Identificar fuente" del popup: abre el identificador de fuentes en la página.

export function setupFont(getTabId) {
  const button = document.getElementById('font-btn');
  const status = document.getElementById('font-status');

  button.addEventListener('click', async () => {
    button.disabled = true;
    status.hidden = true;
    const response = await chrome.runtime.sendMessage({ type: 'font-inspect', tabId: getTabId() });
    if (response?.ok) {
      // Se cierra el popup para que el usuario pueda pasar el cursor por la página.
      window.close();
      return;
    }
    button.disabled = false;
    status.hidden = false;
    status.textContent = response?.error || 'No se pudo abrir el identificador de fuentes.';
    status.classList.add('warn');
  });
}
