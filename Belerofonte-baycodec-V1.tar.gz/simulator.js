// Simulador de dispositivos (service worker): abre la pestaña del simulador y prepara su marco.
//   - Reglas de declarativeNetRequest limitadas a la pestaña del simulador: envían el User-Agent y
//     los Client Hints del dispositivo, y quitan X-Frame-Options / CSP de los marcos para que las
//     webs que prohíben mostrarse dentro de otra página se puedan previsualizar.
//   - Registra simulator/frame.js (solo mientras haya algún simulador abierto).
//   - Avisa a la página del simulador de la URL a la que navega el marco.

const SCRIPT_ID = 'belerofonte-simulator';
const simKey = (tabId) => `sim:${tabId}`; // { ruleIds: [...] }
const REQUEST_TYPES = ['sub_frame', 'xmlhttprequest', 'script', 'stylesheet', 'image', 'font', 'media', 'object', 'ping', 'other', 'websocket'];

async function simTabs() {
  const all = await chrome.storage.session.get(null);
  return Object.keys(all).filter((k) => k.startsWith('sim:')).map((k) => Number(k.slice(4)));
}

async function ensureFrameScript() {
  const registered = await chrome.scripting.getRegisteredContentScripts({ ids: [SCRIPT_ID] });
  if (registered.length) return;
  await chrome.scripting.registerContentScripts([{
    id: SCRIPT_ID,
    js: ['simulator/frame.js'],
    matches: ['<all_urls>'],
    allFrames: true,
    matchOriginAsFallback: true,
    runAt: 'document_start',
    world: 'MAIN',
    persistAcrossSessions: false,
  }]);
}

async function freeRuleIds(count) {
  const used = new Set((await chrome.declarativeNetRequest.getSessionRules()).map((r) => r.id));
  const ids = [];
  for (let id = 1; ids.length < count; id++) if (!used.has(id)) ids.push(id);
  return ids;
}

export async function openSimulator({ tabId }) {
  const tab = await chrome.tabs.get(tabId);
  const page = new URL(chrome.runtime.getURL('simulator/simulator.html'));
  if (/^https?:/i.test(tab.url || '')) page.searchParams.set('url', tab.url);
  await chrome.tabs.create({ url: page.href, windowId: tab.windowId, index: tab.index + 1, openerTabId: tab.id });
  return {};
}

// La página del simulador lo llama al elegir dispositivo, antes de cargar el marco.
export async function configureSimulator({ profile }, sender) {
  const tabId = sender.tab?.id;
  if (tabId == null) throw new Error('El simulador tiene que estar en una pestaña.');
  const key = simKey(tabId);
  const previous = (await chrome.storage.session.get(key))[key]?.ruleIds || [];
  const [frameRule, headerRule] = previous.length === 2 ? previous : await freeRuleIds(2);

  const rules = [{
    id: frameRule,
    priority: 2,
    condition: { tabIds: [tabId], resourceTypes: ['sub_frame'] },
    action: {
      type: 'modifyHeaders',
      responseHeaders: [
        { header: 'x-frame-options', operation: 'remove' },
        { header: 'content-security-policy', operation: 'remove' },
      ],
    },
  }];
  const requestHeaders = [];
  if (profile.ua) requestHeaders.push({ header: 'user-agent', operation: 'set', value: profile.ua });
  if (profile.hintPlatform) {
    requestHeaders.push(
      { header: 'sec-ch-ua-mobile', operation: 'set', value: profile.mobile ? '?1' : '?0' },
      { header: 'sec-ch-ua-platform', operation: 'set', value: `"${profile.hintPlatform}"` },
    );
  }
  if (requestHeaders.length) {
    rules.push({
      id: headerRule,
      priority: 2,
      condition: { tabIds: [tabId], resourceTypes: REQUEST_TYPES },
      action: { type: 'modifyHeaders', requestHeaders },
    });
  }

  await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [frameRule, headerRule], addRules: rules });
  await chrome.storage.session.set({ [key]: { ruleIds: [frameRule, headerRule] } });
  await ensureFrameScript();
  return {};
}

// Al cerrar el simulador se quitan sus reglas; sin simuladores abiertos, también el script.
chrome.tabs.onRemoved.addListener(async (tabId) => {
  const key = simKey(tabId);
  const state = (await chrome.storage.session.get(key))[key];
  if (!state) return;
  await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: state.ruleIds }).catch(() => {});
  await chrome.storage.session.remove(key);
  if (!(await simTabs()).length) {
    await chrome.scripting.unregisterContentScripts({ ids: [SCRIPT_ID] }).catch(() => {});
  }
});

// URL del marco principal del simulador (para la barra de direcciones de la página).
chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    if (details.parentFrameId !== 0) return;
    chrome.storage.session.get(simKey(details.tabId)).then((stored) => {
      if (!stored[simKey(details.tabId)]) return;
      chrome.runtime.sendMessage({ type: 'sim-url', tabId: details.tabId, url: details.url }).catch(() => {});
    });
  },
  { urls: ['<all_urls>'], types: ['sub_frame'] },
);
