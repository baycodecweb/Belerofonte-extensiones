// Motor de detección: aplica las reglas de data/technologies.json sobre los datos
// recogidos de una página (HTML, scripts, cabeceras, cookies, variables JS, DOM...).
//
// Formato de patrón (igual que Wappalyzer):  "regex\;version:\1\;confidence:50"
//   - regex:      expresión regular (sin distinguir mayúsculas). "" = basta con que exista.
//   - version:    plantilla de versión; \1, \2... se sustituyen por los grupos capturados.
//   - confidence: cuánto aporta esta evidencia (por defecto 100). Se suman hasta 100.

const toArray = (value) => (value == null ? [] : Array.isArray(value) ? value : [value]);

export function parsePattern(raw) {
  const [source, ...attrs] = String(raw).split('\\;');
  const pattern = { source, regex: null, version: '', confidence: 100 };

  try {
    pattern.regex = new RegExp(source, 'i');
  } catch {
    pattern.invalid = true;
  }

  for (const attr of attrs) {
    const sep = attr.indexOf(':');
    if (sep < 0) continue;
    const key = attr.slice(0, sep);
    const value = attr.slice(sep + 1);
    if (key === 'version') pattern.version = value;
    else if (key === 'confidence') pattern.confidence = Number(value) || 0;
  }

  return pattern;
}

const EXISTS = parsePattern('');

const parseList = (value) => toArray(value).map(parsePattern);

const parseMap = (obj, lowerKeys) =>
  Object.entries(obj || {}).map(([key, value]) => ({
    key: lowerKeys ? key.toLowerCase() : key,
    patterns: parseList(value),
  }));

// "dom" admite una lista de selectores (basta con que existan) o un objeto
// { selector: { exists: "", attributes: { nombre: patrón }, text: patrón } }.
function parseDom(dom) {
  if (!dom) return [];
  if (typeof dom === 'string' || Array.isArray(dom)) {
    return toArray(dom).map((selector) => ({ selector, exists: true, attributes: [], text: null }));
  }
  return Object.entries(dom).map(([selector, spec]) => {
    const attributes = parseMap(spec.attributes, false);
    const text = spec.text != null ? parsePattern(spec.text) : null;
    const exists = 'exists' in spec || (!attributes.length && !text);
    return { selector, exists, attributes, text };
  });
}

export function prepare(db) {
  const technologies = Object.entries(db.technologies).map(([name, t]) => ({
    name,
    cats: toArray(t.cats),
    icon: t.icon || '',
    website: t.website || '',
    description: t.description || '',
    url: parseList(t.url),
    html: parseList(t.html),
    scripts: parseList(t.scripts),
    resources: parseList(t.resources),
    css: parseList(t.css),
    headers: parseMap(t.headers, true),
    cookies: parseMap(t.cookies, false),
    meta: parseMap(t.meta, true),
    js: parseMap(t.js, false),
    dom: parseDom(t.dom),
    domProps: toArray(t.domProps),
    implies: parseList(t.implies),
    excludes: toArray(t.excludes),
    versionNote: t.versionNote || '',
    noVersionNote: t.noVersionNote || '',
    versionLabels: t.versionLabels || null,
  }));

  return { categories: db.categories, technologies, byName: new Map(technologies.map((t) => [t.name, t])) };
}

// Lo que hay que pedirle a la página: rutas JS, prefijos de propiedades del DOM y selectores.
export function buildQueries(prepared) {
  const js = new Set();
  const domProps = new Set();
  const dom = new Map();

  for (const tech of prepared.technologies) {
    tech.js.forEach(({ key }) => js.add(key));
    tech.domProps.forEach((prefix) => domProps.add(prefix));
    for (const rule of tech.dom) {
      const query = dom.get(rule.selector) || { selector: rule.selector, attributes: [], text: false };
      for (const { key } of rule.attributes) if (!query.attributes.includes(key)) query.attributes.push(key);
      if (rule.text) query.text = true;
      dom.set(rule.selector, query);
    }
  }

  return { js: [...js], domProps: [...domProps], dom: [...dom.values()] };
}

const EVIDENCE_LABELS = {
  url: 'URL',
  html: 'HTML',
  scripts: 'scripts',
  resources: 'recursos cargados',
  css: 'CSS',
  headers: 'cabeceras HTTP',
  cookies: 'cookies',
  meta: 'etiquetas meta',
  js: 'variables JS',
  dom: 'DOM',
  domProps: 'DOM',
};

// data = { url, html, css, scripts[], resources[], headers{nombre:[valores]}, cookies{nombre:valor},
//          meta{nombre:[valores]}, js{ruta:valor}, dom{selector:{attributes,text}}, domProps[] }
export function analyze(prepared, data) {
  const found = new Map();

  const hit = (tech, type, pattern, value) => {
    if (!pattern.regex || value == null) return;
    const match = pattern.regex.exec(String(value));
    if (!match) return;

    let entry = found.get(tech.name);
    if (!entry) found.set(tech.name, (entry = { confidence: 0, versions: [], evidence: new Set(), implied: false }));
    entry.confidence = Math.min(100, entry.confidence + pattern.confidence);
    entry.evidence.add(EVIDENCE_LABELS[type]);
    entry.implied = false;

    if (pattern.version) {
      const version = pattern.version.replace(/\\(\d)/g, (_, i) => match[i] ?? '').trim();
      if (version) entry.versions.push(version);
    }
  };

  const headers = data.headers || {};
  const cookies = data.cookies || {};
  const cookieNames = Object.keys(cookies);
  const meta = data.meta || {};
  const js = data.js || {};
  const dom = data.dom || {};
  const props = new Set(data.domProps || []);

  for (const tech of prepared.technologies) {
    tech.url.forEach((p) => hit(tech, 'url', p, data.url));
    tech.html.forEach((p) => hit(tech, 'html', p, data.html));
    tech.css.forEach((p) => hit(tech, 'css', p, data.css));
    for (const p of tech.scripts) {
      for (const src of data.scripts || []) hit(tech, 'scripts', p, src);
    }
    for (const p of tech.resources) {
      for (const href of data.resources || []) hit(tech, 'resources', p, href);
    }

    for (const { key, patterns } of tech.headers) {
      for (const value of headers[key] || []) patterns.forEach((p) => hit(tech, 'headers', p, value));
    }

    for (const { key, patterns } of tech.cookies) {
      // Un nombre terminado en * es un prefijo (p. ej. "wordpress_logged_in_*").
      const names = key.endsWith('*')
        ? cookieNames.filter((n) => n.startsWith(key.slice(0, -1)))
        : key in cookies ? [key] : [];
      for (const name of names) patterns.forEach((p) => hit(tech, 'cookies', p, cookies[name]));
    }

    for (const { key, patterns } of tech.meta) {
      for (const value of meta[key] || []) patterns.forEach((p) => hit(tech, 'meta', p, value));
    }

    for (const { key, patterns } of tech.js) {
      if (key in js) patterns.forEach((p) => hit(tech, 'js', p, js[key]));
    }

    for (const rule of tech.dom) {
      const result = dom[rule.selector];
      if (!result) continue;
      if (rule.exists) hit(tech, 'dom', EXISTS, '');
      for (const { key, patterns } of rule.attributes) {
        const value = result.attributes?.[key];
        if (value != null) patterns.forEach((p) => hit(tech, 'dom', p, value));
      }
      if (rule.text && result.text != null) hit(tech, 'dom', rule.text, result.text);
    }

    if (tech.domProps.some((prefix) => props.has(prefix))) hit(tech, 'domProps', EXISTS, '');
  }

  resolveImplies(prepared, found);

  for (const [name] of found) {
    for (const excluded of prepared.byName.get(name).excludes) found.delete(excluded);
  }

  return formatResults(prepared, found);
}

// Aclaración que acompaña a la versión (o a su ausencia). En versionNote, {version} es la versión
// detectada y {label} su nombre según versionLabels, cuyas claves son prefijos ("1.8" → "1.8.0_181").
function versionNote(tech, version) {
  if (!version) return tech.noVersionNote;
  if (!tech.versionNote) return '';
  const key = tech.versionLabels && Object.keys(tech.versionLabels).find((k) => version === k || (version.startsWith(k) && /^[._]/.test(version.slice(k.length))));
  if (tech.versionNote.includes('{label}') && !key) return '';
  return tech.versionNote.replaceAll('{version}', version).replaceAll('{label}', key ? tech.versionLabels[key] : '');
}

// Si se detecta WordPress, "implies" añade PHP y MySQL aunque no haya evidencia directa.
function resolveImplies(prepared, found) {
  let changed = true;
  while (changed) {
    changed = false;
    for (const [name, entry] of found) {
      for (const implied of prepared.byName.get(name).implies) {
        if (found.has(implied.source) || !prepared.byName.has(implied.source)) continue;
        found.set(implied.source, {
          confidence: Math.round((entry.confidence * implied.confidence) / 100),
          versions: [],
          evidence: new Set([`implícito por ${name}`]),
          implied: true,
        });
        changed = true;
      }
    }
  }
}

function formatResults(prepared, found) {
  const { categories } = prepared;
  const priority = (tech) => Math.min(...tech.cats.map((id) => categories[id]?.priority ?? 99));

  return [...found]
    .filter(([, entry]) => entry.confidence > 0)
    .map(([name, entry]) => {
      const tech = prepared.byName.get(name);
      // La versión más específica es la que tiene más caracteres (6.4.2 frente a 6.4).
      const version = entry.versions.sort((a, b) => b.length - a.length)[0] || '';
      return {
        name,
        version,
        confidence: entry.confidence,
        implied: entry.implied,
        evidence: [...entry.evidence],
        categories: tech.cats.map((id) => ({ id, name: categories[id]?.name || 'Otros', priority: categories[id]?.priority ?? 99 })),
        icon: tech.icon,
        website: tech.website,
        description: tech.description,
        note: versionNote(tech, version),
        priority: priority(tech),
      };
    })
    .sort((a, b) => a.priority - b.priority || a.name.localeCompare(b.name));
}
