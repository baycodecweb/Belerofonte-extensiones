// Se ejecuta (mundo MAIN, al empezar a cargar) en los marcos del simulador de dispositivos.
// Solo está registrado mientras hay un simulador abierto y no hace nada fuera de él: el marco del
// simulador se reconoce por su nombre (window.name), que lleva los datos del dispositivo.
(() => {
  const PREFIX = '__belerofonte_sim:';
  if (window === window.top || !window.name.startsWith(PREFIX)) return;
  let device;
  try {
    device = JSON.parse(window.name.slice(PREFIX.length));
  } catch {
    return;
  }

  const define = (target, prop, value) => {
    try {
      Object.defineProperty(target, prop, { get: () => value, configurable: true });
    } catch {}
  };

  if (device.ua) {
    define(Navigator.prototype, 'userAgent', device.ua);
    define(Navigator.prototype, 'appVersion', device.ua.replace(/^Mozilla\//, ''));
    define(Navigator.prototype, 'vendor', /Safari\/6/.test(device.ua) && !/Chrome/.test(device.ua) ? 'Apple Computer, Inc.' : 'Google Inc.');
  }
  if (device.platform) define(Navigator.prototype, 'platform', device.platform);
  if (device.ios) define(Navigator.prototype, 'userAgentData', undefined); // Safari no tiene Client Hints
  define(Navigator.prototype, 'maxTouchPoints', device.touch ? 5 : 0);
  if (device.touch && !('ontouchstart' in window)) window.ontouchstart = null;

  define(window, 'devicePixelRatio', device.dpr);
  for (const [prop, value] of [['width', device.width], ['height', device.height], ['availWidth', device.width], ['availHeight', device.height]]) {
    define(Screen.prototype, prop, value);
  }

  // Los móviles no tienen barras de desplazamiento que ocupen sitio.
  if (device.touch) {
    const style = document.createElement('style');
    style.textContent = '::-webkit-scrollbar { width: 0 !important; height: 0 !important; }';
    (document.head || document.documentElement).append(style);
  }

  // Desplazamiento sincronizado entre vistas: se avisa al simulador de la posición (como
  // proporción, porque cada dispositivo tiene un alto de página distinto) y se aplica la que
  // llega de otra vista.
  const KEY = '__belerofonteSim';
  const maxScroll = () => Math.max(0, document.documentElement.scrollHeight - window.innerHeight);
  let applying = false;
  let pending = false;
  window.addEventListener('scroll', () => {
    if (applying || pending) return;
    pending = true;
    requestAnimationFrame(() => {
      pending = false;
      const max = maxScroll();
      window.parent.postMessage({ [KEY]: 'scroll', ratio: max ? window.scrollY / max : 0 }, '*');
    });
  }, { passive: true });
  window.addEventListener('message', (event) => {
    if (event.source !== window.parent || event.data?.[KEY] !== 'scroll-to') return;
    applying = true;
    window.scrollTo({ top: event.data.ratio * maxScroll(), behavior: 'instant' });
    setTimeout(() => (applying = false), 120);
  });
})();
