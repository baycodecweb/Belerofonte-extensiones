// Dispositivos del simulador: tamaño de la ventana del navegador en px CSS (vertical), densidad de
// píxeles (DPR), sistema y tipo de marco. Son valores aproximados según las especificaciones
// públicas de cada modelo.
//
// os: 'ios' (iPhone), 'ipados' (iPad: Safari se presenta como Mac), 'android', 'android-tablet',
//     'desktop' (sin cambiar el User-Agent), 'watchos'.
// frame: 'island' (Dynamic Island), 'notch', 'home' (botón de inicio), 'punch' (cámara perforada),
//        'fold', 'tablet', 'laptop', 'monitor', 'watch', 'watch-round'.

const d = (name, width, height, dpr, os, frame, extra = {}) => ({ name, width, height, dpr, os, frame, ...extra });

export const CATEGORIES = [
  {
    name: 'iPhone',
    devices: [
      d('iPhone 17 Pro Max', 440, 956, 3, 'ios', 'island', { ios: '26.0' }),
      d('iPhone 17 Pro', 402, 874, 3, 'ios', 'island', { ios: '26.0' }),
      d('iPhone 17', 402, 874, 3, 'ios', 'island', { ios: '26.0' }),
      d('iPhone Air', 420, 912, 3, 'ios', 'island', { ios: '26.0' }),
      d('iPhone 16 Pro Max', 440, 956, 3, 'ios', 'island', { ios: '18.6' }),
      d('iPhone 16 Pro', 402, 874, 3, 'ios', 'island', { ios: '18.6' }),
      d('iPhone 16 Plus', 430, 932, 3, 'ios', 'island', { ios: '18.6' }),
      d('iPhone 16', 393, 852, 3, 'ios', 'island', { ios: '18.6' }),
      d('iPhone 16e', 390, 844, 3, 'ios', 'notch', { ios: '18.6' }),
      d('iPhone 15 Pro Max', 430, 932, 3, 'ios', 'island', { ios: '18.6' }),
      d('iPhone 15 Pro', 393, 852, 3, 'ios', 'island', { ios: '18.6' }),
      d('iPhone 15 Plus', 430, 932, 3, 'ios', 'island', { ios: '18.6' }),
      d('iPhone 15', 393, 852, 3, 'ios', 'island', { ios: '18.6' }),
      d('iPhone 14 Pro Max', 430, 932, 3, 'ios', 'island', { ios: '18.6' }),
      d('iPhone 14 Pro', 393, 852, 3, 'ios', 'island', { ios: '18.6' }),
      d('iPhone 14 Plus', 428, 926, 3, 'ios', 'notch', { ios: '18.6' }),
      d('iPhone 14', 390, 844, 3, 'ios', 'notch', { ios: '18.6' }),
      d('iPhone 13 Pro Max', 428, 926, 3, 'ios', 'notch', { ios: '18.6' }),
      d('iPhone 13 Pro', 390, 844, 3, 'ios', 'notch', { ios: '18.6' }),
      d('iPhone 13', 390, 844, 3, 'ios', 'notch', { ios: '18.6' }),
      d('iPhone 13 mini', 375, 812, 3, 'ios', 'notch', { ios: '18.6' }),
      d('iPhone 12 Pro Max', 428, 926, 3, 'ios', 'notch', { ios: '18.6' }),
      d('iPhone 12 Pro', 390, 844, 3, 'ios', 'notch', { ios: '18.6' }),
      d('iPhone 12', 390, 844, 3, 'ios', 'notch', { ios: '18.6' }),
      d('iPhone 12 mini', 375, 812, 3, 'ios', 'notch', { ios: '18.6' }),
      d('iPhone 11 Pro Max', 414, 896, 3, 'ios', 'notch', { ios: '18.6' }),
      d('iPhone 11 Pro', 375, 812, 3, 'ios', 'notch', { ios: '18.6' }),
      d('iPhone 11', 414, 896, 2, 'ios', 'notch', { ios: '18.6' }),
      d('iPhone XR', 414, 896, 2, 'ios', 'notch', { ios: '18.6' }),
      d('iPhone XS Max', 414, 896, 3, 'ios', 'notch', { ios: '18.6' }),
      d('iPhone X / XS', 375, 812, 3, 'ios', 'notch', { ios: '16.7' }),
      d('iPhone SE (2.ª / 3.ª gen.)', 375, 667, 2, 'ios', 'home', { ios: '18.6' }),
      d('iPhone 8 Plus', 414, 736, 3, 'ios', 'home', { ios: '16.7' }),
      d('iPhone 8', 375, 667, 2, 'ios', 'home', { ios: '16.7' }),
      d('iPhone SE (1.ª gen.)', 320, 568, 2, 'ios', 'home', { ios: '15.8' }),
    ],
  },
  {
    name: 'Android',
    devices: [
      d('Google Pixel 9 Pro XL', 448, 998, 3, 'android', 'punch'),
      d('Google Pixel 9 Pro', 410, 914, 3, 'android', 'punch'),
      d('Google Pixel 9', 412, 923, 2.625, 'android', 'punch'),
      d('Google Pixel 8 Pro', 448, 998, 3, 'android', 'punch'),
      d('Google Pixel 8', 412, 915, 2.625, 'android', 'punch'),
      d('Google Pixel 8a', 412, 915, 2.625, 'android', 'punch'),
      d('Google Pixel 7 Pro', 412, 892, 3.5, 'android', 'punch'),
      d('Google Pixel 7', 412, 915, 2.625, 'android', 'punch'),
      d('Google Pixel 6', 412, 915, 2.625, 'android', 'punch'),
      d('Google Pixel 5', 393, 851, 2.75, 'android', 'punch'),
      d('Google Pixel 4a', 393, 851, 2.75, 'android', 'punch'),
      d('Google Pixel 3', 393, 786, 2.75, 'android', 'punch'),
      d('Samsung Galaxy S25 Ultra', 412, 891, 3.5, 'android', 'punch'),
      d('Samsung Galaxy S25+', 384, 832, 3.75, 'android', 'punch'),
      d('Samsung Galaxy S25', 360, 780, 3, 'android', 'punch'),
      d('Samsung Galaxy S24 Ultra', 384, 832, 3.75, 'android', 'punch'),
      d('Samsung Galaxy S24', 360, 780, 3, 'android', 'punch'),
      d('Samsung Galaxy S23 Ultra', 384, 824, 3.75, 'android', 'punch'),
      d('Samsung Galaxy S23', 360, 780, 3, 'android', 'punch'),
      d('Samsung Galaxy S22 Ultra', 384, 824, 3.75, 'android', 'punch'),
      d('Samsung Galaxy S22', 360, 780, 3, 'android', 'punch'),
      d('Samsung Galaxy S21 Ultra', 384, 854, 3.75, 'android', 'punch'),
      d('Samsung Galaxy S21', 360, 800, 3, 'android', 'punch'),
      d('Samsung Galaxy S20 Ultra', 412, 915, 3.5, 'android', 'punch'),
      d('Samsung Galaxy S20', 360, 800, 4, 'android', 'punch'),
      d('Samsung Galaxy S10', 360, 760, 4, 'android', 'punch'),
      d('Samsung Galaxy S9', 360, 740, 4, 'android', 'punch'),
      d('Samsung Galaxy S8', 360, 740, 4, 'android', 'punch'),
      d('Samsung Galaxy Note 20 Ultra', 412, 883, 3.5, 'android', 'punch'),
      d('Samsung Galaxy Note 10', 412, 869, 2.625, 'android', 'punch'),
      d('Samsung Galaxy A55', 384, 854, 2.8125, 'android', 'punch'),
      d('Samsung Galaxy A54', 384, 854, 2.8125, 'android', 'punch'),
      d('Samsung Galaxy A35', 384, 854, 2.8125, 'android', 'punch'),
      d('Samsung Galaxy A51 / A71', 412, 914, 2.625, 'android', 'punch'),
      d('Xiaomi 14', 393, 873, 3, 'android', 'punch'),
      d('Xiaomi Redmi Note 13 Pro', 393, 873, 2.75, 'android', 'punch'),
      d('Xiaomi Redmi Note 12', 393, 873, 2.75, 'android', 'punch'),
      d('Xiaomi Redmi Note 8 Pro', 393, 851, 2.75, 'android', 'punch'),
      d('Xiaomi POCO X6 Pro', 393, 873, 2.75, 'android', 'punch'),
      d('OnePlus 12', 412, 915, 3.5, 'android', 'punch'),
      d('OnePlus 9 Pro', 412, 919, 3.5, 'android', 'punch'),
      d('OnePlus Nord 4', 412, 915, 2.625, 'android', 'punch'),
      d('Motorola Edge 50 Pro', 412, 915, 2.625, 'android', 'punch'),
      d('Motorola Moto G Power', 412, 823, 1.75, 'android', 'punch'),
      d('Motorola Moto G4', 360, 640, 3, 'android', 'home'),
      d('Huawei P30 Pro', 360, 780, 3, 'android', 'punch'),
      d('Huawei Mate 20 Pro', 360, 780, 4, 'android', 'punch'),
      d('Sony Xperia 1 VI', 384, 854, 2.8125, 'android', 'punch'),
      d('Sony Xperia 10 V', 360, 840, 3, 'android', 'punch'),
      d('Nothing Phone (2)', 412, 915, 2.625, 'android', 'punch'),
      d('Nokia G42', 360, 800, 2, 'android', 'punch'),
    ],
  },
  {
    name: 'Plegables',
    devices: [
      d('Samsung Galaxy Z Fold 6 (cerrado)', 344, 882, 3, 'android', 'punch'),
      d('Samsung Galaxy Z Fold 6 (abierto)', 768, 904, 2.625, 'android-tablet', 'fold'),
      d('Samsung Galaxy Z Flip 6', 412, 1004, 2.625, 'android', 'punch'),
      d('Google Pixel 9 Pro Fold (abierto)', 768, 768, 2.625, 'android-tablet', 'fold'),
      d('Microsoft Surface Duo', 540, 720, 2.5, 'android', 'punch'),
    ],
  },
  {
    name: 'Tablets',
    devices: [
      d('iPad Pro 13" (M4)', 1032, 1376, 2, 'ipados', 'tablet', { ios: '18.6' }),
      d('iPad Pro 12.9"', 1024, 1366, 2, 'ipados', 'tablet', { ios: '18.6' }),
      d('iPad Pro 11"', 834, 1194, 2, 'ipados', 'tablet', { ios: '18.6' }),
      d('iPad Air 13" (M2)', 1024, 1366, 2, 'ipados', 'tablet', { ios: '18.6' }),
      d('iPad Air 11" (M2)', 820, 1180, 2, 'ipados', 'tablet', { ios: '18.6' }),
      d('iPad (10.ª gen.)', 820, 1180, 2, 'ipados', 'tablet', { ios: '18.6' }),
      d('iPad (9.ª gen.)', 810, 1080, 2, 'ipados', 'tablet', { ios: '18.6' }),
      d('iPad mini (6.ª gen.)', 744, 1133, 2, 'ipados', 'tablet', { ios: '18.6' }),
      d('iPad mini 4', 768, 1024, 2, 'ipados', 'tablet', { ios: '15.8' }),
      d('Samsung Galaxy Tab S9 Ultra', 924, 1480, 2, 'android-tablet', 'tablet'),
      d('Samsung Galaxy Tab S9', 800, 1280, 2, 'android-tablet', 'tablet'),
      d('Samsung Galaxy Tab A9+', 800, 1334, 1.5, 'android-tablet', 'tablet'),
      d('Google Pixel Tablet', 800, 1280, 2, 'android-tablet', 'tablet'),
      d('Lenovo Tab P12', 860, 1376, 2, 'android-tablet', 'tablet'),
      d('Amazon Fire HD 10', 800, 1280, 1.5, 'android-tablet', 'tablet'),
      d('Google Nexus 7', 600, 960, 2, 'android-tablet', 'tablet'),
      d('Microsoft Surface Pro 9', 912, 1368, 2, 'desktop', 'tablet'),
    ],
  },
  {
    name: 'Portátiles y monitores',
    devices: [
      d('MacBook Air 13" (M2/M3)', 1470, 956, 2, 'desktop', 'laptop', { landscape: true }),
      d('MacBook Air 15"', 1710, 1112, 2, 'desktop', 'laptop', { landscape: true }),
      d('MacBook Pro 14"', 1512, 982, 2, 'desktop', 'laptop', { landscape: true }),
      d('MacBook Pro 16"', 1728, 1117, 2, 'desktop', 'laptop', { landscape: true }),
      d('Portátil HD (1366 × 768)', 1366, 768, 1, 'desktop', 'laptop', { landscape: true }),
      d('Portátil (1440 × 900)', 1440, 900, 1, 'desktop', 'laptop', { landscape: true }),
      d('Portátil Full HD al 125 %', 1536, 864, 1.25, 'desktop', 'laptop', { landscape: true }),
      d('Microsoft Surface Laptop', 1440, 960, 1.5, 'desktop', 'laptop', { landscape: true }),
      d('Monitor Full HD', 1920, 1080, 1, 'desktop', 'monitor', { landscape: true }),
      d('Monitor 2K (QHD)', 2560, 1440, 1, 'desktop', 'monitor', { landscape: true }),
      d('Monitor 4K al 150 %', 2560, 1440, 1.5, 'desktop', 'monitor', { landscape: true }),
      d('iMac 24"', 2240, 1260, 2, 'desktop', 'monitor', { landscape: true }),
      d('Smart TV 1080p', 1920, 1080, 1, 'desktop', 'monitor', { landscape: true }),
    ],
  },
  {
    name: 'Relojes',
    devices: [
      d('Apple Watch Ultra 2', 205, 251, 2, 'watchos', 'watch', { ios: '18.6' }),
      d('Apple Watch Series 10 (46 mm)', 208, 248, 2, 'watchos', 'watch', { ios: '18.6' }),
      d('Samsung Galaxy Watch 7 (44 mm)', 240, 240, 2, 'android', 'watch-round'),
    ],
  },
];

export const DEVICES = CATEGORIES.flatMap((c) => c.devices.map((device) => ({ ...device, category: c.name })));

// User-Agent de cada sistema. Los de Android usan el formato reducido que envía Chrome hoy
// ("Android 10; K"); los iPad se presentan como Mac, igual que Safari en iPadOS.
export function userAgent(device, chromeMajor) {
  const ios = (device.ios || '18.6').replace('.', '_');
  const safari = device.ios || '18.6';
  switch (device.os) {
    case 'ios':
    case 'watchos':
      return `Mozilla/5.0 (iPhone; CPU iPhone OS ${ios} like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/${safari} Mobile/15E148 Safari/604.1`;
    case 'ipados':
      return `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/${safari} Safari/605.1.15`;
    case 'android':
      return `Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${chromeMajor}.0.0.0 Mobile Safari/537.36`;
    case 'android-tablet':
      return `Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${chromeMajor}.0.0.0 Safari/537.36`;
    default:
      return null; // escritorio: se deja el del navegador
  }
}

// Lo que ven los scripts de la página (navigator.platform, pantalla táctil) y las cabeceras
// Client Hints que envía Chrome.
export function profile(device, chromeMajor) {
  const ua = userAgent(device, chromeMajor);
  const touch = device.os !== 'desktop' || device.frame === 'tablet';
  const platform = { ios: 'iPhone', watchos: 'iPhone', ipados: 'MacIntel', android: 'Linux armv81', 'android-tablet': 'Linux armv81' }[device.os] || null;
  const hintPlatform = { android: 'Android', 'android-tablet': 'Android', ios: 'iOS', watchos: 'iOS', ipados: 'macOS' }[device.os] || null;
  return { ua, touch, platform, mobile: ['ios', 'watchos', 'android'].includes(device.os), hintPlatform };
}
