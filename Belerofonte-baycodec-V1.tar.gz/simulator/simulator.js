// Simulador de dispositivos: muestra un sitio en una o varias vistas (hasta MAX_VIEWS) con el
// tamaño, la densidad de píxeles y el User-Agent de cada dispositivo, para compararlos.
// El service worker (simulator.js de la raíz) prepara las cabeceras de esta pestaña;
// simulator/frame.js ajusta lo que ven los scripts del sitio y sincroniza el desplazamiento.

import { CATEGORIES, DEVICES, profile } from './devices.js';

const PREFIX = '__belerofonte_sim:';
const MESSAGE_KEY = '__belerofonteSim';
const STORE_KEY = 'simulator';
const MAX_VIEWS = 6;
const DEFAULT_DEVICE = 'iPhone 16';
const OS_LABEL = {
  ios: 'iOS',
  ipados: 'iPadOS',
  watchos: 'watchOS',
  android: 'Android',
  'android-tablet': 'Android',
  desktop: 'escritorio (User-Agent de tu navegador)',
};
// Espacio extra que ocupan la base del portátil o el pie del monitor (px sin escalar).
const BASE_EXTRA = { laptop: 18, monitor: 70 };
const PRESETS = [
  { name: 'Móvil · Tablet · Escritorio', devices: ['iPhone 16', 'iPad Air 11" (M2)', 'MacBook Air 13" (M2/M3)'] },
  { name: 'iPhone vs Android', devices: ['iPhone 16', 'Samsung Galaxy S24', 'Google Pixel 9'] },
  { name: 'Tamaños de iPhone', devices: ['iPhone SE (2.ª / 3.ª gen.)', 'iPhone 16', 'iPhone 16 Pro Max'] },
  { name: 'Móviles pequeños y grandes', devices: ['iPhone SE (1.ª gen.)', 'Samsung Galaxy S24', 'Google Pixel 9 Pro XL'] },
  { name: 'Tablets', devices: ['iPad mini (6.ª gen.)', 'iPad Pro 11"', 'Samsung Galaxy Tab S9'] },
  { name: 'Portátiles y monitores', devices: ['Portátil HD (1366 × 768)', 'MacBook Pro 14"', 'Monitor Full HD'] },
  { name: 'Plegable cerrado y abierto', devices: ['Samsung Galaxy Z Fold 6 (cerrado)', 'Samsung Galaxy Z Fold 6 (abierto)'] },
];

const $ = (id) => document.getElementById(id);
const search = $('search');
const select = $('device');
const rotateBtn = $('rotate');
const zoomSelect = $('zoom');
const frameCheck = $('frame');
const addBtn = $('add-view');
const presetSelect = $('preset');
const syncCheck = $('sync');
const countEl = $('views-count');
const form = $('address');
const urlInput = $('url');
const statusEl = $('status');
const noteEl = $('note');
const stage = $('stage');
const viewsEl = $('views');
const emptyEl = $('empty');

const chromeMajor = navigator.userAgent.match(/Chrome\/(\d+)/)?.[1] || '140';
let currentUrl = new URLSearchParams(location.search).get('url') || '';
let myTabId = null;
chrome.tabs.getCurrent().then((tab) => (myTabId = tab?.id ?? null));

// Preferencias de este navegador. Formato anterior ({ device, landscape }) → una sola vista.
const state = { views: [], active: 0, zoom: 'fit', frame: true, sync: true };
try {
  const saved = JSON.parse(localStorage.getItem(STORE_KEY) || '{}');
  Object.assign(state, saved);
  if (!Array.isArray(saved.views) && saved.device) state.views = [{ device: saved.device, landscape: Boolean(saved.landscape) }];
} catch {}
state.views = state.views.filter((v) => DEVICES.some((d) => d.name === v.device)).slice(0, MAX_VIEWS);
if (!state.views.length) state.views = [{ device: DEFAULT_DEVICE, landscape: false }];
state.active = Math.min(Math.max(0, state.active), state.views.length - 1);
const save = () => {
  try {
    localStorage.setItem(STORE_KEY, JSON.stringify({ views: state.views, active: state.active, zoom: state.zoom, frame: state.frame, sync: state.sync }));
  } catch {}
};

const normalize = (text) => text.normalize('NFD').replace(/\p{Diacritic}/gu, '').toLowerCase();
const deviceByName = (name) => DEVICES.find((d) => d.name === name) || DEVICES.find((d) => d.name === DEFAULT_DEVICE);
const canRotate = (device) => !['laptop', 'monitor', 'watch', 'watch-round'].includes(device.frame);
const activeView = () => state.views[state.active];

function screenSize(view) {
  const device = deviceByName(view.device);
  const rotated = view.landscape && canRotate(device);
  return rotated ? { device, w: device.height, h: device.width, rotated } : { device, w: device.width, h: device.height, rotated };
}

function normalizeUrl(text) {
  const value = text.trim();
  if (!value) return '';
  return /^[a-z][\w+.-]*:/i.test(value) ? value : `https://${value}`;
}

// --- Selector de dispositivo (actúa sobre la vista activa) ------------------------------------

function fillSelect(filter = '') {
  const query = normalize(filter.trim());
  const groups = CATEGORIES.map((category) => {
    const devices = category.devices.filter((d) => !query || normalize(`${d.name} ${category.name}`).includes(query));
    if (!devices.length) return null;
    const group = document.createElement('optgroup');
    group.label = `${category.name} (${devices.length})`;
    group.append(...devices.map((d) => new Option(`${d.name} · ${d.width}×${d.height}`, d.name)));
    return group;
  }).filter(Boolean);
  select.replaceChildren(...groups);
  if (!groups.length) select.append(new Option('Ningún dispositivo coincide', ''));
  syncToolbar();
}

function syncToolbar() {
  const view = activeView();
  if ([...select.options].some((o) => o.value === view.device)) select.value = view.device;
  rotateBtn.disabled = !canRotate(deviceByName(view.device));
  zoomSelect.value = state.zoom;
  frameCheck.checked = state.frame;
  syncCheck.checked = state.sync;
  addBtn.disabled = state.views.length >= MAX_VIEWS;
  countEl.textContent = state.views.length > 1 ? `${state.views.length} vistas · máximo ${MAX_VIEWS}` : '';
}

// --- Vistas -----------------------------------------------------------------------------------

// Cada vista: { el, frameEl, screenEl, iframe, key } (key = qué cargó, para no recargar sin motivo).
let rendered = [];

function frameName(view) {
  const { device, w, h } = screenSize(view);
  const prof = profile(device, chromeMajor);
  return PREFIX + JSON.stringify({
    ua: prof.ua,
    platform: prof.platform,
    touch: prof.touch,
    dpr: device.dpr,
    width: w,
    height: h,
    ios: ['ios', 'ipados', 'watchos'].includes(device.os),
  });
}

function buildView(index) {
  const el = document.createElement('div');
  el.className = 'sim-view';
  el.innerHTML = `
    <div class="sim-view__bar" title="Haz clic para elegir esta vista">
      <span class="sim-view__name"></span><span class="sim-view__size"></span>
      <span class="sim-view__spacer"></span>
      <button class="sim-mini" data-action="rotate" title="Girar esta vista">⟳</button>
      <button class="sim-mini" data-action="remove" title="Quitar esta vista">✕</button>
    </div>
    <div class="sim-scaler">
      <div class="sim-frame"><div class="sim-screen"></div><div class="sim-cutout"></div><div class="sim-base"></div></div>
    </div>`;
  el.addEventListener('click', (event) => {
    const action = event.target.closest('[data-action]')?.dataset.action;
    const i = rendered.findIndex((r) => r.el === el);
    if (action === 'remove') return removeView(i);
    if (action === 'rotate') {
      state.views[i].landscape = !state.views[i].landscape;
      state.active = i;
      save();
      return render();
    }
    if (event.target.closest('.sim-view__bar') && state.active !== i) {
      state.active = i;
      save();
      updateChrome();
    }
  });
  return { el, scaler: el.querySelector('.sim-scaler'), frameEl: el.querySelector('.sim-frame'), screenEl: el.querySelector('.sim-screen'), iframe: null, key: '' };
}

function render() {
  while (rendered.length < state.views.length) {
    const view = buildView(rendered.length);
    viewsEl.append(view.el);
    rendered.push(view);
  }
  while (rendered.length > state.views.length) rendered.pop().el.remove();

  emptyEl.hidden = Boolean(currentUrl);
  viewsEl.hidden = !currentUrl;

  state.views.forEach((view, i) => {
    const r = rendered[i];
    const { device, w, h, rotated } = screenSize(view);
    r.frameEl.className = `sim-frame ${device.frame}${rotated ? ' landscape' : ''}${state.frame ? '' : ' bare'}`;
    r.screenEl.style.width = `${w}px`;
    r.screenEl.style.height = `${h}px`;
    r.el.querySelector('.sim-view__name').textContent = device.name;
    r.el.querySelector('.sim-view__size').textContent = `${w}×${h}`;
    r.el.querySelector('[data-action="rotate"]').disabled = !canRotate(device);
    r.el.querySelector('[data-action="remove"]').disabled = state.views.length === 1;

    // Un marco nuevo solo si cambian el dispositivo, la orientación o la dirección.
    const key = `${frameName(view)}|${currentUrl}`;
    if (!currentUrl) {
      r.screenEl.replaceChildren();
      r.iframe = null;
      r.key = '';
    } else if (key !== r.key) {
      const iframe = document.createElement('iframe');
      iframe.name = frameName(view);
      iframe.width = String(w);
      iframe.height = String(h);
      // Sin allow-top-navigation: el sitio no puede "escaparse" del marco y sustituir al simulador.
      iframe.setAttribute('sandbox', 'allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-modals allow-downloads allow-presentation');
      iframe.allow = 'autoplay; fullscreen; clipboard-write; encrypted-media; picture-in-picture; web-share';
      r.screenEl.replaceChildren(iframe);
      r.iframe = iframe;
      r.key = key;
      // La dirección se asigna cuando el marco ya tiene tamaño: si no, en una vista recién creada
      // el sitio puede empezar a cargar con innerWidth = 0.
      const url = currentUrl;
      requestAnimationFrame(() => requestAnimationFrame(() => {
        if (r.iframe === iframe) iframe.src = url;
      }));
    }
  });
  updateChrome();
}

// Todo lo que no recarga los marcos: vista activa, barra superior, escala y avisos.
function updateChrome() {
  rendered.forEach((r, i) => r.el.classList.toggle('active', i === state.active && state.views.length > 1));
  syncToolbar();
  fit();
  updateNote();
}

// Escala común para que todas las vistas quepan juntas (o el zoom elegido).
function fit() {
  if (!currentUrl) return;
  const sizes = rendered.map((r, i) => {
    const device = screenSize(state.views[i]).device;
    return { w: r.frameEl.offsetWidth, h: r.frameEl.offsetHeight + (state.frame ? BASE_EXTRA[device.frame] || 0 : 0) };
  });
  const styles = getComputedStyle(stage);
  const gap = parseFloat(getComputedStyle(viewsEl).columnGap) || 0;
  const barH = (rendered[0]?.el.querySelector('.sim-view__bar').offsetHeight || 0) + 10;
  const availW = stage.clientWidth - parseFloat(styles.paddingLeft) - parseFloat(styles.paddingRight) - gap * (sizes.length - 1);
  const availH = stage.clientHeight - parseFloat(styles.paddingTop) - parseFloat(styles.paddingBottom) - barH;
  const totalW = sizes.reduce((sum, s) => sum + s.w, 0);
  const maxH = Math.max(...sizes.map((s) => s.h));
  const scale = state.zoom === 'fit' ? Math.min(1, availW / totalW, availH / maxH) : Number(state.zoom);

  rendered.forEach((r, i) => {
    r.frameEl.style.transform = `scale(${scale})`;
    r.scaler.style.width = `${sizes[i].w * scale}px`;
    r.scaler.style.height = `${sizes[i].h * scale}px`;
    r.el.style.width = `${Math.max(sizes[i].w * scale, 200)}px`;
  });
  updateStatus(scale);
}

function updateStatus(scale) {
  const { device, w, h, rotated } = screenSize(activeView());
  statusEl.textContent = [
    state.views.length > 1 ? `Vista activa: ${device.name}` : device.name,
    `${w} × ${h} px`,
    `DPR ${device.dpr} (${Math.round(w * device.dpr)} × ${Math.round(h * device.dpr)} px reales)`,
    OS_LABEL[device.os],
    canRotate(device) ? (rotated ? 'horizontal' : 'vertical') : null,
    `zoom ${Math.round(scale * 100)} %`,
  ].filter(Boolean).join(' · ');
}

// El servidor solo puede recibir un User-Agent por pestaña: el de la primera vista.
function updateNote() {
  const agents = new Set(state.views.map((v) => profile(deviceByName(v.device), chromeMajor).ua));
  noteEl.hidden = agents.size < 2;
  noteEl.textContent = `El servidor recibe el User-Agent de la primera vista (${state.views[0].device}) en todas. ` +
    'El tamaño, el diseño y lo que ven los scripts sí son los de cada dispositivo.';
}

// Cabeceras de esta pestaña (User-Agent y Client Hints de la primera vista, permitir marcos).
async function configure() {
  const prof = profile(deviceByName(state.views[0].device), chromeMajor);
  const response = await chrome.runtime.sendMessage({ type: 'sim-config', profile: prof });
  if (!response?.ok) statusEl.textContent = `No se pudo preparar el simulador: ${response?.error || 'error desconocido'}`;
}

async function refresh({ reload = false } = {}) {
  if (reload) rendered.forEach((r) => (r.key = ''));
  if (currentUrl) await configure();
  render();
}

function setActiveDevice(name) {
  activeView().device = name;
  save();
  refresh();
}

function step(delta) {
  const names = [...select.options].map((o) => o.value).filter(Boolean);
  const index = names.indexOf(activeView().device);
  const next = names[(index + delta + names.length) % names.length];
  if (next) setActiveDevice(next);
}

function addView() {
  if (state.views.length >= MAX_VIEWS) return;
  // Propone un dispositivo de otro tipo que el activo, para que la comparación tenga sentido.
  const current = deviceByName(activeView().device);
  const suggestion = { iPhone: 'Samsung Galaxy S24', Android: 'iPad Air 11" (M2)', Tablets: 'MacBook Air 13" (M2/M3)' }[current.category] || 'iPhone 16';
  state.views.push({ device: suggestion, landscape: false });
  state.active = state.views.length - 1;
  save();
  refresh();
}

function removeView(index) {
  if (state.views.length === 1) return;
  state.views.splice(index, 1);
  rendered.splice(index, 1)[0].el.remove();
  state.active = Math.min(state.active, state.views.length - 1);
  save();
  refresh(); // la primera vista puede haber cambiado (User-Agent del servidor)
}

// --- Eventos ----------------------------------------------------------------------------------

search.addEventListener('input', () => {
  fillSelect(search.value);
  const first = select.options[0]?.value;
  if (first && ![...select.options].some((o) => o.value === activeView().device)) setActiveDevice(first);
});
select.addEventListener('change', () => select.value && setActiveDevice(select.value));
$('prev').addEventListener('click', () => step(-1));
$('next').addEventListener('click', () => step(1));
rotateBtn.addEventListener('click', () => {
  activeView().landscape = !activeView().landscape;
  save();
  render();
});
zoomSelect.addEventListener('change', () => {
  state.zoom = zoomSelect.value;
  save();
  fit();
});
frameCheck.addEventListener('change', () => {
  state.frame = frameCheck.checked;
  save();
  rendered.forEach((r) => r.frameEl.classList.toggle('bare', !state.frame));
  fit();
});
addBtn.addEventListener('click', addView);
syncCheck.addEventListener('change', () => {
  state.sync = syncCheck.checked;
  save();
});

presetSelect.append(...PRESETS.map((p, i) => new Option(`${p.name} (${p.devices.length})`, String(i))));
presetSelect.addEventListener('change', () => {
  const preset = PRESETS[Number(presetSelect.value)];
  presetSelect.value = '';
  if (!preset) return;
  state.views = preset.devices.map((device) => ({ device, landscape: false }));
  state.active = 0;
  save();
  refresh();
});

form.noValidate = true;
form.addEventListener('submit', (event) => {
  event.preventDefault();
  const url = normalizeUrl(urlInput.value);
  if (!url) return;
  currentUrl = url;
  urlInput.value = url;
  refresh({ reload: true });
});
$('reload').addEventListener('click', () => currentUrl && refresh({ reload: true }));
$('open').addEventListener('click', () => currentUrl && chrome.tabs.create({ url: currentUrl }));
$('shot').addEventListener('click', async () => {
  if (!currentUrl) return;
  // Con varias vistas se capturan todas juntas. Solo se puede capturar lo que se ve en la ventana:
  // se recorta a la parte visible y se avisa.
  const target = state.views.length > 1 ? viewsEl : rendered[0].screenEl;
  const full = target.getBoundingClientRect();
  const left = Math.max(full.left, 0);
  const top = Math.max(full.top, 0);
  const rect = {
    left,
    top,
    width: Math.min(full.right, window.innerWidth) - left,
    height: Math.min(full.bottom, window.innerHeight) - top,
  };
  const cropped = rect.width < full.width - 1 || rect.height < full.height - 1;
  let host = currentUrl;
  try {
    host = new URL(currentUrl).hostname;
  } catch {}
  const names = state.views.map((v) => v.device);
  const response = await chrome.runtime.sendMessage({
    type: 'capture-region',
    rect: { x: rect.left, y: rect.top, width: rect.width, height: rect.height },
    innerWidth: window.innerWidth,
    url: currentUrl,
    title: `${host} en ${names.length > 1 ? `${names.length} dispositivos (${names.join(', ')})` : names[0]}`,
  });
  if (!response?.ok) statusEl.textContent = response?.error || 'No se pudo capturar.';
  else if (cropped) statusEl.textContent = 'No cabe todo en la ventana: la captura incluye solo la parte visible. Usa el zoom «Ajustar» para capturarlo completo.';
});

// Desplazamiento sincronizado: una vista avisa de su posición y se aplica a las demás.
window.addEventListener('message', (event) => {
  if (!state.sync || event.data?.[MESSAGE_KEY] !== 'scroll') return;
  const from = rendered.findIndex((r) => r.iframe && r.iframe.contentWindow === event.source);
  if (from < 0) return;
  rendered.forEach((r, i) => {
    if (i !== from && r.iframe?.contentWindow) r.iframe.contentWindow.postMessage({ [MESSAGE_KEY]: 'scroll-to', ratio: event.data.ratio }, '*');
  });
});

// La barra de direcciones sigue la navegación dentro de los marcos (aviso del service worker).
// Con "Ir" o ↻ se carga esa dirección en todas las vistas.
chrome.runtime.onMessage.addListener((message) => {
  if (message?.type !== 'sim-url' || message.tabId !== myTabId) return;
  if (document.activeElement !== urlInput) urlInput.value = message.url;
});

document.addEventListener('keydown', (event) => {
  if (event.target.closest('input, select, textarea')) return;
  if (event.key === 'ArrowLeft') step(-1);
  else if (event.key === 'ArrowRight') step(1);
  else if (event.key.toLowerCase() === 'r' && !rotateBtn.disabled) rotateBtn.click();
});
new ResizeObserver(() => fit()).observe(stage);

fillSelect();
urlInput.value = currentUrl;
document.title = `${DEVICES.length} dispositivos · Simulador · Belerofonte-Baycodec`;
refresh();
