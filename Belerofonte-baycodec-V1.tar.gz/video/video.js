// Descarga de un stream HLS: elige calidad, baja los segmentos en paralelo y los une en un MP4
// (video y audio juntos). Los streams en directo se graban hasta que el usuario pulsa "Detener y guardar".
// Si el stream está cifrado (AES-128, SAMPLE-AES o DRM) no se descarga.

import { fetchPlaylist } from './hls.js';
import { transmux, mergeTracks, hasVideo } from './mp4.js';

const PARALLEL = 6;
const RETRIES = 3;

const params = new URLSearchParams(location.search);
const sourceUrl = params.get('url');
const pageTitle = params.get('title') || '';
const referer = params.get('referer');
const sourceKind = params.get('kind'); // 'file' (mp4, webm…), 'ytdlp' (YouTube, Vimeo) o vacío (lista HLS)

const $ = (id) => document.getElementById(id);
const heading = $('heading');
const meta = $('meta');
const notice = $('notice');
const choose = $('choose');
const variantsEl = $('variants');
const audioRow = $('audio-row');
const audioSelect = $('audio');
const progress = $('progress');
const progressFill = $('progress-fill');
const progressText = $('progress-text');
const startBtn = $('start');
const stopBtn = $('stop');
const cancelBtn = $('cancel');
const result = $('result');
const filesEl = $('files');
const resultNote = $('result-note');

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const mb = (bytes) => `${(bytes / 1048576).toFixed(1)} MB`;
const clock = (seconds) => {
  const s = Math.round(seconds);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  return `${h ? `${h}:` : ''}${String(m).padStart(h ? 2 : 1, '0')}:${String(s % 60).padStart(2, '0')}`;
};
const mbps = (bps) => `${(bps / 1e6).toFixed(1)} Mbps`;

function showNotice(text) {
  notice.hidden = !text;
  notice.textContent = text;
}

function fail(text) {
  showNotice(text);
  meta.textContent = '';
  for (const el of [choose, progress, startBtn, stopBtn, cancelBtn]) el.hidden = true;
}

function baseName() {
  const raw = pageTitle || new URL(sourceUrl).pathname.split('/').pop().replace(/\.m3u8$/i, '') || 'video';
  return raw.replace(/[\\/:*?"<>|\u0000-\u001f]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 100) || 'video';
}

// --- Red ---------------------------------------------------------------------------------

async function fetchBytes(url, range, signal) {
  for (let attempt = 0; ; attempt++) {
    try {
      const response = await fetch(url, {
        credentials: 'include',
        signal,
        headers: range ? { Range: `bytes=${range.start}-${range.end}` } : {},
      });
      if (!response.ok) throw new Error(`el servidor respondió ${response.status}`);
      return new Uint8Array(await response.arrayBuffer());
    } catch (err) {
      if (signal.aborted || attempt >= RETRIES) throw err;
      await sleep(1000 * (attempt + 1));
    }
  }
}

// Tipo de archivo según los primeros bytes de los datos.
function detectContainer(bytes) {
  const tag = String.fromCharCode(...bytes.subarray(4, 8));
  if (['ftyp', 'styp', 'moof', 'sidx', 'moov'].includes(tag)) return { ext: 'mp4', type: 'video/mp4' };
  if (bytes[0] === 0x47) return { ext: 'ts', type: 'video/mp2t' };
  if (String.fromCharCode(...bytes.subarray(0, 3)) === 'ID3' || (bytes[0] === 0xff && (bytes[1] & 0xf0) === 0xf0)) {
    return { ext: 'aac', type: 'audio/aac' };
  }
  return { ext: 'ts', type: 'video/mp2t' };
}

// --- Descarga de una pista (video o audio) ---------------------------------------------

class Track {
  constructor(label, uri) {
    this.label = label;
    this.uri = uri;
    this.parts = [];
    this.bytes = 0;
    this.done = 0;
    this.total = 0;
    this.duration = 0;
  }

  async run(playlist, signal, stopSignal, onProgress) {
    if (playlist.map) {
      const init = await fetchBytes(playlist.map.uri, playlist.map.range, signal);
      this.init = init;
      this.bytes += init.length;
    }
    return playlist.live ? this.record(playlist, signal, stopSignal, onProgress) : this.download(playlist, signal, onProgress);
  }

  // Video bajo demanda: todos los segmentos, varios a la vez, en orden.
  async download(playlist, signal, onProgress) {
    const { segments } = playlist;
    this.total = segments.length;
    const parts = new Array(segments.length);
    let next = 0;
    const worker = async () => {
      while (next < segments.length) {
        const i = next++;
        parts[i] = await fetchBytes(segments[i].uri, segments[i].range, signal);
        this.bytes += parts[i].length;
        this.done++;
        this.duration += segments[i].duration;
        onProgress();
      }
    };
    await Promise.all(Array.from({ length: Math.min(PARALLEL, segments.length) }, worker));
    this.parts = parts;
  }

  // Directo: se vuelve a pedir la lista cada pocos segundos y se añaden los segmentos nuevos.
  async record(playlist, signal, stopSignal, onProgress) {
    const seen = new Set();
    let current = playlist;
    while (!stopSignal.aborted) {
      for (const segment of current.segments) {
        if (seen.has(segment.sequence) || stopSignal.aborted) continue;
        seen.add(segment.sequence);
        const bytes = await fetchBytes(segment.uri, segment.range, signal);
        this.parts.push(bytes);
        this.bytes += bytes.length;
        this.done++;
        this.duration += segment.duration;
        onProgress();
      }
      if (!current.live) break; // el directo terminó
      await Promise.race([sleep(Math.max(1, current.targetDuration / 2) * 1000), new Promise((r) => stopSignal.addEventListener('abort', r))]);
      if (stopSignal.aborted) break;
      current = await fetchPlaylist(this.uri);
      if (current.encryption.length) throw new Error('el stream pasó a estar cifrado');
    }
  }

  chunks() {
    return this.init ? [this.init, ...this.parts] : this.parts;
  }

  container() {
    return detectContainer(this.chunks().find((p) => p?.length) || new Uint8Array(8));
  }

  // Trozos de un MP4 fragmentado ([init, ...fragmentos]); los MPEG-TS/AAC se remuxan con mux.js.
  async toMp4(onProgress) {
    if (this.container().ext === 'mp4') return this.chunks();
    return transmux(this.parts, onProgress);
  }
}

// --- Flujo principal ----------------------------------------------------------------------

let master = null;

function renderChoices(playlist) {
  master = playlist;
  choose.hidden = false;
  variantsEl.replaceChildren(...playlist.variants.map((variant, i) => {
    const label = document.createElement('label');
    label.className = 'variant';
    const input = Object.assign(document.createElement('input'), { type: 'radio', name: 'variant', value: String(i), checked: i === 0 });
    const quality = document.createElement('b');
    quality.textContent = variant.height ? `${variant.height}p` : `Opción ${i + 1}`;
    const details = document.createElement('span');
    details.textContent = [variant.width && `${variant.width}×${variant.height}`, variant.bandwidth && mbps(variant.bandwidth), variant.codecs]
      .filter(Boolean).join(' · ');
    label.append(input, quality, details);
    return label;
  }));
  variantsEl.addEventListener('change', updateAudio);
  updateAudio();
}

// Pistas de audio separadas del video (grupo AUDIO de la variante elegida).
function updateAudio() {
  const variant = selectedVariant();
  const options = master.renditions.filter((r) => r.type === 'AUDIO' && r.group === variant.audio && r.uri);
  audioRow.hidden = !options.length;
  audioSelect.replaceChildren(...options.map((r) => {
    const option = Object.assign(document.createElement('option'), { value: r.uri, textContent: r.name || r.language || 'Audio' });
    option.selected = r.isDefault;
    return option;
  }));
}

const selectedVariant = () => master.variants[Number(variantsEl.querySelector('input:checked')?.value || 0)];

async function start() {
  const variant = master ? selectedVariant() : null;
  const videoUri = variant ? variant.uri : sourceUrl;
  const audioUri = master && !audioRow.hidden ? audioSelect.value : null;
  const qualityTag = variant?.height ? `-${variant.height}p` : '';

  startBtn.hidden = true;
  choose.querySelectorAll('input, select').forEach((el) => (el.disabled = true));
  showNotice('');
  meta.textContent = 'Preparando…';

  const abort = new AbortController();
  const stop = new AbortController();
  cancelBtn.hidden = false;
  cancelBtn.onclick = () => abort.abort();

  try {
    const tracks = [new Track('Video', videoUri)];
    if (audioUri) tracks.push(new Track('Audio', audioUri));
    const playlists = await Promise.all(tracks.map((t) => fetchPlaylist(t.uri)));

    const encrypted = playlists.flatMap((p) => p.encryption);
    if (encrypted.length) {
      return fail(`Este video está protegido (cifrado ${[...new Set(encrypted)].join(', ')}). No se puede descargar.`);
    }

    const live = playlists.some((p) => p.live);
    if (live) {
      stopBtn.hidden = false;
      stopBtn.onclick = () => stop.abort();
      progressFill.classList.add('live');
      heading.textContent = '⏺ Grabando directo';
    }
    progress.hidden = false;

    const started = performance.now();
    const totalDuration = Math.max(...playlists.map((p) => p.duration));
    const onProgress = () => {
      const bytes = tracks.reduce((sum, t) => sum + t.bytes, 0);
      const seconds = (performance.now() - started) / 1000;
      const speed = bytes / Math.max(seconds, 0.1);
      if (live) {
        progressText.textContent = `Grabado ${clock(tracks[0].duration)} · ${mb(bytes)} · ${mb(speed)}/s`;
        return;
      }
      const done = tracks.reduce((sum, t) => sum + t.done, 0);
      const total = tracks.reduce((sum, t) => sum + t.total, 0) || 1;
      const ratio = done / total;
      progressFill.style.width = `${(ratio * 100).toFixed(1)}%`;
      const eta = ratio > 0 ? seconds / ratio - seconds : 0;
      progressText.textContent = `${Math.round(ratio * 100)} % · segmento ${done} de ${total} · ${mb(bytes)} · ` +
        `${mb(speed)}/s${ratio > 0 && ratio < 1 ? ` · quedan ${clock(eta)}` : ''}`;
    };
    meta.textContent = live
      ? 'Directo: se graba desde ahora hasta que pulses «Detener y guardar».'
      : `Duración ${clock(totalDuration)} · ${playlists[0].segments.length} segmentos`;
    onProgress();

    await Promise.all(tracks.map((t, i) => t.run(playlists[i], abort.signal, stop.signal, onProgress)));

    stopBtn.hidden = true;
    cancelBtn.hidden = true;
    progressFill.classList.remove('live');
    progressFill.style.width = '100%';
    await save(tracks, qualityTag);
  } catch (err) {
    if (abort.signal.aborted) return fail('Descarga cancelada.');
    fail(`No se pudo descargar el video (${err.message}).`);
  }
}

// Intenta guardar un único MP4 (video + audio). Si no se puede, guarda cada pista en su formato original.
async function buildFiles(tracks) {
  try {
    const converted = [];
    for (const track of tracks) {
      converted.push(await track.toMp4((done, total) => {
        progressText.textContent = `Convirtiendo ${track.label.toLowerCase()} a MP4… ${Math.round((done / total) * 100)} %`;
      }));
    }
    const chunks = converted.length > 1 ? mergeTracks(converted[0], converted[1]) : converted[0];
    const video = hasVideo(chunks.find((c) => c.length && String.fromCharCode(...c.subarray(4, 8)) === 'moov') || converted[0][0]);
    return {
      files: [{ blob: new Blob(chunks, { type: video ? 'video/mp4' : 'audio/mp4' }), ext: video ? 'mp4' : 'm4a', suffix: '' }],
      note: '',
    };
  } catch (err) {
    console.warn('No se pudo convertir a MP4:', err);
    const files = tracks.map((track) => {
      const { ext, type } = track.container();
      return { blob: new Blob(track.chunks(), { type }), ext, suffix: tracks.length > 1 ? `-${track.label.toLowerCase()}` : '' };
    });
    const notes = [`No se pudo convertir a MP4 (${err.message}); se guardó el formato original.`];
    if (files.some((f) => f.ext === 'ts')) {
      notes.push('El .ts se reproduce en VLC o mpv. Para pasarlo a MP4 sin perder calidad: ffmpeg -i video.ts -c copy video.mp4');
    }
    if (files.length > 1) notes.push('Para unir video y audio: ffmpeg -i video.ts -i audio.aac -c copy video.mp4');
    return { files, note: notes.join(' ') };
  }
}

async function save(tracks, qualityTag) {
  const name = baseName();
  const { files, note } = await buildFiles(tracks);
  const links = files.map(({ blob, ext, suffix }) => {
    const fileName = `${name}${qualityTag}${suffix}.${ext}`;
    const link = Object.assign(document.createElement('a'), { href: URL.createObjectURL(blob), download: fileName });
    link.textContent = `⬇ ${fileName} (${mb(blob.size)})`;
    return link;
  });

  filesEl.replaceChildren(...links.map((link) => {
    const li = document.createElement('li');
    li.append(link);
    return li;
  }));
  links.forEach((link) => link.click());

  progressText.textContent = `Listo · ${files.map((f) => f.ext.toUpperCase()).join(' + ')} · ${mb(files.reduce((sum, f) => sum + f.blob.size, 0))}`;
  resultNote.textContent = note;
  result.hidden = false;
  heading.textContent = 'Video descargado';
  meta.textContent = 'Si la descarga no empezó sola, usa los enlaces de abajo.';
}

// --- Archivo directo (mp4, webm…) --------------------------------------------------------
// Se usa cuando el gestor de descargas del navegador recibe un 403: desde aquí la petición lleva
// el Referer de la página del video.

const EXT_BY_TYPE = { 'video/mp4': 'mp4', 'video/webm': 'webm', 'video/quicktime': 'mov', 'audio/mpeg': 'mp3', 'audio/mp4': 'm4a', 'audio/ogg': 'ogg' };

function directFileName(response) {
  const disposition = response.headers.get('content-disposition') || '';
  const fromHeader = disposition.match(/filename\*=UTF-8''([^;]+)|filename="?([^";]+)"?/i);
  if (fromHeader) return decodeURIComponent(fromHeader[1] || fromHeader[2]);
  let fromUrl = '';
  try {
    fromUrl = decodeURIComponent(new URL(sourceUrl).pathname.split('/').filter(Boolean).pop() || '');
  } catch {}
  if (/\.\w{2,4}$/.test(fromUrl)) return fromUrl;
  // Enlaces sin nombre de archivo (p. ej. los de OK.ru o con token): el título y la extensión del tipo.
  const type = (response.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
  return `${baseName()}.${EXT_BY_TYPE[type] || 'mp4'}`;
}

async function downloadDirect() {
  const abort = new AbortController();
  cancelBtn.hidden = false;
  cancelBtn.onclick = () => abort.abort();
  progress.hidden = false;
  meta.textContent = 'Descargando con el Referer de la página del video…';

  try {
    const response = await fetch(sourceUrl, { credentials: 'include', signal: abort.signal });
    if (response.status === 403 || response.status === 410) {
      return fail(`El servidor rechazó la descarga (${response.status}). Lo más probable es que el enlace haya caducado: ` +
        'recarga la página del video y vuelve a descargarlo (o copia el enlace nuevo).');
    }
    if (!response.ok) return fail(`El servidor respondió ${response.status}.`);

    const name = directFileName(response);
    heading.textContent = name;
    const total = Number(response.headers.get('content-length')) || 0;
    const reader = response.body.getReader();
    const chunks = [];
    let bytes = 0;
    const started = performance.now();
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(value);
      bytes += value.length;
      const seconds = (performance.now() - started) / 1000;
      const speed = bytes / Math.max(seconds, 0.1);
      if (total) {
        const ratio = bytes / total;
        progressFill.style.width = `${(ratio * 100).toFixed(1)}%`;
        progressText.textContent = `${Math.round(ratio * 100)} % · ${mb(bytes)} de ${mb(total)} · ${mb(speed)}/s` +
          (ratio < 1 ? ` · quedan ${clock((total - bytes) / speed)}` : '');
      } else {
        progressText.textContent = `${mb(bytes)} · ${mb(speed)}/s`;
      }
    }

    const blob = new Blob(chunks, { type: response.headers.get('content-type') || 'video/mp4' });
    cancelBtn.hidden = true;
    progressFill.style.width = '100%';
    progressText.textContent = `Listo · ${mb(blob.size)}`;
    const link = Object.assign(document.createElement('a'), { href: URL.createObjectURL(blob), download: name });
    link.textContent = `⬇ ${name} (${mb(blob.size)})`;
    const li = document.createElement('li');
    li.append(link);
    filesEl.replaceChildren(li);
    link.click();
    resultNote.textContent = '';
    result.hidden = false;
    heading.textContent = 'Video descargado';
    meta.textContent = 'Si la descarga no empezó sola, usa el enlace de abajo.';
  } catch (err) {
    if (abort.signal.aborted) return fail('Descarga cancelada.');
    fail(`No se pudo descargar el video (${err.message}).`);
  }
}

// --- YouTube y Vimeo con yt-dlp ----------------------------------------------------------------
// La extensión arranca yt-dlp a través del conector nativo (native/belerofonte_ytdlp.py), que se
// registra una sola vez con native/instalar.sh. El archivo se guarda en la carpeta de descargas.
const NATIVE_HOST = 'com.baycodec.belerofonte_ytdlp';
const INSTALL_HINT = 'Falta instalar el conector de yt-dlp (una vez, y otra si mueves la carpeta de la extensión). ' +
  'En una terminal, dentro de la carpeta de la extensión: ./native/instalar.sh — luego recarga la extensión.';

// Errores de yt-dlp que tienen una explicación concreta.
function ytdlpError(message) {
  if (/DRM/i.test(message)) return 'Este video está protegido con DRM: no se puede descargar.';
  // Vimeo bloquea a veces las conexiones que no vienen de un navegador ("couldn't verify the security
  // of your connection"), aunque el video sea público.
  if (/vimeo/i.test(message) && /HTTP Error 40[13]/i.test(message)) {
    return 'Vimeo no deja que yt-dlp acceda a este video (bloquea las conexiones que no vienen de un navegador). ' +
      'Alternativa: abre el video en su pestaña, reprodúcelo unos segundos y vuelve a abrir el popup: ' +
      'en «Videos de la página» aparecerá su stream para descargarlo desde el navegador (si no tiene DRM).';
  }
  if (/HTTP Error 40[13]|logged-in|private|password/i.test(message)) {
    return 'Este video es privado o solo se puede ver desde la web que lo inserta. ' +
      'Abre esa web y descárgalo desde el popup (sección Videos de la página).';
  }
  if (/HTTP Error 404|No video formats found/i.test(message)) return 'El video no existe o ya no está disponible.';
  return `yt-dlp no pudo descargar el video: ${message}`;
}

function downloadYtdlp() {
  const soloAudio = params.get('audio') === '1';
  const subtitulos = params.get('subs') === '1';
  const calidad = params.get('calidad') || (soloAudio ? '192' : 'mejor');
  const options = soloAudio
    ? `Solo audio MP3 · ${calidad} kbps`
    : `Video ${calidad === 'mejor' ? 'en la mejor calidad' : `hasta ${calidad}p`}${subtitulos ? ' · con subtítulos' : ''}`;
  heading.textContent = pageTitle.replace(/ - YouTube$| on Vimeo$/, '') || `Video de ${params.get('site') || 'YouTube'}`;
  meta.textContent = `${options} · yt-dlp`;
  progress.hidden = false;
  progressText.textContent = 'Arrancando yt-dlp…';

  let port;
  try {
    port = chrome.runtime.connectNative(NATIVE_HOST);
  } catch {
    return fail(INSTALL_HINT);
  }
  let finished = false;
  cancelBtn.hidden = false;
  cancelBtn.onclick = () => {
    finished = true;
    port.disconnect(); // el conector borra el archivo a medias y termina
    fail('Descarga cancelada.');
  };

  port.onDisconnect.addListener(() => {
    if (finished) return;
    const error = chrome.runtime.lastError?.message || '';
    fail(/not found|forbidden/i.test(error) ? INSTALL_HINT : `El conector de yt-dlp se cerró inesperadamente${error ? ` (${error})` : ''}.`);
  });

  port.onMessage.addListener((message) => {
    if (message.type === 'progress') {
      progressFill.style.width = `${message.porcentaje || 0}%`;
      progressText.textContent = message.mensaje ||
        `${message.porcentaje || 0} %${message.total ? ` · ${mb(message.descargado)} de ${mb(message.total)}` : ''}` +
        `${message.velocidad ? ` · ${message.velocidad}` : ''}`;
    } else if (message.type === 'error') {
      finished = true;
      port.disconnect();
      fail(ytdlpError(message.mensaje));
    } else if (message.type === 'done') {
      finished = true;
      port.disconnect();
      cancelBtn.hidden = true;
      progressFill.style.width = '100%';
      progressText.textContent = `Listo${message.tamano ? ` · ${mb(message.tamano)}` : ''}`;

      const open = Object.assign(document.createElement('button'), { className: 'btn', textContent: '📂 Abrir la carpeta' });
      open.addEventListener('click', () => chrome.runtime.sendNativeMessage(NATIVE_HOST, { action: 'reveal', path: message.ruta }));
      const li = document.createElement('li');
      li.append(`${message.archivo} `, open);
      filesEl.replaceChildren(li);
      resultNote.textContent = `Guardado en ${message.ruta}`;
      result.hidden = false;
      heading.textContent = soloAudio ? 'Audio descargado' : 'Video descargado';
      meta.textContent = options;
    }
  });

  port.postMessage({ action: 'download', url: sourceUrl, solo_audio: soloAudio, calidad, subtitulos, referer });
}

async function init() {
  if (!sourceUrl) return fail('Falta la dirección del video.');
  heading.textContent = baseName();
  try {
    // Las peticiones de esta pestaña llevarán el Referer de la web del video (algunos servidores lo exigen).
    if (referer) await chrome.runtime.sendMessage({ type: 'media-referer', referer });
    if (sourceKind === 'file') return downloadDirect();
    if (sourceKind === 'ytdlp') return downloadYtdlp();
    const playlist = await fetchPlaylist(sourceUrl);
    if (playlist.type === 'master') {
      if (!playlist.variants.length) return fail('La lista no contiene ninguna calidad descargable.');
      renderChoices(playlist);
      meta.textContent = `${playlist.variants.length} calidades disponibles`;
    } else {
      if (playlist.encryption.length) return fail(`Este video está protegido (cifrado ${playlist.encryption.join(', ')}). No se puede descargar.`);
      meta.textContent = playlist.live ? 'Directo' : `Duración ${clock(playlist.duration)} · ${playlist.segments.length} segmentos`;
    }
    const live = playlist.type === 'media' && playlist.live;
    startBtn.textContent = live ? '⏺ Grabar directo' : '⬇ Descargar';
    startBtn.hidden = false;
    startBtn.onclick = start;
  } catch (err) {
    fail(`No se pudo leer la lista del video (${err.message}).`);
  }
}

init();
