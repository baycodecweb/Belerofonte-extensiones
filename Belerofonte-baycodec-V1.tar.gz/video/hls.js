// Lector de listas HLS (.m3u8): maestras (varias calidades) y de medios (lista de segmentos).
// Lo usan el service worker (para clasificar lo detectado) y la página de descarga.

const ATTR = /([A-Z0-9-]+)=("[^"]*"|[^,]*)/g;

function parseAttrs(text) {
  const attrs = {};
  for (const [, key, raw] of text.matchAll(ATTR)) attrs[key] = raw.startsWith('"') ? raw.slice(1, -1) : raw;
  return attrs;
}

const resolve = (uri, base) => new URL(uri, base).href;

// "longitud@inicio"; sin inicio, empieza donde terminó el rango anterior.
function parseByteRange(value, previousEnd) {
  const [length, offset] = value.split('@').map(Number);
  const start = Number.isFinite(offset) ? offset : previousEnd;
  return { start, end: start + length - 1 };
}

export function parsePlaylist(text, baseUrl) {
  const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  if (lines[0] !== '#EXTM3U') throw new Error('No es una lista HLS válida.');

  if (lines.some((l) => l.startsWith('#EXT-X-STREAM-INF'))) {
    const variants = [];
    const renditions = [];
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      if (line.startsWith('#EXT-X-STREAM-INF:')) {
        const a = parseAttrs(line.slice(18));
        const uri = lines.slice(i + 1).find((l) => !l.startsWith('#'));
        if (!uri) continue;
        const [width, height] = (a.RESOLUTION || '').split('x').map(Number);
        variants.push({
          uri: resolve(uri, baseUrl),
          bandwidth: Number(a['AVERAGE-BANDWIDTH'] || a.BANDWIDTH) || 0,
          width: width || null,
          height: height || null,
          codecs: a.CODECS || '',
          audio: a.AUDIO || null,
        });
      } else if (line.startsWith('#EXT-X-MEDIA:')) {
        const a = parseAttrs(line.slice(13));
        renditions.push({
          type: a.TYPE,
          group: a['GROUP-ID'],
          name: a.NAME || a.LANGUAGE || '',
          language: a.LANGUAGE || '',
          isDefault: a.DEFAULT === 'YES',
          uri: a.URI ? resolve(a.URI, baseUrl) : null,
        });
      }
    }
    // Una misma URL puede repetirse (p. ej. variantes con distinto grupo de audio).
    const seen = new Set();
    const unique = variants.filter((v) => !seen.has(v.uri) && seen.add(v.uri));
    unique.sort((a, b) => (b.height || 0) - (a.height || 0) || b.bandwidth - a.bandwidth);
    return { type: 'master', variants: unique, renditions };
  }

  const segments = [];
  const keys = new Set();
  let map = null;
  let duration = 0;
  let pendingDuration = 0;
  let pendingRange = null;
  let previousEnd = 0;
  let sequence = 0;
  let ended = false;
  let targetDuration = 6;

  for (const line of lines) {
    if (line.startsWith('#EXTINF:')) pendingDuration = parseFloat(line.slice(8)) || 0;
    else if (line.startsWith('#EXT-X-TARGETDURATION:')) targetDuration = Number(line.slice(22)) || targetDuration;
    else if (line.startsWith('#EXT-X-MEDIA-SEQUENCE:')) sequence = Number(line.slice(22)) || 0;
    else if (line.startsWith('#EXT-X-ENDLIST')) ended = true;
    else if (line.startsWith('#EXT-X-PLAYLIST-TYPE:VOD')) ended = true;
    else if (line.startsWith('#EXT-X-BYTERANGE:')) pendingRange = line.slice(17);
    else if (line.startsWith('#EXT-X-KEY:') || line.startsWith('#EXT-X-SESSION-KEY:')) {
      const method = parseAttrs(line.slice(line.indexOf(':') + 1)).METHOD;
      if (method && method !== 'NONE') keys.add(method);
    } else if (line.startsWith('#EXT-X-MAP:')) {
      const a = parseAttrs(line.slice(11));
      map = { uri: resolve(a.URI, baseUrl), range: a.BYTERANGE ? parseByteRange(a.BYTERANGE, 0) : null };
    } else if (!line.startsWith('#')) {
      let range = null;
      if (pendingRange) {
        range = parseByteRange(pendingRange, previousEnd);
        previousEnd = range.end + 1;
      }
      segments.push({ uri: resolve(line, baseUrl), duration: pendingDuration, range, sequence: sequence + segments.length });
      duration += pendingDuration;
      pendingDuration = 0;
      pendingRange = null;
    }
  }

  return {
    type: 'media',
    segments,
    map,
    // Cualquier cifrado (AES-128, SAMPLE-AES, DRM) se trata como contenido protegido.
    encryption: [...keys],
    live: !ended,
    duration,
    targetDuration,
  };
}

export async function fetchPlaylist(url) {
  const response = await fetch(url, { credentials: 'include' });
  if (!response.ok) throw new Error(`El servidor respondió ${response.status} al pedir la lista.`);
  return parsePlaylist(await response.text(), response.url || url);
}
