// Convierte los segmentos de un stream en un único MP4 sin recodificar:
//   - MPEG-TS / AAC → MP4 fragmentado con mux.js (cargado como window.muxjs en video.html).
//   - Si el audio viene en otra pista, combina video y audio en el mismo MP4.

// --- Cajas (boxes) MP4 -----------------------------------------------------------------

const text = (bytes, at) => String.fromCharCode(bytes[at], bytes[at + 1], bytes[at + 2], bytes[at + 3]);
const view = (bytes) => new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);

// Cajas hijas entre start y end: [{ type, start, end, payload }] (payload = inicio del contenido).
function boxes(bytes, start = 0, end = bytes.length) {
  const dv = view(bytes);
  const out = [];
  for (let at = start; at + 8 <= end;) {
    let size = dv.getUint32(at);
    let header = 8;
    if (size === 1) {
      size = Number(dv.getBigUint64(at + 8));
      header = 16;
    } else if (size === 0) {
      size = end - at;
    }
    if (size < header || at + size > end) break;
    out.push({ type: text(bytes, at + 4), start: at, end: at + size, payload: at + header });
    at += size;
  }
  return out;
}

const child = (bytes, box, type) => boxes(bytes, box.payload, box.end).find((b) => b.type === type);
const children = (bytes, box, type) => boxes(bytes, box.payload, box.end).filter((b) => b.type === type);
const slice = (bytes, box) => bytes.slice(box.start, box.end);

function makeBox(type, parts) {
  const size = 8 + parts.reduce((sum, p) => sum + p.length, 0);
  const out = new Uint8Array(size);
  view(out).setUint32(0, size);
  for (let i = 0; i < 4; i++) out[4 + i] = type.charCodeAt(i);
  let at = 8;
  for (const part of parts) {
    out.set(part, at);
    at += part.length;
  }
  return out;
}

// Posición del track_ID en tkhd / trex / tfhd (relativa al inicio de la caja).
const tkhdIdOffset = (bytes, box) => (box.payload - box.start) + (bytes[box.payload] === 1 ? 20 : 12);
const trexIdOffset = (box) => (box.payload - box.start) + 4;

function trackInfo(init) {
  const moov = boxes(init).find((b) => b.type === 'moov');
  if (!moov) throw new Error('falta la caja moov');
  const traks = children(init, moov, 'trak').map((trak) => {
    const tkhd = child(init, trak, 'tkhd');
    const mdia = child(init, trak, 'mdia');
    const mdhd = child(init, mdia, 'mdhd');
    const hdlr = child(init, mdia, 'hdlr');
    const v1 = init[mdhd.payload] === 1;
    return {
      box: trak,
      id: view(init).getUint32(tkhd.start + tkhdIdOffset(init, tkhd)),
      timescale: view(init).getUint32(mdhd.payload + (v1 ? 20 : 12)),
      handler: text(init, hdlr.payload + 8),
    };
  });
  return { moov, traks };
}

export function hasVideo(init) {
  return trackInfo(init).traks.some((t) => t.handler === 'vide');
}

// --- MPEG-TS / AAC → MP4 fragmentado ----------------------------------------------------

// Remuxa los segmentos (en orden) con mux.js. Devuelve [init, ...fragmentos].
// onProgress(hechos, total) permite mostrar el avance; se cede el hilo de vez en cuando.
export async function transmux(parts, onProgress = () => {}) {
  if (!globalThis.muxjs?.Transmuxer) throw new Error('no se cargó mux.js');
  const transmuxer = new globalThis.muxjs.Transmuxer({ remux: true });
  let init = null;
  const fragments = [];
  transmuxer.on('data', (segment) => {
    init ||= new Uint8Array(segment.initSegment);
    fragments.push(new Uint8Array(segment.data));
  });

  for (let i = 0; i < parts.length; i++) {
    transmuxer.push(parts[i]);
    transmuxer.flush();
    if (i % 20 === 19) {
      onProgress(i + 1, parts.length);
      await new Promise((resolve) => setTimeout(resolve));
    }
  }
  onProgress(parts.length, parts.length);
  if (!init || !fragments.length) throw new Error('no se encontraron pistas H.264/AAC compatibles');
  return [init, ...fragments];
}

// --- Combinar dos MP4 fragmentados (video + audio) ---------------------------------------

// Separa las parejas moof+mdat (u otras cajas sueltas) de una lista de trozos fMP4.
function fragmentsOf(chunks) {
  const out = [];
  for (const chunk of chunks) {
    let current = null;
    for (const box of boxes(chunk)) {
      if (box.type === 'moof') {
        current = { moof: slice(chunk, box), rest: [] };
        out.push(current);
      } else if (current && box.type !== 'ftyp' && box.type !== 'moov' && box.type !== 'styp' && box.type !== 'sidx') {
        current.rest.push(slice(chunk, box));
      }
    }
  }
  return out;
}

// Cambia el track_ID en tfhd y devuelve el tiempo de inicio (tfdt) en segundos.
function patchFragment(fragment, idMap, timescales, sequence) {
  const { moof } = fragment;
  const box = boxes(moof)[0];
  const mfhd = child(moof, box, 'mfhd');
  view(moof).setUint32(mfhd.payload + 4, sequence);
  let time = Infinity;
  for (const traf of children(moof, box, 'traf')) {
    const tfhd = child(moof, traf, 'tfhd');
    const oldId = view(moof).getUint32(tfhd.payload + 4);
    const newId = idMap.get(oldId) ?? oldId;
    view(moof).setUint32(tfhd.payload + 4, newId);
    const tfdt = child(moof, traf, 'tfdt');
    if (tfdt) {
      const dv = view(moof);
      const decode = moof[tfdt.payload] === 1 ? Number(dv.getBigUint64(tfdt.payload + 4)) : dv.getUint32(tfdt.payload + 4);
      time = Math.min(time, decode / (timescales.get(newId) || 90000));
    }
  }
  return time;
}

// chunksA (video) y chunksB (audio): [init, ...fragmentos] de cada pista. Devuelve los trozos del MP4 combinado.
export function mergeTracks(chunksA, chunksB) {
  const [initA, ...restA] = chunksA;
  const [initB, ...restB] = chunksB;
  const a = trackInfo(initA);
  const b = trackInfo(initB);

  // Los ID de la segunda pista se renumeran después de los de la primera.
  let nextId = Math.max(...a.traks.map((t) => t.id)) + 1;
  const idMapB = new Map(b.traks.map((t) => [t.id, nextId++]));
  const timescales = new Map([...a.traks.map((t) => [t.id, t.timescale]), ...b.traks.map((t) => [idMapB.get(t.id), t.timescale])]);

  const mvhd = slice(initA, child(initA, a.moov, 'mvhd'));
  const mvhdOffset = (mvhd[8] === 1 ? 108 : 96) + 8;
  view(mvhd).setUint32(mvhdOffset, nextId); // next_track_ID

  const traksA = a.traks.map((t) => slice(initA, t.box));
  const traksB = b.traks.map((t) => {
    const trak = slice(initB, t.box);
    const tkhd = child(trak, boxes(trak)[0], 'tkhd');
    view(trak).setUint32(tkhd.start + tkhdIdOffset(trak, tkhd), idMapB.get(t.id));
    return trak;
  });

  const trexes = (init, info, idMap) => {
    const mvex = child(init, info.moov, 'mvex');
    return mvex ? children(init, mvex, 'trex').map((box) => {
      const trex = slice(init, box);
      const at = trexIdOffset(boxes(trex)[0]);
      const id = view(trex).getUint32(at);
      if (idMap) view(trex).setUint32(at, idMap.get(id) ?? id);
      return trex;
    }) : [];
  };
  const mvex = makeBox('mvex', [...trexes(initA, a), ...trexes(initB, b, idMapB)]);
  const moov = makeBox('moov', [mvhd, ...traksA, ...traksB, mvex]);
  const ftyp = boxes(initA).find((x) => x.type === 'ftyp');

  // Fragmentos de las dos pistas, intercalados por tiempo.
  const fragments = [
    ...fragmentsOf(restA).map((f) => ({ f, ids: new Map() })),
    ...fragmentsOf(restB).map((f) => ({ f, ids: idMapB })),
  ];
  const timed = fragments.map(({ f, ids }) => ({ f, time: patchFragment(f, ids, timescales, 0) }));
  timed.sort((x, y) => x.time - y.time);
  timed.forEach(({ f }, i) => patchFragment(f, new Map(), timescales, i + 1));

  return [ftyp ? slice(initA, ftyp) : new Uint8Array(), moov, ...timed.flatMap(({ f }) => [f.moof, ...f.rest])];
}
