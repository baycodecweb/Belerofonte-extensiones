#!/usr/bin/env python3
"""Genera icons/tech/*.svg con los logos que usa data/technologies.json (campo "icon").

El campo "icon" admite:
    "react"              logo de Simple Icons (CC0), en el color de la marca
    "logos:magento"      logo a color de gilbarbara/logos (CC0), vía Iconify
    "devicon:carbon"     logo de devicon (MIT), vía Iconify
    "lucide:server"      icono genérico de referencia (Lucide, ISC) cuando no hay logo oficial

Uso (cada paquete descomprimido en su propia carpeta):
    curl -sL https://registry.npmjs.org/simple-icons/-/simple-icons-16.32.0.tgz | tar xz -C si
    curl -sL https://registry.npmjs.org/@iconify-json/logos/-/logos-1.2.14.tgz | tar xz -C logos
    curl -sL https://registry.npmjs.org/@iconify-json/devicon/-/devicon-1.2.67.tgz | tar xz -C devicon
    curl -sL https://registry.npmjs.org/@iconify-json/lucide/-/lucide-1.2.136.tgz | tar xz -C lucide
    python3 -I tools/build-icons.py si/package logos/package devicon/package lucide/package

Cada SVG se dibuja sobre una baldosa redondeada de 32×32: blanca para los logos (oscura si el
color de la marca es demasiado claro para leerse sobre blanco) y lila para los de referencia,
para que se distingan de un logo oficial.
"""

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'icons' / 'tech'
LIGHT_BG = '#ffffff'
DARK_BG = '#1c1c22'
REFERENCE_BG = '#eef0ff'
REFERENCE_FG = '#4f46e5'
REFERENCE_SETS = {'lucide'}


def file_name(icon):
    """"logos:magento" → "logos-magento.svg"; también lo usa el popup."""
    return icon.replace(':', '-') + '.svg'


def luminance(hex_color):
    r, g, b = (int(hex_color[i:i + 2], 16) / 255 for i in (0, 2, 4))
    lin = lambda c: c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    return 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b)


def contrast(l1, l2):
    hi, lo = max(l1, l2), min(l1, l2)
    return (hi + 0.05) / (lo + 0.05)


def tile(bg, inner):
    return (
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">'
        f'<rect width="32" height="32" rx="7" fill="{bg}"/>{inner}</svg>\n'
    )


def load_packages(dirs):
    simple, iconify = None, {}
    for d in map(Path, dirs):
        if (d / 'data' / 'simple-icons.json').exists():
            simple = d
        elif (d / 'icons.json').exists():
            data = json.loads((d / 'icons.json').read_text())
            iconify[data['prefix']] = data
        else:
            sys.exit(f'{d}: no parece un paquete de Simple Icons ni de Iconify')
    return simple, iconify


def simple_icon(package, colors, slug):
    source = (package / 'icons' / f'{slug}.svg').read_text()
    path = re.search(r'<path d="([^"]+)"', source)
    if not path:
        sys.exit(f'{slug}: no se encontró el <path> del logo')
    color = colors[slug]
    # Sobre blanco el logo necesita un contraste mínimo de 2:1; si no, fondo oscuro.
    bg = LIGHT_BG if contrast(luminance(color), 1.0) >= 2 else DARK_BG
    return tile(bg, f'<path transform="translate(6 6) scale(.8333)" fill="#{color}" d="{path.group(1)}"/>')


def iconify_icon(data, name):
    # Los alias apuntan a otro icono (posiblemente con sus propias dimensiones).
    alias = data.get('aliases', {}).get(name)
    icon = dict(data['icons'][alias['parent']] if alias else data['icons'][name])
    if alias:
        icon.update({k: v for k, v in alias.items() if k != 'parent'})
    left, top = icon.get('left', 0), icon.get('top', 0)
    width = icon.get('width', data.get('width', 16))
    height = icon.get('height', data.get('height', 16))

    reference = data['prefix'] in REFERENCE_SETS
    # Los iconos de referencia se pintan con currentColor: se les da el color de acento.
    color = f' color="{REFERENCE_FG}"' if reference else ''
    inner = (
        f'<svg x="6" y="6" width="20" height="20" viewBox="{left} {top} {width} {height}"{color}>'
        f'{icon["body"]}</svg>'
    )
    return tile(REFERENCE_BG if reference else LIGHT_BG, inner)


def build(dirs):
    simple, iconify = load_packages(dirs)
    colors = {}
    if simple:
        colors = {i['slug']: i['hex'] for i in json.loads((simple / 'data' / 'simple-icons.json').read_text())}

    techs = json.loads((ROOT / 'data' / 'technologies.json').read_text())['technologies']
    icons = sorted({t['icon'] for t in techs.values() if 'icon' in t})

    OUT.mkdir(parents=True, exist_ok=True)
    wanted = {file_name(i) for i in icons}
    for old in OUT.glob('*.svg'):
        if old.name not in wanted:
            old.unlink()

    built = 0
    for icon in icons:
        prefix, _, name = icon.rpartition(':')
        if not prefix:
            if not simple:
                print(f'  omitido {icon}: falta el paquete de Simple Icons')
                continue
            svg = simple_icon(simple, colors, name)
        elif prefix in iconify:
            svg = iconify_icon(iconify[prefix], name)
        else:
            print(f'  omitido {icon}: falta el paquete de Iconify «{prefix}»')
            continue
        (OUT / file_name(icon)).write_text(svg)
        built += 1

    print(f'{built} iconos generados en {OUT.relative_to(ROOT)}')


if __name__ == '__main__':
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    build(sys.argv[1:])
