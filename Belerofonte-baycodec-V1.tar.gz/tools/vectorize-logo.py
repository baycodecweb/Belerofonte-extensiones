#!/usr/bin/env python3
# Uso (desde la carpeta del proyecto):
#   python3 -m venv /tmp/trace-venv && /tmp/trace-venv/bin/pip install potracer pillow numpy
#   /tmp/trace-venv/bin/python -I tools/vectorize-logo.py icons/logo/icono.png icons/logo/icono.svg icons/logo/icono-pegaso.svg
#   for s in 128 48; do inkscape icons/logo/icono.svg --export-type=png --export-filename=icons/icon$s.png -w $s -h $s; done
#   for s in 32 16;  do inkscape icons/logo/icono-pegaso.svg --export-type=png --export-filename=icons/icon$s.png -w $s -h $s; done
#
# Las medidas (centro, radios, fila que separa Pegaso del texto) y los colores del degradado
# están tomados de icono.png; si cambias el logo, vuelve a medirlos.
# Vectoriza icono.png: círculo, anillo y degradado como formas SVG; las zonas blancas (Pegaso con
# el jinete y el texto) trazadas con potrace. Genera el logo completo y una variante solo con Pegaso.
import sys, time, numpy as np, potrace
from PIL import Image

SRC, OUT_FULL, OUT_SMALL = sys.argv[1:4]
CX, CY, R, R_IN = 1604, 1598, 1572, 1421.5        # medidos en el PNG (px)
SPLIT = 2150                                      # fila que separa Pegaso (arriba) del texto (abajo)
RING = '#13788c'
STOPS = ['#57ddb5', '#53ceb3', '#4fbeb1', '#4cafb0', '#489faf', '#4490ad', '#397a98', '#2e6582', '#234f6d', '#183a58', '#0e2443']
SCALE = 0.5                                       # se traza a media resolución (de sobra para un icono)

im = np.asarray(Image.open(SRC).convert('RGBA')).astype(int)
H, W = im.shape[:2]
Y, X = np.ogrid[:H, :W]
inside = (X - CX) ** 2 + (Y - CY) ** 2 < (R_IN - 6) ** 2
# Blanco = el canal más bajo es alto (el fondo más claro, arriba, tiene el mínimo en ~0x57).
white = (im[..., :3].min(axis=2) > 170) & (im[..., 3] > 128) & inside

def trace(mask):
    small = Image.fromarray((mask * 255).astype(np.uint8)).resize((int(W * SCALE), int(H * SCALE)), Image.LANCZOS)
    # potracer toma True como fondo y False como figura: se le pasa la máscara invertida.
    bitmap = potrace.Bitmap(np.asarray(small) <= 127)
    t = time.time()
    path = bitmap.trace(turdsize=6, turnpolicy=potrace.POTRACE_TURNPOLICY_MINORITY, alphamax=1.0, opticurve=True, opttolerance=0.2)
    f = lambda p: f'{p.x / SCALE:.1f} {p.y / SCALE:.1f}'
    parts = []
    for curve in path:
        parts.append(f'M{f(curve.start_point)}')
        for seg in curve:
            parts.append(f'L{f(seg.c)}L{f(seg.end_point)}' if seg.is_corner else f'C{f(seg.c1)} {f(seg.c2)} {f(seg.end_point)}')
        parts.append('Z')
    print(f'   {len(path)} contornos, {sum(len(c) for c in path)} segmentos en {time.time() - t:.1f} s', file=sys.stderr)
    return ''.join(parts)

rows = np.arange(H)[:, None]
print('Pegaso:', file=sys.stderr); pegaso = trace(white & (rows < SPLIT))
print('Texto:', file=sys.stderr); texto = trace(white & (rows >= SPLIT))

# Caja de Pegaso (para centrarlo y agrandarlo en la variante pequeña)
ys, xs = np.nonzero(white & (rows < SPLIT))
bx0, bx1, by0, by1 = xs.min(), xs.max(), ys.min(), ys.max()

def svg(title, figure):
    stops = ''.join(f'<stop offset="{i / (len(STOPS) - 1):.2f}" stop-color="{c}"/>' for i, c in enumerate(STOPS))
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 1000" width="1000" height="1000">
  <title>{title}</title>
  <defs><linearGradient id="fondo" x1="0" y1="0" x2="0" y2="1">{stops}</linearGradient></defs>
  <circle cx="500" cy="500" r="500" fill="{RING}"/>
  <circle cx="500" cy="500" r="{R_IN / R * 500:.1f}" fill="url(#fondo)"/>
{figure}
</svg>
'''

k = 500 / R   # px del PNG → unidades del viewBox (radio 500)
full = f'''  <g fill="#fff" fill-rule="evenodd" transform="translate(500 500) scale({k:.5f}) translate({-CX} {-CY})">
    <path d="{pegaso}"/>
    <path d="{texto}"/>
  </g>'''
# Variante pequeña: solo Pegaso, centrado y lo más grande posible dentro del interior del círculo.
bw, bh = bx1 - bx0, by1 - by0
fit = (R_IN / R * 500) * 1.85 / np.hypot(bw, bh)   # la diagonal de la figura ocupa ~92 % del diámetro interior
small = f'''  <g fill="#fff" fill-rule="evenodd" transform="translate(500 500) scale({fit:.5f}) translate({-(bx0 + bw / 2):.1f} {-(by0 + bh / 2):.1f})">
    <path d="{pegaso}"/>
  </g>'''
open(OUT_FULL, 'w').write(svg('Belerofonte-Baycodec', full))
open(OUT_SMALL, 'w').write(svg('Belerofonte-Baycodec (Pegaso)', small))
print(f'Pegaso: caja {bw}x{bh} px; escala en la variante pequeña {fit / k:.2f}x respecto al logo completo', file=sys.stderr)
