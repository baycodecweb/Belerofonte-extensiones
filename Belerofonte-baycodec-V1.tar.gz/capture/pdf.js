// Convierte una imagen en PDF sin bibliotecas externas. La imagen va sin pérdida (RGB comprimido
// con Flate) y ajustada al ancho de un A4. Dos diseños:
//   'a4'     si cabe en una página, la página mide lo que la imagen; si no, se reparte en páginas A4.
//   'single' una sola página tan alta como la imagen.

const A4_WIDTH = 595.28; // puntos
const A4_HEIGHT = 841.89;
// Alto máximo de página que admiten los visores (PDF, anexo C). Si la imagen es más alta, se reduce
// el tamaño de la página; la imagen conserva todos sus píxeles.
const MAX_PAGE_SIDE = 14_400;

const encoder = new TextEncoder();
const num = (n) => String(Math.round(n * 100) / 100);

async function deflate(bytes) {
  const stream = new Blob([bytes]).stream().pipeThrough(new CompressionStream('deflate'));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

function toRgb(rgba) {
  const rgb = new Uint8Array((rgba.length / 4) * 3);
  for (let i = 0, j = 0; i < rgba.length; i += 4, j += 3) {
    rgb[j] = rgba[i];
    rgb[j + 1] = rgba[i + 1];
    rgb[j + 2] = rgba[i + 2];
  }
  return rgb;
}

// Texto del diccionario Info en UTF-16BE, para que admita tildes y cualquier carácter.
function pdfText(text) {
  let hex = 'FEFF';
  for (let i = 0; i < text.length; i++) hex += text.charCodeAt(i).toString(16).padStart(4, '0');
  return `<${hex}>`;
}

function pdfDate(date) {
  const pad = (n) => String(n).padStart(2, '0');
  return `(D:${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}${pad(date.getHours())}${pad(date.getMinutes())}${pad(date.getSeconds())})`;
}

// ¿Ocupa más de una página A4? Solo entonces cambia algo elegir entre 'a4' y 'single'.
export const needsSeveralPages = (width, height) => height * (A4_WIDTH / width) > A4_HEIGHT;

export async function imageToPdf(bitmap, { title = '', date = new Date(), layout = 'a4' } = {}) {
  let scale = A4_WIDTH / bitmap.width;
  let pageWidth = A4_WIDTH;
  let pageHeight = A4_HEIGHT;
  let sliceHeight = Math.floor(A4_HEIGHT / scale);

  if (layout === 'single' || !needsSeveralPages(bitmap.width, bitmap.height)) {
    scale = Math.min(scale, MAX_PAGE_SIDE / bitmap.height);
    pageWidth = bitmap.width * scale;
    pageHeight = bitmap.height * scale;
    sliceHeight = bitmap.height;
  }
  const pageCount = Math.ceil(bitmap.height / sliceHeight);

  const parts = [];
  const offsets = [];
  let length = 0;
  const push = (chunk) => {
    const bytes = typeof chunk === 'string' ? encoder.encode(chunk) : chunk;
    parts.push(bytes);
    length += bytes.length;
  };
  const object = (id, dict, stream) => {
    offsets[id] = length;
    push(`${id} 0 obj\n${dict}\n`);
    if (stream) {
      push('stream\n');
      push(stream);
      push('\nendstream\n');
    }
    push('endobj\n');
  };

  push('%PDF-1.4\n');
  push(new Uint8Array([0x25, 0xe2, 0xe3, 0xcf, 0xd3, 0x0a])); // marca de archivo binario

  // 1 catálogo, 2 árbol de páginas, 3 info; cada página usa 3 objetos (página, contenido, imagen).
  const pageId = (i) => 4 + i * 3;
  object(1, '<< /Type /Catalog /Pages 2 0 R >>');
  object(2, `<< /Type /Pages /Kids [${Array.from({ length: pageCount }, (_, i) => `${pageId(i)} 0 R`).join(' ')}] /Count ${pageCount} >>`);
  object(3, `<< /Title ${pdfText(title)} /Producer ${pdfText('Belerofonte-Baycodec')} /CreationDate ${pdfDate(date)} >>`);

  const canvas = new OffscreenCanvas(bitmap.width, sliceHeight);
  const ctx = canvas.getContext('2d', { willReadFrequently: true });

  for (let i = 0; i < pageCount; i++) {
    const top = i * sliceHeight;
    const height = Math.min(sliceHeight, bitmap.height - top);
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, bitmap.width, height);
    ctx.drawImage(bitmap, 0, top, bitmap.width, height, 0, 0, bitmap.width, height);
    const image = await deflate(toRgb(ctx.getImageData(0, 0, bitmap.width, height).data));

    const drawHeight = height * scale;
    const content = encoder.encode(`q ${num(pageWidth)} 0 0 ${num(drawHeight)} 0 ${num(pageHeight - drawHeight)} cm /Im0 Do Q`);
    const id = pageId(i);

    object(id, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${num(pageWidth)} ${num(pageHeight)}] ` +
      `/Resources << /XObject << /Im0 ${id + 2} 0 R >> >> /Contents ${id + 1} 0 R >>`);
    object(id + 1, `<< /Length ${content.length} >>`, content);
    object(id + 2, `<< /Type /XObject /Subtype /Image /Width ${bitmap.width} /Height ${height} ` +
      `/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /FlateDecode /Length ${image.length} >>`, image);
  }

  const xref = length;
  const size = offsets.length;
  push(`xref\n0 ${size}\n0000000000 65535 f \n`);
  for (let id = 1; id < size; id++) push(`${String(offsets[id]).padStart(10, '0')} 00000 n \n`);
  push(`trailer\n<< /Size ${size} /Root 1 0 R /Info 3 0 R >>\nstartxref\n${xref}\n%%EOF\n`);

  return new Blob(parts, { type: 'application/pdf' });
}
