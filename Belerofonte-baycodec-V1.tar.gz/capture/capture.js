// Vista previa de una captura: la pide al service worker y permite descargarla (PNG o PDF) o copiarla.

import { imageToPdf, needsSeveralPages } from './pdf.js';

const MODES = { visible: 'Área visible', full: 'Página completa', region: 'Selección' };

const heading = document.getElementById('heading');
const meta = document.getElementById('meta');
const notice = document.getElementById('notice');
const stage = document.getElementById('stage');
const copyBtn = document.getElementById('copy');
const download = document.getElementById('download');
const pdfBtn = document.getElementById('pdf');
const pdfLayout = document.getElementById('pdf-layout');
const LAYOUT_KEY = 'pdfLayout';

const pad = (n) => String(n).padStart(2, '0');

function fileName(capture) {
  const d = new Date(capture.takenAt);
  const host = new URL(capture.url).hostname.replace(/^www\./, '');
  const stamp = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}_${pad(d.getHours())}-${pad(d.getMinutes())}-${pad(d.getSeconds())}`;
  return `captura-${host}-${stamp}.png`;
}

function showError(text) {
  heading.textContent = 'Captura no disponible';
  meta.textContent = '';
  const p = document.createElement('p');
  p.className = 'state';
  p.textContent = text;
  stage.replaceChildren(p);
}

async function load() {
  const id = new URLSearchParams(location.search).get('id');
  const capture = await chrome.runtime.sendMessage({ type: 'capture-get', id });
  if (!capture?.ok) return showError(capture?.error || 'No se pudo cargar la captura.');

  const blob = await (await fetch(capture.dataUrl)).blob();
  const url = URL.createObjectURL(blob);
  const name = fileName(capture);

  heading.textContent = `Captura · ${MODES[capture.mode] || capture.mode}`;
  meta.textContent = `${capture.title || capture.url} · ${capture.width} × ${capture.height} px · ` +
    new Date(capture.takenAt).toLocaleString('es');
  meta.title = capture.url;
  document.title = `${name} · Belerofonte-Baycodec`;

  if (capture.truncated) {
    notice.hidden = false;
    notice.textContent = 'La página es demasiado larga: se capturó solo la parte superior que cabe en una imagen.';
  }

  const img = document.createElement('img');
  img.src = url;
  img.alt = `Captura de ${capture.url}`;
  stage.replaceChildren(img);

  download.href = url;
  download.download = name;
  download.removeAttribute('aria-disabled');

  // Se recuerda el último diseño elegido (solo es una preferencia de este navegador).
  if (needsSeveralPages(capture.width, capture.height)) {
    pdfLayout.hidden = false;
    try {
      if (localStorage.getItem(LAYOUT_KEY) === 'single') pdfLayout.value = 'single';
    } catch {}
    pdfLayout.addEventListener('change', () => {
      try {
        localStorage.setItem(LAYOUT_KEY, pdfLayout.value);
      } catch {}
    });
  }

  const pdfUrls = {};
  pdfBtn.disabled = false;
  pdfBtn.addEventListener('click', async () => {
    const layout = pdfLayout.value;
    if (!pdfUrls[layout]) {
      pdfBtn.disabled = true;
      pdfBtn.textContent = 'Generando PDF…';
      try {
        const bitmap = await createImageBitmap(blob);
        const pdf = await imageToPdf(bitmap, { title: capture.title || capture.url, date: new Date(capture.takenAt), layout });
        bitmap.close();
        pdfUrls[layout] = URL.createObjectURL(pdf);
      } catch (err) {
        pdfBtn.textContent = '✗ No se pudo generar';
        console.error(err);
        setTimeout(() => {
          pdfBtn.textContent = '⬇ Descargar PDF';
          pdfBtn.disabled = false;
        }, 2000);
        return;
      }
      pdfBtn.textContent = '⬇ Descargar PDF';
      pdfBtn.disabled = false;
    }
    const link = document.createElement('a');
    link.href = pdfUrls[layout];
    link.download = name.replace(/\.png$/, '.pdf');
    link.click();
  });

  copyBtn.disabled = false;
  copyBtn.addEventListener('click', async () => {
    try {
      await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
      copyBtn.textContent = '✓ Copiada';
    } catch {
      copyBtn.textContent = '✗ No se pudo copiar';
    }
    setTimeout(() => (copyBtn.textContent = '⧉ Copiar imagen'), 1500);
  });
}

load();
