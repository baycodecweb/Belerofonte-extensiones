// Perfil del dominio: datos de registro (RDAP), IP y red, primera captura en archive.org
// y una estimación de cuándo se creó el sitio. Solo se ejecuta cuando el usuario lo pide,
// porque envía el dominio a servicios externos.

const TIMEOUT = 20_000;
// La búsqueda de archive.org puede tardar casi un minuto en sitios con muchas capturas.
const WAYBACK_TIMEOUT = 60_000;

// --- Dominio registrable (blog.tienda.com.mx → tienda.com.mx) -----------------

let suffixesPromise;

function loadSuffixes() {
  suffixesPromise ??= fetch(chrome.runtime.getURL('data/public-suffixes.txt'))
    .then((res) => res.text())
    .then((text) => {
      // Las reglas vienen en Unicode; las URL usan punycode (xn--...).
      const toAscii = (name) => {
        try {
          return new URL(`http://${name}`).hostname;
        } catch {
          return name;
        }
      };
      const rules = new Set();
      const wildcards = new Set();
      const exceptions = new Set();
      for (const line of text.split('\n')) {
        const rule = line.trim();
        if (!rule || rule.startsWith('//')) continue;
        if (rule.startsWith('!')) exceptions.add(toAscii(rule.slice(1)));
        else if (rule.startsWith('*.')) wildcards.add(toAscii(rule.slice(2)));
        else rules.add(toAscii(rule));
      }
      return { rules, wildcards, exceptions };
    });
  return suffixesPromise;
}

export async function registrableDomain(host) {
  host = host.toLowerCase().replace(/\.$/, '');
  if (/^[\d.]+$/.test(host) || host.includes(':')) return null; // dirección IP

  const { rules, wildcards, exceptions } = await loadSuffixes();
  const labels = host.split('.');
  let suffixLength = 1; // sin regla conocida, el sufijo es la última etiqueta

  for (let i = 0; i < labels.length; i++) {
    const candidate = labels.slice(i).join('.');
    if (exceptions.has(candidate)) {
      suffixLength = labels.length - i - 1;
      break;
    }
    if (rules.has(candidate) || (i + 1 < labels.length && wildcards.has(labels.slice(i + 1).join('.')))) {
      suffixLength = labels.length - i;
      break;
    }
  }

  if (labels.length <= suffixLength) return null;
  return labels.slice(-(suffixLength + 1)).join('.');
}

// --- Utilidades ----------------------------------------------------------------

async function fetchJson(url, headers = {}, timeout = TIMEOUT) {
  const res = await fetch(url, { headers, signal: AbortSignal.timeout(timeout), credentials: 'omit' });
  if (!res.ok) {
    const err = new Error(`HTTP ${res.status}`);
    err.status = res.status;
    throw err;
  }
  return res.json();
}

const rdapJson = (url) => fetchJson(url, { Accept: 'application/rdap+json, application/json' });

// Cada fuente puede fallar por su cuenta sin tirar el perfil completo.
async function safe(promise) {
  try {
    return await promise;
  } catch (err) {
    return { error: err.name === 'TimeoutError' ? 'El servicio tardó demasiado en responder.' : err.message };
  }
}

const eventDate = (data, action) => data.events?.find((e) => e.eventAction === action)?.eventDate || null;
const vcardField = (entity, field) => entity?.vcardArray?.[1]?.find(([name]) => name === field);

// --- Fuentes externas -------------------------------------------------------------

async function lookupRdap(domain) {
  let data;
  try {
    data = await rdapJson(`https://rdap.org/domain/${domain}`);
  } catch (err) {
    if (err.status === 404) {
      return { error: 'Esta extensión de dominio no publica datos RDAP (el WHOIS moderno) o el dominio no existe.' };
    }
    throw err;
  }

  // Algunos registros solo guardan lo mínimo; el registrador ("related") tiene el resto.
  if (!eventDate(data, 'registration')) {
    const related = data.links?.find((l) => l.rel === 'related' && /rdap/i.test(l.href + (l.type || '')))?.href;
    if (related) data = { ...(await safe(rdapJson(related))), ...data };
  }

  const registrar = data.entities?.find((e) => e.roles?.includes('registrar'));
  return {
    domain: data.ldhName?.toLowerCase() || domain,
    status: data.status || [],
    created: eventDate(data, 'registration'),
    expires: eventDate(data, 'expiration'),
    updated: eventDate(data, 'last changed'),
    nameservers: (data.nameservers || []).map((ns) => ns.ldhName?.toLowerCase()).filter(Boolean),
    dnssec: data.secureDNS?.delegationSigned ?? null,
    registrar: registrar
      ? {
          name: vcardField(registrar, 'fn')?.[3] || registrar.handle || '',
          ianaId: registrar.publicIds?.find((p) => /iana/i.test(p.type))?.identifier || '',
          url: registrar.links?.find((l) => /^https?:/.test(l.href) && !/rdap/i.test(l.href))?.href || '',
          whois: registrar.port43 || data.port43 || '',
        }
      : null,
    source: data.links?.find((l) => l.rel === 'self')?.href || `https://rdap.org/domain/${domain}`,
  };
}

async function resolveIp(host) {
  const data = await fetchJson(`https://cloudflare-dns.com/dns-query?name=${encodeURIComponent(host)}&type=A`, {
    Accept: 'application/dns-json',
  });
  return data.Answer?.find((a) => a.type === 1)?.data || null;
}

async function lookupIp(ip) {
  const data = await fetchJson(`https://ipwho.is/${ip}?lang=es`);
  if (!data.success) throw new Error(data.message || 'Sin datos para esta IP');
  return {
    country: data.country,
    countryCode: data.country_code,
    region: data.region,
    city: data.city,
    flag: data.flag?.emoji || '',
    asn: data.connection?.asn || null,
    org: data.connection?.org || data.connection?.isp || '',
  };
}

// Titular registrado del bloque de IPs (suele ser el proveedor de hosting) y su dirección.
async function lookupNetwork(ip) {
  const data = await rdapJson(`https://rdap.org/ip/${ip}`);
  const owner = data.entities?.find((e) => vcardField(e, 'fn')) || null;
  const label = vcardField(owner, 'adr')?.[1]?.label || '';
  return {
    name: vcardField(owner, 'fn')?.[3] || data.name || '',
    // La etiqueta suele ser "calle\nciudad\nestado\ncp\npaís": se omiten la calle y el CP.
    address: label.split('\n').slice(1).filter((part) => part && !/^\d[\d -]*$/.test(part)).join(', '),
    range: data.startAddress && data.endAddress ? `${data.startAddress} – ${data.endAddress}` : '',
  };
}

async function lookupAsn(asn) {
  const data = await rdapJson(`https://rdap.org/autnum/${asn}`);
  return { name: data.name || '', registered: eventDate(data, 'registration') };
}

// Primera captura del dominio (con y sin www) en la Wayback Machine.
async function lookupWayback(domain) {
  const first = async (url) => {
    const rows = await fetchJson(
      `https://web.archive.org/cdx/search/cdx?url=${encodeURIComponent(url)}&output=json&limit=1&fl=timestamp,original`,
      {},
      WAYBACK_TIMEOUT,
    );
    return rows[1] ? { timestamp: rows[1][0], original: rows[1][1] } : null;
  };
  const settled = await Promise.allSettled([first(domain), first(`www.${domain}`)]);
  const results = settled
    .filter((r) => r.status === 'fulfilled' && r.value)
    .map((r) => r.value)
    .sort((a, b) => a.timestamp.localeCompare(b.timestamp));

  if (!results.length) {
    // "Sin capturas" solo si archive.org respondió; si falló, se explica por qué.
    const failure = settled.find((r) => r.status === 'rejected')?.reason;
    if (failure?.status === 429) throw new Error('archive.org está limitando las consultas; inténtalo de nuevo en unos minutos.');
    if (failure?.name === 'TimeoutError') throw new Error('archive.org tardó demasiado en responder; inténtalo de nuevo.');
    if (failure) throw failure;
    return { firstCapture: null };
  }

  const { timestamp, original } = results[0];
  const [, y, m, d, hh, mm, ss] = timestamp.match(/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})/);
  return {
    firstCapture: `${y}-${m}-${d}T${hh}:${mm}:${ss}Z`,
    url: `https://web.archive.org/web/${timestamp}/${original}`,
  };
}

// --- Pistas dentro de la propia página (se ejecuta en la pestaña) ---------------

function collectAgeHints() {
  const now = new Date().getFullYear();
  const valid = (y) => y >= 1991 && y <= now;

  const copyright = [];
  const text = (document.body?.innerText || '').slice(-200_000);
  const re = /(?:©|\(c\)|copyright|derechos reservados)[^\n\d]{0,40}((?:19|20)\d{2})(?:\s*[-–—]\s*((?:19|20)\d{2}))?/gi;
  for (const match of text.matchAll(re)) {
    const year = Number(match[1]);
    if (valid(year)) copyright.push(year);
  }

  // schema.org: "foundingDate" de la organización, si la página lo declara.
  let founding = null;
  for (const script of document.querySelectorAll('script[type="application/ld+json"]')) {
    const year = Number(script.textContent.match(/"foundingDate"\s*:\s*"((?:19|20)\d{2})/)?.[1]);
    if (valid(year) && (!founding || year < founding)) founding = year;
  }

  return { copyrightYear: copyright.length ? Math.min(...copyright) : null, foundingYear: founding };
}

// --- Estimación ---------------------------------------------------------------------

// Rango probable de creación del sitio:
//   - desde: no antes del registro del dominio,
//   - hasta: la evidencia más antigua de que el sitio ya existía (archive.org, copyright).
export function estimate({ created, firstCapture, copyrightYear }) {
  const registered = created ? new Date(created) : null;
  // "© 2018" demuestra que el sitio existía en algún momento de 2018: a más tardar el 31/12.
  const evidence = [
    firstCapture && { date: new Date(firstCapture), source: 'archive' },
    copyrightYear && { date: new Date(Date.UTC(copyrightYear, 11, 31)), source: 'copyright', year: copyrightYear },
  ]
    .filter(Boolean)
    .sort((a, b) => a.date - b.date);
  const earliest = evidence[0] || null;

  if (registered && earliest) {
    if (earliest.date >= registered) {
      return { kind: 'range', from: registered.toISOString(), to: earliest.date.toISOString(), basis: earliest.source, year: earliest.year };
    }
    // La evidencia es anterior al registro actual: el dominio caducó y se volvió a registrar,
    // o el copyright se refiere a la empresa y no al sitio.
    return { kind: 'before-registration', to: earliest.date.toISOString(), registered: registered.toISOString(), basis: earliest.source, year: earliest.year };
  }
  if (registered) return { kind: 'not-before', from: registered.toISOString() };
  if (earliest) return { kind: 'at-least', to: earliest.date.toISOString(), basis: earliest.source, year: earliest.year };
  return { kind: 'unknown' };
}

// --- Perfil completo -------------------------------------------------------------------

// Todo menos archive.org (ver waybackProfile).
export async function domainProfile({ tabId, url, ip: connectionIp, lastModified }) {
  const host = new URL(url).hostname;
  const domain = await registrableDomain(host);
  if (!domain) throw new Error('Esta página no tiene un dominio registrable (es una IP o un dominio local).');

  const [hints, rdap, ip] = await Promise.all([
    chrome.scripting
      .executeScript({ target: { tabId }, func: collectAgeHints })
      .then(([r]) => r.result)
      .catch(() => ({ copyrightYear: null, foundingYear: null })),
    safe(lookupRdap(domain)),
    connectionIp ? connectionIp : safe(resolveIp(host)).then((r) => (typeof r === 'string' ? r : null)),
  ]);

  const [ipInfo, network] = ip ? await Promise.all([safe(lookupIp(ip)), safe(lookupNetwork(ip))]) : [null, null];
  const asn = ipInfo?.asn ? { number: ipInfo.asn, org: ipInfo.org, ...(await safe(lookupAsn(ipInfo.asn))) } : null;

  return {
    host,
    domain,
    checkedAt: new Date().toISOString(),
    rdap,
    ip,
    ipInfo,
    network,
    asn,
    hints,
    lastModified: lastModified || null,
  };
}

// archive.org va aparte porque puede tardar mucho: el popup muestra el resto mientras tanto.
export function waybackProfile(domain) {
  return safe(lookupWayback(domain));
}
