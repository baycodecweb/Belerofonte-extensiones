import { prepare, buildQueries, analyze } from './engine.js';
import { domainProfile, registrableDomain, waybackProfile } from './domain.js';
import { startCapture, finishRegion, getCapture } from './capture.js';
import { startEyedropper } from './eyedropper.js';
import { startFontInspector, setupFontMenu } from './fontinspector.js';
import { listMedia, downloadMedia, prepareReferer } from './media.js';
import { openSimulator, configureSimulator } from './simulator.js';
import { wordpressProfile } from './wordpress.js';

const MAX_HTML = 500_000;
const MAX_CSS = 300_000;
const MAX_TYPO_ELEMENTS = 4000;

let dbPromise;

function loadDb() {
  dbPromise ??= fetch(chrome.runtime.getURL('data/technologies.json'))
    .then((res) => res.json())
    .then((raw) => {
      const prepared = prepare(raw);
      return { prepared, queries: buildQueries(prepared) };
    });
  return dbPromise;
}

// --- 1. Cabeceras HTTP del documento principal -------------------------------
// Se guardan en storage.session porque el service worker puede dormirse entre la
// carga de la página y el momento en que se abre el popup.

const headersKey = (tabId) => `headers:${tabId}`;

function headersToObject(list = []) {
  const out = {};
  for (const { name, value } of list) (out[name.toLowerCase()] ||= []).push(value ?? '');
  return out;
}

chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    if (details.tabId < 0) return;
    chrome.storage.session.set({
      [headersKey(details.tabId)]: { url: details.url, headers: headersToObject(details.responseHeaders) },
    });
  },
  { urls: ['<all_urls>'], types: ['main_frame'] },
  ['responseHeaders', 'extraHeaders'],
);

// IP del servidor que respondió de verdad (sin pasar por DNS de nuevo).
const ipKey = (tabId) => `ip:${tabId}`;

chrome.webRequest.onResponseStarted.addListener(
  (details) => {
    if (details.tabId < 0 || !details.ip) return;
    chrome.storage.session.set({ [ipKey(details.tabId)]: { url: details.url, ip: details.ip } });
  },
  { urls: ['<all_urls>'], types: ['main_frame'] },
);

const sameOrigin = (a, b) => {
  try {
    return new URL(a).origin === new URL(b).origin;
  } catch {
    return false;
  }
};

async function getHeaders(tabId, url) {
  const key = headersKey(tabId);
  const stored = (await chrome.storage.session.get(key))[key];
  if (stored && sameOrigin(stored.url, url)) return stored.headers;

  // La pestaña se cargó antes de instalar la extensión: se vuelve a pedir la página.
  try {
    const res = await fetch(url, { credentials: 'include', cache: 'no-store' });
    res.body?.cancel();
    const headers = {};
    res.headers.forEach((value, name) => (headers[name.toLowerCase()] ||= []).push(value));
    return headers;
  } catch {
    return {};
  }
}

// --- 2. Datos que se leen dentro de la página ---------------------------------
// Estas funciones se serializan y se ejecutan en la pestaña: no pueden usar nada
// de fuera de su propio cuerpo.

// Mundo aislado de la extensión: HTML, meta, scripts, CSS y selectores DOM.
function collectPage(domQueries, maxHtml, maxCss) {
  const meta = {};
  for (const el of document.querySelectorAll('meta')) {
    const key = (el.getAttribute('name') || el.getAttribute('property') || el.getAttribute('http-equiv') || '').toLowerCase();
    if (key) (meta[key] ||= []).push(el.getAttribute('content') || '');
  }

  // scripts: <script src> y scripts cargados después. resources: hojas de estilo,
  // archivos de fuentes, imágenes... (todo lo demás que la página ha descargado).
  const scripts = new Set([...document.scripts].map((s) => s.src).filter(Boolean));
  const resources = new Set([...document.querySelectorAll('link[href]')].map((l) => l.href));
  try {
    for (const entry of performance.getEntriesByType('resource')) {
      if (entry.initiatorType === 'script') scripts.add(entry.name);
      else if (resources.size < 1000) resources.add(entry.name);
    }
  } catch {}

  // El texto de <style> conserva los comentarios de cabecera (/*! tailwindcss v3.4 */)
  // que cssRules descarta. Las hojas de otro dominio lanzan SecurityError al leer cssRules.
  let css = '';
  for (const style of document.querySelectorAll('style')) {
    if (css.length > maxCss) break;
    css += style.textContent.slice(0, 2000) + '\n';
  }
  for (const sheet of document.styleSheets) {
    if (css.length > maxCss) break;
    try {
      for (const rule of sheet.cssRules) {
        css += rule.cssText + '\n';
        if (css.length > maxCss) break;
      }
    } catch {}
  }

  const dom = {};
  for (const { selector, attributes, text } of domQueries) {
    let el;
    try {
      el = document.querySelector(selector);
    } catch {
      continue;
    }
    if (!el) continue;
    const result = { attributes: {} };
    for (const name of attributes) {
      if (el.hasAttribute(name)) result.attributes[name] = el.getAttribute(name);
    }
    if (text) result.text = el.textContent.slice(0, 1000);
    dom[selector] = result;
  }

  return {
    url: location.href,
    html: document.documentElement.outerHTML.slice(0, maxHtml),
    meta,
    scripts: [...scripts],
    resources: [...resources],
    css: css.slice(0, maxCss),
    dom,
  };
}

// Mundo aislado: tipografía realmente usada. Para cada elemento con texto se mira su
// font-family calculada y se decide qué fuente de la pila se está pintando (la primera
// webfont cargada; si no hay ninguna, la primera de la lista, que será local o del sistema).
function collectTypography(maxElements) {
  const clean = (name) => name.trim().replace(/^["']|["']$/g, '');
  const norm = (name) => name.toLowerCase().replace(/[\s_-]+/g, '');
  const GENERIC = new Set(['serif', 'sans-serif', 'monospace', 'cursive', 'fantasy', 'system-ui', 'ui-sans-serif',
    'ui-serif', 'ui-monospace', 'ui-rounded', 'emoji', 'math', 'fangsong', '-apple-system', 'blinkmacsystemfont']);
  const ICON = /awesome|material (?:icons|symbols)|bootstrap-icons|ionicons|remixicon|icomoon|glyphicons|dashicons|eicons|feather|lucide|tabler|phosphor|boxicons/i;

  // 1. Webfonts declaradas con @font-face (document.fonts las incluye, se usen o no).
  const webfonts = new Map();
  for (const face of document.fonts) {
    const family = clean(face.family);
    const entry = webfonts.get(norm(family)) || { family, weights: new Set(), loaded: false };
    entry.weights.add(face.weight);
    if (face.status === 'loaded') entry.loaded = true;
    webfonts.set(norm(family), entry);
  }

  // 2. De dónde vienen: URLs de los archivos de fuente, enlaces a Google/Bunny Fonts
  //    y reglas @font-face legibles (las del mismo dominio).
  const PROVIDERS = [
    [/fonts\.(?:gstatic|googleapis)\.com$/, 'Google Fonts'],
    [/(?:use|p)\.typekit\.net$/, 'Adobe Fonts'],
    [/fonts\.bunny\.net$/, 'Bunny Fonts'],
    [/fontshare\.com$/, 'Fontshare'],
    [/fontawesome\.com$/, 'Font Awesome'],
    [/cdn\.jsdelivr\.net$/, 'jsDelivr'],
    [/cdnjs\.cloudflare\.com$/, 'cdnjs'],
    [/unpkg\.com$/, 'unpkg'],
  ];
  const providerOf = (url) => {
    try {
      const { host } = new URL(url, location.href);
      if (host === location.host) return 'Autoalojada';
      return PROVIDERS.find(([re]) => re.test(host))?.[1] || host;
    } catch {
      return null;
    }
  };

  const sourceByFamily = new Map();
  const fontFileProviders = new Set();
  try {
    for (const entry of performance.getEntriesByType('resource')) {
      if (!/\.(?:woff2?|ttf|otf|eot)(?:[?#]|$)|fonts\.gstatic\.com/i.test(entry.name)) continue;
      fontFileProviders.add(providerOf(entry.name));
      const slug = entry.name.match(/fonts\.gstatic\.com\/s\/([^/]+)\//)?.[1];
      if (slug) sourceByFamily.set(norm(slug), 'Google Fonts');
    }
  } catch {}
  for (const link of document.querySelectorAll('link[href*="fonts.googleapis.com"], link[href*="fonts.bunny.net"]')) {
    try {
      const url = new URL(link.href);
      for (const param of url.searchParams.getAll('family')) {
        for (const family of param.split('|')) sourceByFamily.set(norm(family.split(':')[0]), providerOf(url.href));
      }
    } catch {}
  }
  for (const sheet of document.styleSheets) {
    try {
      for (const rule of sheet.cssRules) {
        if (!(rule instanceof CSSFontFaceRule)) continue;
        const family = clean(rule.style.getPropertyValue('font-family'));
        const src = rule.style.getPropertyValue('src').match(/url\(\s*["']?([^"')]+)/)?.[1];
        if (family && src && !src.startsWith('data:')) {
          sourceByFamily.set(norm(family), providerOf(new URL(src, sheet.href || location.href).href));
        }
      }
    } catch {}
  }
  const onlyProvider = fontFileProviders.size === 1 ? [...fontFileProviders][0] : null;

  // 3. Uso real: caracteres de texto pintados con cada fuente.
  const usage = new Map();
  let total = 0;
  const elements = document.body ? document.body.getElementsByTagName('*') : [];
  for (let i = 0; i < elements.length && i < maxElements; i++) {
    const el = elements[i];
    if (el instanceof SVGElement || /^(?:SCRIPT|STYLE|NOSCRIPT|TEMPLATE)$/.test(el.tagName)) continue;
    let chars = 0;
    for (const node of el.childNodes) if (node.nodeType === Node.TEXT_NODE) chars += node.textContent.trim().length;
    if (!chars) continue;

    const style = getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden') continue;
    const stack = style.fontFamily.split(',').map(clean).filter(Boolean);
    const family = stack.find((f) => webfonts.get(norm(f))?.loaded) || stack[0] || 'desconocida';

    const role = el.closest('h1, h2, h3, h4, h5, h6, [role="heading"]') ? 'Títulos'
      : el.closest('pre, code, kbd, samp') ? 'Código' : 'Texto';
    const entry = usage.get(norm(family)) || { family, chars: 0, roles: new Map(), weights: new Set() };
    entry.chars += chars;
    entry.roles.set(role, (entry.roles.get(role) || 0) + chars);
    entry.weights.add(style.fontWeight);
    usage.set(norm(family), entry);
    total += chars;
  }

  // Las fuentes de iconos suelen pintarse con ::before, sin texto: se añaden aparte si están cargadas.
  for (const [key, font] of webfonts) {
    if (font.loaded && !usage.has(key) && ICON.test(font.family)) {
      usage.set(key, { family: font.family, chars: 0, roles: new Map([['Iconos', 1]]), weights: new Set() });
    }
  }

  const sortWeights = (set) => [...set].filter((w) => w !== 'normal' || set.size === 1).sort((a, b) => parseFloat(a) - parseFloat(b));

  return [...usage.entries()]
    .map(([key, entry]) => {
      const webfont = webfonts.get(key);
      const icon = ICON.test(entry.family);
      const source = webfont
        ? sourceByFamily.get(key) || onlyProvider || 'Webfont'
        : GENERIC.has(entry.family.toLowerCase()) ? 'Genérica del sistema' : 'Local / del sistema';
      return {
        family: entry.family,
        usage: total ? Math.round((entry.chars / total) * 1000) / 10 : 0,
        roles: icon ? ['Iconos'] : [...entry.roles].sort((a, b) => b[1] - a[1]).map(([role]) => role),
        weights: sortWeights(entry.weights.size ? entry.weights : webfont?.weights || new Set()),
        webfont: !!webfont,
        icon,
        source,
      };
    })
    .sort((a, b) => b.usage - a.usage)
    .slice(0, 12);
}

// Mundo principal de la página: variables globales (window.jQuery, window.Vue...)
// y propiedades internas que los frameworks dejan en los nodos (__reactFiber$..., __vue__).
function collectRuntime(paths, propPrefixes) {
  const js = {};
  for (const path of paths) {
    try {
      let value;
      if (path.endsWith('*') && !path.includes('.')) {
        const prefix = path.slice(0, -1);
        value = Object.keys(window).some((k) => k.startsWith(prefix)) || undefined;
      } else {
        value = path.split('.').reduce((obj, key) => (obj == null ? undefined : obj[key]), window);
      }
      if (value === undefined || value === null || value === false) continue;
      js[path] = ['string', 'number', 'boolean'].includes(typeof value) ? String(value) : true;
    } catch {}
  }

  const found = new Set();
  const nodes = document.querySelectorAll('html, body, body *');
  for (let i = 0; i < nodes.length && i < 400 && found.size < propPrefixes.length; i++) {
    for (const key of Object.keys(nodes[i])) {
      const prefix = propPrefixes.find((p) => key.startsWith(p));
      if (prefix) found.add(prefix);
    }
  }

  return { js, domProps: [...found] };
}

// --- 3. Análisis -------------------------------------------------------------

async function analyzeTab(tabId) {
  const tab = await chrome.tabs.get(tabId);
  if (!/^https?:/i.test(tab.url || '')) {
    throw new Error('Solo se pueden analizar páginas http:// o https://.');
  }

  const { prepared, queries } = await loadDb();
  const target = { tabId };

  let page, runtime, fonts;
  try {
    [[{ result: page }], [{ result: runtime }], [{ result: fonts }]] = await Promise.all([
      chrome.scripting.executeScript({ target, func: collectPage, args: [queries.dom, MAX_HTML, MAX_CSS] }),
      chrome.scripting.executeScript({ target, world: 'MAIN', func: collectRuntime, args: [queries.js, queries.domProps] }),
      chrome.scripting.executeScript({ target, func: collectTypography, args: [MAX_TYPO_ELEMENTS] }),
    ]);
  } catch (err) {
    throw new Error(`El navegador no permite inspeccionar esta página (${err.message}).`);
  }

  const [cookieList, headers] = await Promise.all([chrome.cookies.getAll({ url: tab.url }), getHeaders(tabId, tab.url)]);
  const cookies = Object.fromEntries(cookieList.map((c) => [c.name, c.value]));

  const technologies = analyze(prepared, { ...page, ...runtime, headers, cookies });

  chrome.action.setBadgeText({ tabId, text: technologies.length ? String(technologies.length) : '' });
  chrome.action.setBadgeBackgroundColor({ tabId, color: '#4f46e5' });

  return { url: page.url, title: tab.title, technologies, fonts, rules: prepared.technologies.length };
}

// Analiza cada página al terminar de cargar para mostrar el número en el icono.
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status !== 'complete' || !/^https?:/i.test(tab.url || '')) return;
  // Margen para que los scripts de la página terminen de definir sus variables.
  setTimeout(() => analyzeTab(tabId).catch(() => {}), 1000);
});

chrome.tabs.onRemoved.addListener((tabId) => chrome.storage.session.remove([headersKey(tabId), ipKey(tabId)]));

// --- 4. Perfil del dominio (solo bajo demanda, desde el botón del popup) ----------

const DOMAIN_CACHE_MS = 6 * 60 * 60 * 1000;

async function domainTab(tabId, refresh) {
  const tab = await chrome.tabs.get(tabId);
  if (!/^https?:/i.test(tab.url || '')) throw new Error('Solo se pueden consultar páginas http:// o https://.');

  const domain = await registrableDomain(new URL(tab.url).hostname);
  const cacheKey = `domain:${domain}`;
  if (domain && !refresh) {
    const cached = (await chrome.storage.session.get(cacheKey))[cacheKey];
    if (cached && Date.now() - Date.parse(cached.checkedAt) < DOMAIN_CACHE_MS) return { ...cached, cached: true };
  }

  const stored = (await chrome.storage.session.get(ipKey(tabId)))[ipKey(tabId)];
  const headers = await getHeaders(tabId, tab.url);
  const profile = await domainProfile({
    tabId,
    url: tab.url,
    ip: stored && sameOrigin(stored.url, tab.url) ? stored.ip : null,
    lastModified: headers['last-modified']?.[0],
  });
  if (domain) await chrome.storage.session.set({ [cacheKey]: profile });
  return profile;
}

// Solo se guardan en caché las respuestas buenas de archive.org (no los errores temporales).
async function waybackDomain(domain, refresh) {
  const cacheKey = `wayback:${domain}`;
  if (!refresh) {
    const cached = (await chrome.storage.session.get(cacheKey))[cacheKey];
    if (cached && Date.now() - cached.checkedAt < DOMAIN_CACHE_MS) return cached.result;
  }
  const result = await waybackProfile(domain);
  if (!result.error) await chrome.storage.session.set({ [cacheKey]: { checkedAt: Date.now(), result } });
  return result;
}

// --- 5. Análisis de WordPress (solo bajo demanda, desde el botón del popup) --------

const WP_CACHE_MS = 60 * 60 * 1000;

async function wordpressTab(tabId, refresh) {
  const tab = await chrome.tabs.get(tabId);
  if (!/^https?:/i.test(tab.url || '')) throw new Error('Solo se pueden analizar páginas http:// o https://.');

  const cacheKey = `wp:${new URL(tab.url).origin}`;
  if (!refresh) {
    const cached = (await chrome.storage.session.get(cacheKey))[cacheKey];
    if (cached && Date.now() - Date.parse(cached.checkedAt) < WP_CACHE_MS) return { ...cached, cached: true };
  }
  const profile = await wordpressProfile({ tabId });
  if (profile.isWordPress) await chrome.storage.session.set({ [cacheKey]: profile });
  return profile;
}

// Menú contextual «Identificar fuente».
setupFontMenu();

const HANDLERS = {
  analyze: (message) => analyzeTab(message.tabId),
  domain: (message) => domainTab(message.tabId, message.refresh),
  wayback: (message) => waybackDomain(message.domain, message.refresh),
  wordpress: (message) => wordpressTab(message.tabId, message.refresh),
  capture: (message) => startCapture(message),
  'capture-region': (message, sender) => finishRegion(message, sender),
  'capture-get': (message) => getCapture(message),
  eyedropper: (message, sender) => startEyedropper(message, sender),
  'font-inspect': (message) => startFontInspector(message),
  'media-list': (message) => listMedia(message),
  'media-download': (message) => downloadMedia(message),
  'media-referer': (message, sender) => prepareReferer(message, sender),
  'sim-open': (message) => openSimulator(message),
  'sim-config': (message, sender) => configureSimulator(message, sender),
};

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const handler = HANDLERS[message?.type];
  if (!handler) return;
  handler(message, sender)
    .then((result) => sendResponse({ ok: true, ...result }))
    .catch((err) => sendResponse({ ok: false, error: err.message }));
  return true;
});
