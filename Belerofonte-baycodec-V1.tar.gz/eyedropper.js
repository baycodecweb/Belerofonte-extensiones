// Cuentagotas: congela lo que se ve en la pestaña (captura) y deja elegir un píxel con una lupa.
// Muestra el color en HEX, RGB y HSL y lo guarda en el historial (chrome.storage.local).

// --- Función que se ejecuta dentro de la página ---------------------------------------

async function pickColor(dataUrl, historyKey, historySize) {
  document.getElementById('__eyedropper')?.remove();

  const img = new Image();
  img.src = dataUrl;
  await img.decode();
  const pixels = document.createElement('canvas');
  pixels.width = img.naturalWidth;
  pixels.height = img.naturalHeight;
  const pctx = pixels.getContext('2d', { willReadFrequently: true });
  pctx.drawImage(img, 0, 0);
  const scale = img.naturalWidth / window.innerWidth;

  // --- Formatos de color ---
  const hex = ([r, g, b]) => '#' + [r, g, b].map((v) => v.toString(16).padStart(2, '0')).join('').toUpperCase();
  const rgb = ([r, g, b]) => `rgb(${r}, ${g}, ${b})`;
  // [r, g, b] → [h (0-360), s (0-1), l (0-1)]
  const toHsl = ([r, g, b]) => {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    const l = (max + min) / 2;
    let h = 0;
    let s = 0;
    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      h = max === r ? (g - b) / d + (g < b ? 6 : 0) : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
      h *= 60;
    }
    return [h, s, l];
  };
  const fromHsl = (h, s, l) => {
    h = ((h % 360) + 360) % 360;
    const a = s * Math.min(l, 1 - l);
    const f = (n) => {
      const k = (n + h / 30) % 12;
      return Math.round(255 * (l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1))));
    };
    return [f(0), f(8), f(4)];
  };
  const hsl = (color) => {
    const [h, s, l] = toHsl(color);
    return `hsl(${Math.round(h)}, ${Math.round(s * 100)}%, ${Math.round(l * 100)}%)`;
  };

  // Colores que combinan con el elegido: cada armonía da 3 colores además del principal.
  // Los grises casi no tienen tono, así que girar el círculo cromático no cambia nada:
  // para ellos solo se proponen tonos más claros y más oscuros.
  const harmonies = (color) => {
    const [h, s, l] = toHsl(color);
    const clamp = (v) => Math.min(0.95, Math.max(0.08, v));
    const shades = l > 0.6 ? [l - 0.45, l - 0.3, l - 0.15] : l < 0.3 ? [l + 0.15, l + 0.3, l + 0.45] : [l - 0.2, l + 0.15, l + 0.3];
    const mono = { name: 'Monocromática', info: 'Mismo tono, más claro y más oscuro', colors: shades.map((v) => fromHsl(h, s, clamp(v))) };
    if (s < 0.08) return [{ ...mono, info: 'Es un color neutro: combina con sus tonos más claros y oscuros' }];
    const rotate = (degrees) => degrees.map((d) => fromHsl(h + d, s, l));
    return [
      { name: 'Análogos', info: 'Vecinos en el círculo cromático: armonía suave', colors: rotate([-30, 30, 60]) },
      { name: 'Complementarios', info: 'El opuesto y sus vecinos: máximo contraste', colors: rotate([150, 180, 210]) },
      { name: 'Cuadrada', info: 'Repartidos cada 90°: paleta variada y equilibrada', colors: rotate([90, 180, 270]) },
      mono,
    ];
  };
  const colorAt = (x, y) => {
    const px = Math.min(pixels.width - 1, Math.max(0, Math.floor(x * scale)));
    const py = Math.min(pixels.height - 1, Math.max(0, Math.floor(y * scale)));
    return [...pctx.getImageData(px, py, 1, 1).data.slice(0, 3)];
  };
  // Texto claro u oscuro según la luminosidad del color de fondo.
  const textOn = ([r, g, b]) => (0.299 * r + 0.587 * g + 0.114 * b > 150 ? '#111' : '#fff');

  async function copy(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      // Páginas http:// o sin foco: método clásico.
      const area = Object.assign(document.createElement('textarea'), { value: text });
      area.style.cssText = 'position:fixed;opacity:0;';
      document.body.append(area);
      area.select();
      const ok = document.execCommand('copy');
      area.remove();
      return ok;
    }
  }

  const host = document.createElement('div');
  host.id = '__eyedropper';
  const shadow = host.attachShadow({ mode: 'closed' });
  shadow.innerHTML = `
    <style>
      * { box-sizing: border-box; }
      .layer { position: fixed; left: 0; top: 0; z-index: 2147483647; cursor: crosshair;
               background-repeat: no-repeat; background-position: 0 0; }
      .loupe { position: fixed; z-index: 2147483647; pointer-events: none; display: none;
               border-radius: 12px; overflow: hidden; background: #17171c; box-shadow: 0 8px 24px rgba(0,0,0,.45);
               border: 2px solid #fff; }
      .loupe canvas { display: block; image-rendering: pixelated; }
      .loupe .label { display: flex; align-items: center; gap: 6px; padding: 5px 8px;
                      font: 600 12px/1 ui-monospace, Menlo, Consolas, monospace; color: #ececf1; }
      .loupe .dot { width: 12px; height: 12px; border-radius: 3px; border: 1px solid rgba(255,255,255,.5); }
      .hint { position: fixed; top: 16px; left: 50%; transform: translateX(-50%); z-index: 2147483647;
              padding: 8px 14px; border-radius: 8px; background: #17171c; color: #ececf1;
              font: 13px/1.4 system-ui, sans-serif; pointer-events: none; }
      .card { position: fixed; top: 16px; right: 16px; z-index: 2147483647; width: 280px; padding: 14px;
              border-radius: 12px; background: #fff; color: #1c1c22; border: 1px solid #e4e4ea;
              box-shadow: 0 12px 32px rgba(0,0,0,.25); font: 13px/1.4 system-ui, sans-serif; }
      .card__head { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; }
      .swatch { width: 48px; height: 48px; border-radius: 10px; border: 1px solid rgba(0,0,0,.15);
                display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 700; }
      .card__title { flex: 1; font-weight: 700; }
      .card__title small { display: block; font-weight: 400; color: #6b6b78; }
      .close { border: 0; background: none; font-size: 18px; line-height: 1; color: #6b6b78; cursor: pointer; padding: 4px; }
      .row { display: flex; align-items: center; gap: 8px; padding: 5px 0; border-top: 1px solid #f0f0f4; }
      .row b { width: 34px; font-size: 11px; color: #6b6b78; }
      .row code { flex: 1; font: 12.5px ui-monospace, Menlo, Consolas, monospace; user-select: all; }
      .btn { padding: 4px 9px; border: 1px solid #e4e4ea; border-radius: 6px; background: #f5f5f7; color: #1c1c22;
             font: 600 11.5px system-ui, sans-serif; cursor: pointer; }
      .btn:hover { border-color: #4f46e5; color: #4f46e5; }
      .card { max-height: calc(100vh - 32px); overflow: auto; }
      .palettes { margin-top: 8px; padding-top: 8px; border-top: 1px solid #f0f0f4; }
      .palettes__title { font-weight: 700; margin-bottom: 2px; }
      .palette { padding: 6px 0; }
      .palette__head { display: flex; flex-wrap: wrap; align-items: center; gap: 0 6px; }
      .palette__head b { flex: 1; font-size: 12px; }
      .palette__head small { order: 3; flex-basis: 100%; font-size: 11px; color: #6b6b78; }
      .palette__head .btn { padding: 2px 7px; font-size: 11px; }
      .palette__colors { display: flex; gap: 4px; margin-top: 4px; }
      .chip { flex: 1; min-width: 0; padding: 0; border: 0; background: none; cursor: pointer; color: inherit; }
      .chip span { display: block; height: 30px; border-radius: 6px; border: 1px solid rgba(0,0,0,.12); }
      .chip code { display: block; margin-top: 2px; text-align: center; font: 10px ui-monospace, Menlo, Consolas, monospace; }
      .chip--main span { box-shadow: inset 0 0 0 2px rgba(255,255,255,.7); border-color: rgba(0,0,0,.35); }
      .chip:hover span { transform: translateY(-1px); border-color: #4f46e5; }
      .again { width: 100%; margin-top: 10px; padding: 8px; border-color: #4f46e5; background: #4f46e5; color: #fff; }
      .again:hover { color: #fff; filter: brightness(1.1); }
      @media (prefers-color-scheme: dark) {
        .card { background: #17171c; color: #ececf1; border-color: #2e2e37; }
        .card__title small, .row b, .close { color: #9a9aa8; }
        .row, .palettes { border-top-color: #2e2e37; }
        .palette__head small { color: #9a9aa8; }
        .btn { background: #212128; color: #ececf1; border-color: #2e2e37; }
        .again { background: #4f46e5; border-color: #4f46e5; color: #fff; }
      }
    </style>
    <div class="layer"></div>
    <div class="loupe"><canvas width="132" height="132"></canvas><div class="label"><span class="dot"></span><span class="hex"></span></div></div>
    <div class="hint">Haz clic para elegir un color · Esc para cancelar</div>`;

  const layer = shadow.querySelector('.layer');
  const loupe = shadow.querySelector('.loupe');
  const lens = loupe.querySelector('canvas');
  const lctx = lens.getContext('2d');
  const dot = loupe.querySelector('.dot');
  const label = loupe.querySelector('.hex');
  const hint = shadow.querySelector('.hint');

  // La captura se pinta encima de la página al mismo tamaño: lo que ves es lo que eliges.
  Object.assign(layer.style, {
    width: `${window.innerWidth}px`,
    height: `${window.innerHeight}px`,
    backgroundImage: `url("${dataUrl}")`,
    backgroundSize: `${window.innerWidth}px ${window.innerHeight}px`,
  });

  const ZOOM_PIXELS = 11; // píxeles de la captura que se ven en la lupa (impar: hay uno central)
  const cell = lens.width / ZOOM_PIXELS;
  lctx.imageSmoothingEnabled = false;

  function drawLoupe(x, y) {
    const cx = Math.floor(x * scale);
    const cy = Math.floor(y * scale);
    const half = Math.floor(ZOOM_PIXELS / 2);
    lctx.fillStyle = '#000';
    lctx.fillRect(0, 0, lens.width, lens.height);
    lctx.drawImage(pixels, cx - half, cy - half, ZOOM_PIXELS, ZOOM_PIXELS, 0, 0, lens.width, lens.height);
    // Rejilla y píxel central.
    lctx.strokeStyle = 'rgba(255,255,255,.12)';
    lctx.lineWidth = 1;
    for (let i = 1; i < ZOOM_PIXELS; i++) {
      lctx.beginPath(); lctx.moveTo(i * cell, 0); lctx.lineTo(i * cell, lens.height); lctx.stroke();
      lctx.beginPath(); lctx.moveTo(0, i * cell); lctx.lineTo(lens.width, i * cell); lctx.stroke();
    }
    lctx.strokeStyle = '#fff';
    lctx.lineWidth = 2;
    lctx.strokeRect(half * cell, half * cell, cell, cell);

    const color = colorAt(x, y);
    dot.style.background = hex(color);
    label.textContent = hex(color);

    // La lupa sigue al cursor y se da la vuelta cerca de los bordes.
    const w = loupe.offsetWidth || 136;
    const h = loupe.offsetHeight || 160;
    const left = x + 20 + w > window.innerWidth ? x - 20 - w : x + 20;
    const top = y + 20 + h > window.innerHeight ? y - 20 - h : y + 20;
    loupe.style.left = `${left}px`;
    loupe.style.top = `${top}px`;
  }

  function close() {
    host.remove();
    document.removeEventListener('keydown', onKey, true);
  }
  function onKey(event) {
    if (event.key !== 'Escape') return;
    event.preventDefault();
    event.stopPropagation();
    close();
  }

  function showCard(color) {
    layer.remove();
    loupe.remove();
    hint.remove();

    const formats = [['HEX', hex(color)], ['RGB', rgb(color)], ['HSL', hsl(color)]];
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
      <div class="card__head">
        <div class="swatch"></div>
        <div class="card__title">Color elegido<small class="status"></small></div>
        <button class="close" title="Cerrar" aria-label="Cerrar">×</button>
      </div>
      ${formats.map(([name]) => `<div class="row"><b>${name}</b><code></code><button class="btn">Copiar</button></div>`).join('')}
      <button class="btn again">🎨 Elegir otro color</button>`;
    const swatch = card.querySelector('.swatch');
    swatch.style.background = hex(color);
    swatch.style.color = textOn(color);
    swatch.textContent = 'Aa';
    const status = card.querySelector('.status');

    card.querySelectorAll('.row').forEach((row, i) => {
      const [name, value] = formats[i];
      row.querySelector('code').textContent = value;
      const button = row.querySelector('.btn');
      button.addEventListener('click', async () => {
        button.textContent = (await copy(value)) ? '✓' : '✗';
        status.textContent = `${name} copiado`;
        setTimeout(() => (button.textContent = 'Copiar'), 1200);
      });
    });
    // Paletas: clic en un color copia su HEX; "Copiar" copia los cuatro de la fila.
    const palettes = document.createElement('div');
    palettes.className = 'palettes';
    palettes.innerHTML = '<div class="palettes__title">Colores que combinan</div>';
    for (const { name, info, colors } of harmonies(color)) {
      const values = [color, ...colors].map(hex);
      const palette = document.createElement('div');
      palette.className = 'palette';
      palette.innerHTML = `
        <div class="palette__head"><b></b><small></small><button class="btn">Copiar</button></div>
        <div class="palette__colors">${values.map((_, i) => `<button class="chip${i ? '' : ' chip--main'}"><span></span><code></code></button>`).join('')}</div>`;
      palette.querySelector('b').textContent = name;
      palette.querySelector('small').textContent = info;
      palette.querySelectorAll('.chip').forEach((chip, i) => {
        chip.title = i ? `${values[i]} · clic para copiar` : `${values[i]} · color elegido`;
        chip.querySelector('span').style.background = values[i];
        chip.querySelector('code').textContent = values[i];
        chip.addEventListener('click', async () => {
          status.textContent = (await copy(values[i])) ? `${values[i]} copiado` : 'No se pudo copiar';
        });
      });
      const button = palette.querySelector('.btn');
      button.addEventListener('click', async () => {
        button.textContent = (await copy(values.join(', '))) ? '✓' : '✗';
        status.textContent = `Paleta ${name.toLowerCase()} copiada`;
        setTimeout(() => (button.textContent = 'Copiar'), 1200);
      });
      palettes.append(palette);
    }
    card.querySelector('.again').before(palettes);

    card.querySelector('.close').addEventListener('click', close);
    card.querySelector('.again').addEventListener('click', () => {
      close();
      // Se espera a que desaparezca la tarjeta antes de volver a capturar.
      requestAnimationFrame(() => requestAnimationFrame(() => chrome.runtime.sendMessage({ type: 'eyedropper' })));
    });
    shadow.append(card);

    copy(hex(color)).then((ok) => (status.textContent = ok ? `${hex(color)} copiado al portapapeles` : ''));
  }

  async function saveToHistory(value) {
    try {
      const list = (await chrome.storage.local.get(historyKey))[historyKey] || [];
      const next = [value, ...list.filter((c) => c !== value)].slice(0, historySize);
      await chrome.storage.local.set({ [historyKey]: next });
    } catch {}
  }

  layer.addEventListener('pointermove', (event) => {
    loupe.style.display = 'block';
    hint.style.display = 'none';
    drawLoupe(event.clientX, event.clientY);
  });
  layer.addEventListener('pointerleave', () => (loupe.style.display = 'none'));
  layer.addEventListener('click', (event) => {
    const color = colorAt(event.clientX, event.clientY);
    saveToHistory(hex(color));
    showCard(color);
  });
  // Si la ventana cambia de tamaño, la captura ya no coincide con la página: se cancela.
  window.addEventListener('resize', close, { once: true });

  document.addEventListener('keydown', onKey, true);
  document.documentElement.append(host);
}

// --- Service worker -----------------------------------------------------------------

export const COLOR_HISTORY_KEY = 'eyedropperColors';
const HISTORY_SIZE = 12;

// Desde el popup ({ tabId }) o desde el botón "Elegir otro color" de la página (sender.tab).
export async function startEyedropper(message, sender) {
  const tab = await chrome.tabs.get(message.tabId ?? sender.tab.id);
  if (!/^https?:/i.test(tab.url || '')) throw new Error('Solo se pueden usar en páginas http:// o https://.');
  if (!tab.active) throw new Error('La pestaña tiene que estar visible.');
  try {
    // Quita la tarjeta del color anterior para que no salga en la captura.
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const old = document.getElementById('__eyedropper');
        if (!old) return;
        old.remove();
        return new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
      },
    });
    const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: pickColor,
      args: [dataUrl, COLOR_HISTORY_KEY, HISTORY_SIZE],
    });
  } catch (err) {
    throw new Error(`No se pudo abrir el cuentagotas (${err.message}).`);
  }
  return {};
}
