// Análisis de WordPress: versión del núcleo, tema y plugins con sus versiones.
// Solo usa archivos públicos (los que cualquier visitante puede abrir) y compara con
// WordPress.org para saber si están al día. No prueba rutas a ciegas ni fuerza nada.

const TIMEOUT = 10_000;
const MAX_HTML = 1_500_000;
const MAX_PLUGINS = 40;
const CONCURRENCY = 6;

// --- Datos que se leen dentro de la página -----------------------------------------
// Se serializa y se ejecuta en la pestaña: no puede usar nada de fuera de su cuerpo.

function collectWordPressHints(maxHtml) {
  const urls = new Set();
  const add = (value) => {
    if (!value) return;
    try {
      urls.add(new URL(value, document.baseURI).href);
    } catch {}
  };
  for (const node of document.querySelectorAll('[src], [href], [data-src], [srcset]')) {
    add(node.getAttribute('src'));
    add(node.getAttribute('href'));
    add(node.getAttribute('data-src'));
    for (const part of (node.getAttribute('srcset') || '').split(',')) add(part.trim().split(/\s+/)[0]);
  }
  try {
    for (const entry of performance.getEntriesByType('resource')) urls.add(entry.name);
  } catch {}

  const comments = [];
  const walker = document.createTreeWalker(document.documentElement, NodeFilter.SHOW_COMMENT);
  while (walker.nextNode() && comments.length < 400) comments.push(walker.currentNode.nodeValue.slice(0, 300));

  return {
    url: location.href,
    html: document.documentElement.outerHTML.slice(0, maxHtml),
    urls: [...urls],
    comments,
    generators: [...document.querySelectorAll('meta[name="generator" i]')].map((m) => m.content || ''),
    restRoot: document.querySelector('link[rel="https://api.w.org/"]')?.href || null,
  };
}

// --- Utilidades -----------------------------------------------------------------------

const VERSION = /^\d+(?:\.\d+)+(?:[-.]?(?:alpha|beta|rc)[\w.-]*)?$/i;
const isVersion = (v) => typeof v === 'string' && VERSION.test(v);

// -1, 0 o 1. "6.6" < "6.6.1"; las pre-versiones (beta, rc) van antes de la final.
function compareVersions(a, b) {
  const parse = (v) => {
    const [main, pre = ''] = String(v).split(/-(.*)/s);
    return { nums: main.split('.').map((n) => parseInt(n, 10) || 0), pre };
  };
  const x = parse(a);
  const y = parse(b);
  for (let i = 0; i < Math.max(x.nums.length, y.nums.length); i++) {
    const d = (x.nums[i] || 0) - (y.nums[i] || 0);
    if (d) return Math.sign(d);
  }
  if (x.pre && !y.pre) return -1;
  if (!x.pre && y.pre) return 1;
  return 0;
}

async function fetchText(url, { credentials = 'omit' } = {}) {
  const res = await fetch(url, { signal: AbortSignal.timeout(TIMEOUT), credentials, cache: 'no-store' });
  if (!res.ok) {
    const err = new Error(`HTTP ${res.status}`);
    err.status = res.status;
    throw err;
  }
  return res.text();
}

async function fetchJson(url) {
  return JSON.parse(await fetchText(url));
}

// Devuelve null si falla: cada pista es opcional.
const attempt = (promise) => promise.catch(() => null);

async function mapLimit(items, limit, fn) {
  const out = new Array(items.length);
  let next = 0;
  const worker = async () => {
    while (next < items.length) {
      const i = next++;
      out[i] = await fn(items[i], i);
    }
  };
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, worker));
  return out;
}

// El valor más repetido (la versión de un plugin aparece en todos sus ?ver=).
function mostCommon(values) {
  const counts = new Map();
  for (const v of values) counts.set(v, (counts.get(v) || 0) + 1);
  return [...counts].sort((a, b) => b[1] - a[1])[0]?.[0] || null;
}

// Cabecera de style.css o readme.txt ("Theme Name: Astra", "Stable tag: 4.2").
function headerField(text, name) {
  const match = text.slice(0, 8192).match(new RegExp(`^[\\s*#@]*${name}\\s*:\\s*(.+)$`, 'im'));
  return match ? match[1].trim().replace(/\s*\*\/\s*$/, '') : null;
}

const decodeEntities = (s) =>
  s.replace(/&#0*38;|&amp;/g, '&').replace(/&#8211;|&ndash;/g, '–').replace(/&#8217;|&rsquo;/g, '’').replace(/&#0*39;/g, "'");

// --- Rutas de wp-content: temas y plugins con sus ?ver= ------------------------------

// /wp-content/(themes|plugins)/<slug>/… y también las carpetas de Bedrock (/app/…).
const CONTENT_PATH = /^(.*?\/(?:wp-content|app|content))\/(themes|plugins|mu-plugins)\/([\w.-]+)\//i;

// Archivos de wp-includes cuyo ?ver= es la versión de WordPress (los de dist/ usan un hash).
const CORE_ASSET = /\/wp-includes\/(?:js\/wp-emoji-release(?:\.min)?\.js|css\/dist\/block-library\/[\w-]+(?:\.min)?\.css|blocks\/[\w-]+\/[\w-]+(?:\.min)?\.css|css\/dashicons(?:\.min)?\.css|css\/admin-bar(?:\.min)?\.css|js\/wp-embed(?:\.min)?\.js|js\/comment-reply(?:\.min)?\.js|css\/classic-themes(?:\.min)?\.css)$/i;

function scanAssets(hints) {
  // Las URLs del HTML también cuentan (incluidas las escritas en JSON como https:\/\/…).
  const html = hints.html.replace(/\\\//g, '/');
  const all = new Set(hints.urls);
  for (const match of html.matchAll(/(?:https?:)?\/\/[^\s"'<>()\\]+|\/(?:wp-content|wp-includes|app)\/[^\s"'<>()\\]+/gi)) {
    try {
      all.add(new URL(decodeEntities(match[0]), hints.url).href);
    } catch {}
  }

  const page = new URL(hints.url);
  const items = { themes: new Map(), plugins: new Map() };
  const coreVers = [];
  const bases = new Map();
  let usesWordPressPaths = false;

  for (const href of all) {
    let url;
    try {
      url = new URL(href);
    } catch {
      continue;
    }
    if (!/^https?:$/.test(url.protocol)) continue;
    const ver = url.searchParams.get('ver');

    if (url.pathname.includes('/wp-includes/')) {
      usesWordPressPaths = true;
      if (CORE_ASSET.test(url.pathname) && isVersion(ver)) coreVers.push(ver);
      continue;
    }

    const match = url.pathname.match(CONTENT_PATH);
    if (!match) continue;
    const [, base, kind, slug] = match;
    // /app/ y /content/ solo cuentan en el propio sitio (Bedrock); en otros dominios son otra cosa.
    if (!/wp-content$/i.test(base) && url.host !== page.host) continue;
    if (/wp-content$/i.test(base)) usesWordPressPaths = true;

    const baseUrl = url.origin + base;
    bases.set(baseUrl, (bases.get(baseUrl) || 0) + (url.host === page.host ? 2 : 1));

    const group = kind.toLowerCase() === 'themes' ? items.themes : items.plugins;
    if (!group.has(slug)) group.set(slug, { slug, mu: kind.toLowerCase() === 'mu-plugins', refs: 0, vers: [], base: baseUrl });
    const item = group.get(slug);
    item.refs++;
    if (isVersion(ver)) item.vers.push(ver);
  }

  const contentBase = [...bases].sort((a, b) => b[1] - a[1])[0]?.[0] || `${page.origin}/wp-content`;
  return { ...items, coreVers, contentBase, usesWordPressPaths };
}

// --- Firmas: comentarios HTML y <meta name="generator"> de plugins conocidos --------

// slugs: el primero es el que se usa si no aparece ninguno en las rutas de la página.
const SIGNATURES = [
  { slugs: ['wordpress-seo', 'wordpress-seo-premium'], name: 'Yoast SEO', re: /optimized with the Yoast (?:WordPress )?SEO (?:Premium )?plugin v([\d.]+)/i },
  { slugs: ['all-in-one-seo-pack-pro'], name: 'All in One SEO Pro', re: /All in One SEO Pro ([\d.]+)/i },
  { slugs: ['all-in-one-seo-pack'], name: 'All in One SEO', re: /All in One SEO (?!Pro)([\d.]+)/i },
  { slugs: ['seo-by-rank-math', 'seo-by-rank-math-pro'], name: 'Rank Math SEO', re: /Search Engine Optimization by Rank Math/i },
  { slugs: ['google-analytics-for-wordpress', 'google-analytics-premium'], name: 'MonsterInsights', re: /Google Analytics by MonsterInsights plugin v([\d.]+)/i },
  { slugs: ['google-site-kit'], name: 'Site Kit by Google', re: /Site Kit by Google ([\d.]+)/i },
  { slugs: ['litespeed-cache'], name: 'LiteSpeed Cache', re: /(?:optimized|generated) by LiteSpeed Cache ([\d.]+)/i },
  { slugs: ['w3-total-cache'], name: 'W3 Total Cache', re: /Performance optimized by W3 Total Cache/i },
  { slugs: ['wp-super-cache'], name: 'WP Super Cache', re: /(?:generated|served) by WP-Super-Cache/i },
  { slugs: ['wp-fastest-cache'], name: 'WP Fastest Cache', re: /WP Fastest Cache file was created/i },
  { slugs: ['wp-rocket'], name: 'WP Rocket', re: /This website is like a Rocket/i },
  { slugs: ['elementor'], name: 'Elementor', re: /^Elementor ([\d.]+)/i },
  { slugs: ['woocommerce'], name: 'WooCommerce', re: /^WooCommerce ([\d.]+)/i },
  { slugs: ['revslider'], name: 'Slider Revolution', re: /Powered by Slider Revolution ([\d.]+)/i },
  { slugs: ['js_composer'], name: 'WPBakery Page Builder', re: /Powered by WPBakery Page Builder/i },
  { slugs: ['sitepress-multilingual-cms'], name: 'WPML', re: /WPML ver:([\d.]+)/i },
];

// API REST (/wp-json/): cada plugin registra su espacio de nombres.
const NAMESPACES = {
  'contact-form-7': 'contact-form-7',
  yoast: 'wordpress-seo',
  wc: 'woocommerce',
  'wc-analytics': 'woocommerce',
  'wc-admin': 'woocommerce',
  elementor: 'elementor',
  'elementor-pro': 'elementor-pro',
  jetpack: 'jetpack',
  'jetpack-boost': 'jetpack-boost',
  rankmath: 'seo-by-rank-math',
  litespeed: 'litespeed-cache',
  wordfence: 'wordfence',
  akismet: 'akismet',
  redirection: 'redirection',
  aioseo: 'all-in-one-seo-pack',
  'google-site-kit': 'google-site-kit',
  wpforms: 'wpforms-lite',
  monsterinsights: 'google-analytics-for-wordpress',
  complianz: 'complianz-gdpr',
  gf: 'gravityforms',
  'wp-statistics': 'wp-statistics',
  updraftplus: 'updraftplus',
  wpml: 'sitepress-multilingual-cms',
  'regenerate-thumbnails': 'regenerate-thumbnails',
  'two-factor': 'two-factor',
  'wp-smush': 'wp-smushit',
  smush: 'wp-smushit',
  'the-events-calendar': 'the-events-calendar',
  tribe: 'the-events-calendar',
  ssp: 'seriously-simple-podcasting',
  'fluent-forms': 'fluentform',
  fluentform: 'fluentform',
  mailpoet: 'mailpoet',
  'ninja-forms': 'ninja-forms',
  wpcode: 'insert-headers-and-footers',
  'cookie-law-info': 'cookie-law-info',
  woocommerce: 'woocommerce',
  'woocommerce-analytics': 'woocommerce',
  'my-jetpack': 'jetpack',
  'wp-parsely': 'wp-parsely',
  coauthors: 'co-authors-plus',
  'safe-svg': 'safe-svg',
  elasticpress: 'elasticpress',
  'apple-news': 'publish-to-apple-news',
  'simple-page-ordering': 'simple-page-ordering',
  automatewoo: 'automatewoo',
};

// Espacios del núcleo de WordPress (no son plugins).
const CORE_NAMESPACE = /^(?:oembed|wp|wp-site-health|wp-block-editor|wp-abilities|batch)$/;

// --- Lecturas de archivos públicos del sitio --------------------------------------------

async function coreFromFeed(root) {
  const text = await fetchText(`${root}/feed/`);
  return text.match(/<generator>https?:\/\/wordpress\.org\/\?v=([^<\s]+)<\/generator>/i)?.[1] || null;
}

async function coreFromOpml(root) {
  const text = await fetchText(`${root}/wp-links-opml.php`);
  return text.match(/generator="WordPress\/([^"\s]+)"/i)?.[1] || null;
}

async function coreFromReadme(root) {
  const text = await fetchText(`${root}/readme.html`);
  if (!/wordpress/i.test(text.slice(0, 3000))) return null;
  return text.match(/<br\s*\/?>\s*(?:Version|Versión)\s+([\d.]+)/i)?.[1] || null;
}

async function restIndex(restRoot) {
  const sep = restRoot.includes('?') ? '&' : '?';
  const data = await fetchJson(`${restRoot}${sep}_fields=name,description,namespaces`);
  return Array.isArray(data?.namespaces) ? data : null;
}

async function readStyle(base, slug) {
  const text = await fetchText(`${base}/themes/${slug}/style.css`);
  if (!/Theme Name\s*:/i.test(text.slice(0, 8192))) return null;
  return {
    name: headerField(text, 'Theme Name'),
    version: headerField(text, 'Version'),
    author: headerField(text, 'Author'),
    uri: headerField(text, 'Theme URI'),
    template: headerField(text, 'Template'),
  };
}

async function readReadme(base, slug) {
  for (const file of ['readme.txt', 'README.txt']) {
    const text = await attempt(fetchText(`${base}/plugins/${slug}/${file}`));
    if (!text || !/^\s*===|Stable tag\s*:/im.test(text.slice(0, 4096))) continue;
    const stable = headerField(text, 'Stable tag');
    return {
      name: text.match(/^\s*===\s*(.+?)\s*===/m)?.[1] || null,
      version: isVersion(stable) ? stable : null,
    };
  }
  return null;
}

// --- WordPress.org: última versión publicada ---------------------------------------------

const WPORG = 'https://api.wordpress.org';
const LEAN = ['sections', 'description', 'reviews', 'screenshots', 'versions', 'contributors', 'banners', 'icons', 'tags', 'ratings', 'donate_link', 'compatibility']
  .map((f) => `&request[fields][${f}]=0`)
  .join('');

async function latestCore() {
  const data = await fetchJson(`${WPORG}/core/version-check/1.7/`);
  return data?.offers?.[0]?.current || data?.offers?.[0]?.version || null;
}

// { name, version, updated } o { missing: true } si no está en el directorio (premium o propio).
async function wporgInfo(kind, slug) {
  const action = kind === 'theme' ? 'theme_information' : 'plugin_information';
  try {
    const data = await fetchJson(`${WPORG}/${kind}s/info/1.2/?action=${action}&request[slug]=${encodeURIComponent(slug)}${LEAN}`);
    if (!data || data.error) return { missing: true };
    return { name: decodeEntities(data.name || ''), version: data.version || null, updated: data.last_updated || null };
  } catch (err) {
    return err.status === 404 ? { missing: true } : null;
  }
}

function status(version, latest) {
  if (!version || !latest) return 'unknown';
  return compareVersions(version, latest) < 0 ? 'outdated' : 'current';
}

// --- Perfil completo ----------------------------------------------------------------------

export async function profileFromHints(hints) {
  const page = new URL(hints.url);
  const assets = scanAssets(hints);
  const generators = hints.generators.join('\n');
  const metaCore = hints.generators.map((g) => g.match(/^WordPress\s+([^\s]+)/i)?.[1]).find(Boolean) || null;

  // Raíz del sitio: la de la API REST (sin /wp-json/) o la de wp-content.
  let root = page.origin;
  if (hints.restRoot) root = hints.restRoot.replace(/\/(?:wp-json\/?|\?rest_route=.*)$/, '').replace(/\/$/, '');
  else if (/\/wp-content$/.test(assets.contentBase) && new URL(assets.contentBase).host === page.host) {
    root = assets.contentBase.replace(/\/wp-content$/, '');
  }
  const restRoot = hints.restRoot || `${root}/wp-json/`;

  const [feed, opml, readme, rest, wpLatest] = await Promise.all([
    attempt(coreFromFeed(root)),
    attempt(coreFromOpml(root)),
    attempt(coreFromReadme(root)),
    attempt(restIndex(restRoot)),
    attempt(latestCore()),
  ]);

  const isWordPress = !!(metaCore || feed || opml || rest || hints.restRoot || assets.usesWordPressPaths ||
    assets.themes.size || /<meta[^>]+generator[^>]+WordPress/i.test(hints.html));
  if (!isWordPress) return { isWordPress: false, url: hints.url, checkedAt: new Date().toISOString() };

  // Núcleo: fuentes de más a menos fiables.
  const coreSources = [
    feed && { source: 'feed RSS (/feed/)', version: feed },
    opml && { source: 'wp-links-opml.php', version: opml },
    metaCore && { source: 'meta generator', version: metaCore },
    assets.coreVers.length && { source: 'archivos de wp-includes (?ver=)', version: mostCommon(assets.coreVers) },
    readme && { source: 'readme.html', version: readme },
  ].filter((s) => s && isVersion(s.version));
  // Gana la más fiable; si otra fuente da la misma versión con más detalle (6.6 → 6.6.1), se usa esa.
  let coreVersion = coreSources[0]?.version || null;
  for (const s of coreSources) {
    if (coreVersion && s.version.startsWith(`${coreVersion}.`)) coreVersion = s.version;
  }

  // Plugins: rutas de la página + firmas + API REST.
  const plugins = new Map();
  const touch = (slug, init = {}) => {
    if (!plugins.has(slug)) plugins.set(slug, { slug, name: null, mu: false, evidence: new Set(), versions: [], ...init });
    return plugins.get(slug);
  };
  for (const item of assets.plugins.values()) {
    // Algunos alojamientos (p. ej. WordPress VIP) cargan plugins normales como mu-plugins/jetpack-16.2/.
    const pinned = item.mu && item.slug.match(/^(.+?)-(\d+(?:\.\d+)+)$/);
    const plugin = touch(pinned ? pinned[1] : item.slug, { mu: item.mu && !pinned, base: item.base });
    plugin.evidence.add(item.mu ? 'archivos (mu-plugins)' : 'archivos de la página');
    if (pinned) plugin.versions.push({ source: 'nombre de la carpeta', version: pinned[2] });
    // Un ?ver= igual a la versión de WordPress suele ser la del núcleo, no la del plugin.
    const ver = mostCommon(item.vers.filter((v) => v !== coreVersion));
    if (ver) plugin.versions.push({ source: '?ver= de sus archivos', version: ver });
  }

  const signatureText = [...hints.comments, generators].join('\n');
  for (const sig of SIGNATURES) {
    const match = signatureText.match(sig.re);
    if (!match) continue;
    const slug = sig.slugs.find((s) => plugins.has(s)) || sig.slugs[0];
    const plugin = touch(slug);
    plugin.name ||= sig.name;
    plugin.evidence.add(hints.generators.some((g) => sig.re.test(g)) ? 'meta generator' : 'comentario HTML');
    if (isVersion(match[1])) plugin.versions.unshift({ source: 'firma en el HTML', version: match[1] });
  }

  const otherNamespaces = [];
  for (const ns of rest?.namespaces || []) {
    const prefix = ns.split('/')[0];
    if (CORE_NAMESPACE.test(prefix)) continue;
    const slug = NAMESPACES[prefix];
    if (slug) touch(slug).evidence.add('API REST');
    else if (!otherNamespaces.includes(prefix)) otherNamespaces.push(prefix);
  }

  const pluginList = [...plugins.values()].slice(0, MAX_PLUGINS);

  // Temas: el activo es el hijo (su style.css tiene "Template:") o el más referenciado.
  const themeList = [...assets.themes.values()].sort((a, b) => b.refs - a.refs).slice(0, 4);
  const styles = await mapLimit(themeList, CONCURRENCY, (t) => attempt(readStyle(t.base, t.slug)));
  const themes = themeList.map((t, i) => {
    const ver = mostCommon(t.vers.filter((v) => v !== coreVersion));
    return {
      slug: t.slug,
      style: styles[i],
      versions: [
        isVersion(styles[i]?.version) && { source: 'style.css', version: styles[i].version },
        ver && { source: '?ver= de sus archivos', version: ver },
      ].filter(Boolean),
      base: t.base,
    };
  });
  const child = themes.find((t) => t.style?.template);
  if (child && !themes.some((t) => t.slug === child.style.template)) {
    const parentStyle = await attempt(readStyle(child.base, child.style.template));
    themes.push({
      slug: child.style.template,
      style: parentStyle,
      versions: isVersion(parentStyle?.version) ? [{ source: 'style.css', version: parentStyle.version }] : [],
      base: child.base,
    });
  }
  const active = child || themes[0];

  const readmes = await mapLimit(pluginList, CONCURRENCY, (p) => attempt(readReadme(p.base || assets.contentBase, p.slug)));
  pluginList.forEach((p, i) => {
    const r = readmes[i];
    if (!r) return;
    p.name ||= r.name;
    if (r.version) {
      // La firma del HTML es la más fiable; después readme.txt; después ?ver=.
      const at = p.versions[0]?.source === 'firma en el HTML' ? 1 : 0;
      p.versions.splice(at, 0, { source: 'readme.txt', version: r.version });
    }
  });

  const [themeInfo, pluginInfo] = await Promise.all([
    mapLimit(themes, CONCURRENCY, (t) => wporgInfo('theme', t.slug)),
    mapLimit(pluginList, CONCURRENCY, (p) => (p.mu ? { missing: true } : wporgInfo('plugin', p.slug))),
  ]);

  return {
    isWordPress: true,
    url: hints.url,
    root,
    siteName: rest?.name ? decodeEntities(rest.name) : null,
    checkedAt: new Date().toISOString(),
    core: {
      version: coreVersion,
      latest: wpLatest,
      status: status(coreVersion, wpLatest),
      sources: coreSources,
    },
    themes: themes.map((t, i) => {
      const version = t.versions[0]?.version || null;
      const info = themeInfo[i];
      return {
        slug: t.slug,
        name: t.style?.name || info?.name || t.slug,
        role: t === active ? 'active' : t.slug === child?.style.template ? 'parent' : 'other',
        parent: t.style?.template || null,
        author: t.style?.author || null,
        uri: t.style?.uri || null,
        version,
        sources: t.versions,
        latest: info?.version || null,
        inDirectory: info ? !info.missing : null,
        status: status(version, info?.version),
      };
    }),
    plugins: pluginList
      .map((p, i) => {
        const version = p.versions[0]?.version || null;
        const info = pluginInfo[i];
        return {
          slug: p.slug,
          name: p.name || info?.name || p.slug,
          mu: p.mu,
          version,
          sources: p.versions,
          evidence: [...p.evidence],
          latest: info?.version || null,
          inDirectory: info ? !info.missing : null,
          status: status(version, info?.version),
        };
      })
      .sort((a, b) => a.name.localeCompare(b.name, 'es', { sensitivity: 'base' })),
    otherNamespaces,
  };
}

export async function wordpressProfile({ tabId }) {
  let hints;
  try {
    [{ result: hints }] = await chrome.scripting.executeScript({ target: { tabId }, func: collectWordPressHints, args: [MAX_HTML] });
  } catch (err) {
    throw new Error(`El navegador no permite inspeccionar esta página (${err.message}).`);
  }
  return profileFromHints(hints);
}
