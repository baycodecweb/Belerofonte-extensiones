#!/usr/bin/env python3
"""Conector nativo de Belerofonte-Baycodec: descarga videos de YouTube, Vimeo, TikTok e Instagram con yt-dlp.

Chrome lo arranca cuando la extensión llama a chrome.runtime.connectNative() y se comunica por
stdin/stdout con mensajes JSON precedidos de su longitud (4 bytes). Si la extensión cierra la
conexión (botón Cancelar o pestaña cerrada), el conector borra el archivo a medias y termina.

Mensajes que recibe:
  {"action": "info"}                                   → versión de yt-dlp, ffmpeg y carpeta
  {"action": "download", "url", "solo_audio", "calidad", "subtitulos", "referer", "cookies"}
                                                       → progreso… y al final done / error
  {"action": "reveal", "path"}                         → abre la carpeta del archivo
"""

import json
import os
import shutil
import struct
import subprocess
import sys
import tempfile
import threading
import time

IS_WINDOWS = os.name == "nt"
NATIVE_DIR = os.path.dirname(os.path.abspath(__file__))
# Programas que native/instalar.ps1 descarga dentro de la propia carpeta (Windows).
LOCAL_BIN = {
    "ffmpeg": os.path.join(NATIVE_DIR, "ffmpeg", "bin", "ffmpeg.exe"),
    "deno": os.path.join(NATIVE_DIR, "deno", "deno.exe"),
}

# yt-dlp y ffmpeg escriben en stdout: el stdout real se reserva para los mensajes con Chrome.
_protocol_out = sys.stdout.buffer
sys.stdout = sys.stderr
_send_lock = threading.Lock()

CALIDADES_VIDEO = {"mejor", "1080", "720", "480", "360"}
CALIDADES_AUDIO = {"320", "192", "128"}

_current_tmp = {"path": None}


def send(message: dict) -> None:
    data = json.dumps(message, ensure_ascii=False).encode("utf-8")
    with _send_lock:
        _protocol_out.write(struct.pack("=I", len(data)))
        _protocol_out.write(data)
        _protocol_out.flush()


def read_message():
    header = sys.stdin.buffer.read(4)
    if len(header) < 4:
        return None
    (length,) = struct.unpack("=I", header)
    return json.loads(sys.stdin.buffer.read(length).decode("utf-8"))


def _windows_downloads() -> str:
    """Carpeta «Descargas» de Windows (aunque el usuario la haya movido a otro disco)."""
    import ctypes
    from ctypes import wintypes
    from uuid import UUID

    class GUID(ctypes.Structure):
        _fields_ = [("Data1", wintypes.DWORD), ("Data2", wintypes.WORD),
                    ("Data3", wintypes.WORD), ("Data4", ctypes.c_ubyte * 8)]

    raw = UUID("{374DE290-123F-4565-9164-39C4925E467B}").bytes_le  # FOLDERID_Downloads
    guid = GUID.from_buffer_copy(raw)
    path = ctypes.c_wchar_p()
    if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.byref(guid), 0, None, ctypes.byref(path)) != 0:
        return ""
    try:
        return path.value or ""
    finally:
        ctypes.windll.ole32.CoTaskMemFree(path)


def download_dir() -> str:
    """Carpeta de descargas del usuario (p. ej. ~/Descargas en español)."""
    folder = ""
    if IS_WINDOWS:
        try:
            folder = _windows_downloads()
        except (OSError, AttributeError, ValueError):
            folder = ""
        folder = folder or os.path.expanduser("~/Downloads")
        os.makedirs(folder, exist_ok=True)
        return folder
    try:
        folder = subprocess.run(
            ["xdg-user-dir", "DOWNLOAD"], capture_output=True, text=True, timeout=5
        ).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        pass
    if not folder or os.path.realpath(folder) == os.path.realpath(os.path.expanduser("~")):
        folder = os.path.expanduser("~/Downloads")
    os.makedirs(folder, exist_ok=True)
    return folder


def video_format(calidad: str) -> str:
    # Vimeo entrega el audio aparte en .mp4 (no .m4a): sin el «bestvideo+bestaudio» genérico no
    # habría ningún formato válido. ffmpeg lo une todo en un MP4 (merge_output_format).
    if calidad not in CALIDADES_VIDEO or calidad == "mejor":
        return "bestvideo[ext=mp4]+bestaudio[ext=m4a]/bestvideo+bestaudio/best[ext=mp4]/best"
    return (
        f"bestvideo[height<={calidad}][ext=mp4]+bestaudio[ext=m4a]/"
        f"bestvideo[height<={calidad}]+bestaudio/"
        f"best[height<={calidad}][ext=mp4]/best[height<={calidad}]"
    )


# YouTube exige resolver un reto en JavaScript para entregar el video; sin un entorno de JS,
# yt-dlp recibe "HTTP Error 403: Forbidden". Chrome arranca el conector con un PATH mínimo, así
# que se buscan también las rutas de instalación habituales.
JS_RUNTIME_PATHS = {
    "deno": [LOCAL_BIN["deno"], "~/.deno/bin/deno.exe", "~/.deno/bin/deno", "/usr/local/bin/deno", "/usr/bin/deno"],
    "node": [os.path.expandvars(r"%ProgramFiles%\nodejs\node.exe"), "/usr/local/bin/node", "/usr/bin/node", "/usr/bin/nodejs"],
    "bun": ["~/.bun/bin/bun.exe", "~/.bun/bin/bun", "/usr/local/bin/bun"],
}


def js_runtimes() -> dict:
    found = {}
    for name, candidates in JS_RUNTIME_PATHS.items():
        for path in [shutil.which(name)] + [os.path.expanduser(c) for c in candidates]:
            if path and os.path.isfile(path) and os.access(path, os.X_OK):
                found[name] = {"path": path}
                break
    return found


def ffmpeg_path() -> str | None:
    """ffmpeg une video y audio y convierte a MP3. En Windows, instalar.ps1 lo deja en native/ffmpeg."""
    if os.path.isfile(LOCAL_BIN["ffmpeg"]):
        return LOCAL_BIN["ffmpeg"]
    return shutil.which("ffmpeg") or next(
        (p for p in ("/usr/bin/ffmpeg", "/usr/local/bin/ffmpeg") if os.path.isfile(p)), None)


class Logger:
    """Los avisos de yt-dlp van a stderr (Chrome los muestra en su registro), nunca a stdout."""

    def debug(self, msg):
        pass

    def info(self, msg):
        pass

    def warning(self, msg):
        print(msg, file=sys.stderr)

    def error(self, msg):
        print(msg, file=sys.stderr)


def info() -> dict:
    try:
        import yt_dlp

        version = yt_dlp.version.__version__
    except ImportError:
        version = None
    try:
        import yt_dlp_ejs  # noqa: F401  (scripts que resuelven el reto de YouTube)

        ejs = True
    except ImportError:
        ejs = False
    return {
        "type": "info",
        "ytdlp": version,
        "js": {name: conf["path"] for name, conf in js_runtimes().items()},
        "ejs": ejs,
        "ffmpeg": bool(ffmpeg_path()),
        "carpeta": download_dir(),
        "python": sys.executable,
    }


def cookie_file(cookies) -> str | None:
    """Escribe las cookies que envía la extensión (Instagram) en un archivo Netscape temporal, legible
    solo por el usuario. Se borra al terminar la descarga."""
    if not isinstance(cookies, list) or not cookies:
        return None
    lines = ["# Netscape HTTP Cookie File"]
    for c in cookies:
        name, value, domain = str(c.get("name", "")), str(c.get("value", "")), str(c.get("domain", ""))
        if not name or not domain or any(ch in name + value + domain for ch in "\t\r\n"):
            continue
        if not c.get("hostOnly") and not domain.startswith("."):
            domain = "." + domain
        # Las cookies de sesión no tienen caducidad: se les da un día para que yt-dlp no las descarte.
        expires = int(c.get("expirationDate") or time.time() + 86400)
        lines.append("\t".join([
            domain, "TRUE" if domain.startswith(".") else "FALSE", str(c.get("path") or "/"),
            "TRUE" if c.get("secure") else "FALSE", str(expires), name, value,
        ]))
    fd, path = tempfile.mkstemp(prefix="belerofonte-cookies-", suffix=".txt")
    with os.fdopen(fd, "w") as handle:
        handle.write("\n".join(lines) + "\n")
    _current_tmp["cookies"] = path
    return path


# "1.4K views · 341 reactions | ", "119 reactions · 1.4K shares ｜ " (yt-dlp cambia | por ｜).
FACEBOOK_STATS = r"^(?:[\d.,]+[KMB]? (?:views|reactions|shares|comments|reproducciones|reacciones|veces compartido|comentarios)(?: · )?)+ *[|｜] *"


def download(message: dict) -> dict:
    import yt_dlp
    from yt_dlp.postprocessor.metadataparser import MetadataParserPP

    url = (message.get("url") or "").strip()
    solo_audio = bool(message.get("solo_audio"))
    calidad = str(message.get("calidad") or ("192" if solo_audio else "mejor"))
    subtitulos = bool(message.get("subtitulos"))
    if not url.startswith(("http://", "https://")):
        return {"type": "error", "mensaje": "El enlace no es válido."}

    last_sent = [0.0]
    title_sent = [False]

    def progress(state: dict) -> None:
        if state.get("tmpfilename"):
            _current_tmp["path"] = state["tmpfilename"]
        title = (state.get("info_dict") or {}).get("title")
        if title and not title_sent[0]:
            # El título llega en cuanto yt-dlp lee el video: la pestaña de descarga lo muestra.
            title_sent[0] = True
            send({"type": "progress", "porcentaje": 0, "titulo": title, "mensaje": "Descargando…"})
        if state["status"] == "downloading":
            now = time.monotonic()
            if now - last_sent[0] < 0.4:
                return
            last_sent[0] = now
            total = state.get("total_bytes") or state.get("total_bytes_estimate")
            done = state.get("downloaded_bytes") or 0
            send({
                "type": "progress",
                "porcentaje": round(done / total * 100, 1) if total else 0,
                "velocidad": speed if "Unknown" not in (speed := (state.get("_speed_str") or "").strip()) else "",
                "descargado": done,
                "total": total,
                # Con video y audio por separado, yt-dlp baja dos archivos seguidos.
                "parte": (state.get("info_dict") or {}).get("format_id", ""),
            })
        elif state["status"] == "finished":
            send({"type": "progress", "porcentaje": 100, "mensaje": "Procesando archivo…"})

    options = {
        "outtmpl": os.path.join(download_dir(), "%(title).150B [%(id)s].%(ext)s"),
        "windowsfilenames": True,
        "noplaylist": True,
        "progress_hooks": [progress],
        "logger": Logger(),
        "js_runtimes": js_runtimes() or {"deno": {}},
        "quiet": True,
        "noprogress": True,
    }
    ffmpeg = ffmpeg_path()
    if ffmpeg:
        options["ffmpeg_location"] = ffmpeg
    cookie_path = cookie_file(message.get("cookies"))
    if cookie_path:
        options["cookiefile"] = cookie_path
    # Videos de Vimeo insertados que solo se pueden ver desde la web que los inserta.
    referer = (message.get("referer") or "").strip()
    if referer.startswith(("http://", "https://")):
        options["http_headers"] = {"Referer": referer}
    if solo_audio:
        options.update({
            # Nombre propio: si no, yt-dlp toma el video ya descargado con el mismo nombre como
            # "ya descargado", lo convierte a MP3 y lo borra.
            "outtmpl": os.path.join(download_dir(), "%(title).150B [%(id)s] - audio.%(ext)s"),
            "format": "bestaudio/best",
            "postprocessors": [{
                "key": "FFmpegExtractAudio",
                "preferredcodec": "mp3",
                "preferredquality": calidad if calidad in CALIDADES_AUDIO else "192",
            }],
        })
    else:
        options["format"] = video_format(calidad)
        options["merge_output_format"] = "mp4"
        if subtitulos:
            options.update({
                "writesubtitles": True,
                "writeautomaticsub": True,
                "subtitleslangs": ["es", "es-*", "en"],
                "postprocessors": [{"key": "FFmpegEmbedSubtitle"}],
            })

    # Facebook pone las estadísticas delante del título ("9.8K views · 341 reactions | Texto…"): se
    # quitan antes de nombrar el archivo. (El .150B de outtmpl limita el nombre a 150 bytes.)
    options.setdefault("postprocessors", []).insert(0, {
        "key": "MetadataParser",
        "when": "pre_process",
        "actions": [(MetadataParserPP.Actions.REPLACE, "title", FACEBOOK_STATS, "")],
    })

    send({"type": "progress", "porcentaje": 0, "mensaje": "Leyendo el video…"})
    try:
        with yt_dlp.YoutubeDL(options) as ydl:
            result = ydl.extract_info(url, download=True)
            downloads = result.get("requested_downloads") or []
            path = downloads[-1].get("filepath") if downloads else None
            if not path:
                path = ydl.prepare_filename(result)
            if solo_audio:
                path = os.path.splitext(path)[0] + ".mp3"
    except yt_dlp.utils.DownloadError as error:
        return {"type": "error", "mensaje": str(error).removeprefix("ERROR: ")}
    finally:
        if cookie_path:
            try:
                os.remove(cookie_path)
            except OSError:
                pass
    _current_tmp["path"] = None
    return {
        "type": "done",
        "archivo": os.path.basename(path),
        "ruta": path,
        "tamano": os.path.getsize(path) if os.path.exists(path) else None,
        "titulo": result.get("title"),
    }


def show_in_file_manager(path: str) -> bool:
    """Abre la carpeta con el archivo ya seleccionado. En Linux se usa la interfaz estándar
    org.freedesktop.FileManager1 (Thunar, Nautilus, Dolphin, Nemo, Caja…)."""
    from urllib.parse import quote

    uri = "file://" + quote(os.path.abspath(path), safe="/")  # sin comillas ni comas: no rompen los argumentos
    commands = [
        ["gdbus", "call", "--session", "--dest", "org.freedesktop.FileManager1",
         "--object-path", "/org/freedesktop/FileManager1",
         "--method", "org.freedesktop.FileManager1.ShowItems", f"['{uri}']", ""],
        ["dbus-send", "--session", "--print-reply", "--dest=org.freedesktop.FileManager1", "--type=method_call",
         "/org/freedesktop/FileManager1", "org.freedesktop.FileManager1.ShowItems", f"array:string:{uri}", "string:"],
    ]
    for command in commands:
        if not shutil.which(command[0]):
            continue
        try:
            result = subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=8)
            if result.returncode == 0:
                return True
        except (OSError, subprocess.SubprocessError):
            continue
    return False


def reveal(message: dict) -> dict:
    path = message.get("path") or ""
    is_file = bool(path) and os.path.isfile(path)
    folder = os.path.dirname(path) if is_file else download_dir()
    if IS_WINDOWS:
        if is_file:
            subprocess.Popen(f'explorer /select,"{os.path.normpath(path)}"')
        else:
            os.startfile(folder)
    elif sys.platform == "darwin":
        subprocess.Popen(["open", "-R", path] if is_file else ["open", folder])
    elif not (is_file and show_in_file_manager(path)):
        # Sin gestor de archivos compatible: al menos se abre la carpeta.
        subprocess.Popen(["xdg-open", folder], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return {"type": "ok", "seleccionado": is_file}


def handle(message: dict) -> None:
    action = message.get("action")
    try:
        if action == "info":
            send(info())
        elif action == "download":
            send(download(message))
        elif action == "reveal":
            send(reveal(message))
        else:
            send({"type": "error", "mensaje": f"Acción desconocida: {action}"})
    except ImportError:
        send({"type": "error", "mensaje": "yt-dlp no está instalado para el Python del conector. Vuelve a ejecutar native/instalar.sh (Windows: native\\instalar.bat)."})
    except Exception as error:  # cualquier fallo se informa a la extensión en lugar de cortar la conexión
        send({"type": "error", "mensaje": f"{type(error).__name__}: {error}"})


def main() -> None:
    # Cada mensaje se atiende en un hilo; el principal solo lee. Cuando Chrome cierra la conexión
    # (stdin termina): una descarga en curso se cancela (se borra el archivo a medias); las demás
    # peticiones (info, reveal) terminan y responden antes de salir.
    workers = []
    while True:
        message = read_message()
        if message is None:
            break
        worker = threading.Thread(target=handle, args=(message,), daemon=True)
        worker.start()
        workers.append((worker, message.get("action")))

    downloading = any(w.is_alive() and action == "download" for w, action in workers)
    if not downloading:
        for worker, _ in workers:
            worker.join(timeout=15)
    # Archivo a medias y cookies de una descarga cancelada.
    for tmp in (_current_tmp["path"], _current_tmp.get("cookies")):
        if tmp and os.path.exists(tmp):
            try:
                os.remove(tmp)
            except OSError:
                # Windows no deja borrar un archivo abierto (la descarga sigue en otro hilo): se borra
                # unos segundos después, cuando este proceso ya ha terminado.
                if IS_WINDOWS:
                    delete_later(tmp)
    os._exit(0)


def delete_later(path: str) -> None:
    flags = 0x08000000 | 0x00000008  # CREATE_NO_WINDOW | DETACHED_PROCESS
    command = f'cmd /d /c ping -n 4 127.0.0.1 >nul & del /f /q "{path}"'
    for extra in (0x01000000, 0):  # CREATE_BREAKAWAY_FROM_JOB, si el navegador lo permite
        try:
            subprocess.Popen(command, creationflags=flags | extra, close_fds=True,
                             stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return
        except OSError:
            continue


if __name__ == "__main__":
    main()
