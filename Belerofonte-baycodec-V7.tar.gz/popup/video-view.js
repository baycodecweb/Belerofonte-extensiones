// Sección "Videos de la página" del popup: lista lo detectado y lanza la descarga.

import { oembedInfo } from '../video/oembed.js';

const list = () => document.getElementById('videos-list');

const mb = (bytes) => (bytes >= 1073741824 ? `${(bytes / 1073741824).toFixed(1)} GB` : `${(bytes / 1048576).toFixed(1)} MB`);
const clock = (seconds) => {
  const s = Math.round(seconds);
  const m = Math.floor(s / 60);
  return m >= 60 ? `${Math.floor(m / 60)}:${String(m % 60).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}` : `${m}:${String(s % 60).padStart(2, '0')}`;
};

function el(tag, props = {}, children = []) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children.filter(Boolean));
  return node;
}

function describe(item) {
  if (item.kind === 'ytdlp') return { badge: item.site.slice(0, 5), info: 'Reproductor insertado · se descarga con yt-dlp', action: 'Descargar' };
  if (item.site === 'OK.ru' && item.kind === 'file') return { badge: 'OK.ru', info: `${item.quality} · MP4`, action: 'Descargar' };
  if (item.kind === 'file') {
    const ext = (item.name.match(/\.(\w+)$/)?.[1] || item.type?.split('/')[1] || 'video').toUpperCase();
    return { badge: ext.slice(0, 4), info: [item.type, item.size && mb(item.size)].filter(Boolean).join(' · ') || 'Archivo directo', action: 'Descargar' };
  }
  const info = item.info || {};
  const badge = item.kind === 'dash' ? 'DASH' : 'HLS';
  if (info.error) return { badge, info: `No se pudo leer desde aquí (${info.error}): se intentará con el Referer del reproductor`, action: 'Abrir' };
  if (info.encryption?.length) return { badge, info: `Protegido (${info.encryption.join(', ')})`, action: null };
  const parts = [];
  if (info.live) parts.push('🔴 En directo');
  else if (info.duration) parts.push(clock(info.duration));
  if (info.maxHeight) parts.push(`hasta ${info.maxHeight}p`);
  if (info.qualities > 1) parts.push(`${info.qualities} calidades`);
  if (info.subtitles?.length) parts.push(`💬 ${[...new Set(info.subtitles)].join(', ')}`);
  return { badge, info: parts.join(' · ') || `Stream ${badge}`, action: info.live ? 'Grabar' : 'Descargar' };
}

function render(tabId, response) {
  if (!response?.ok) {
    list().replaceChildren(el('p', { className: 'videos__empty muted', textContent: response?.error || 'No se pudieron buscar videos.' }));
    return;
  }
  if (response.ytdlp && !response.items.length) {
    list().replaceChildren(el('p', {
      className: 'videos__empty muted',
      textContent: `Video de ${response.ytdlp.site}: elige las opciones y pulsa Descargar. Se descarga con yt-dlp (conector nativo).` +
        (response.ytdlp.site === 'Vimeo'
          ? ' Si Vimeo bloquea a yt-dlp, reproduce el video unos segundos y vuelve a abrir este panel: aparecerá aquí para bajarlo desde el navegador (si no tiene DRM).'
          : ''),
    }));
    return;
  }
  if (!response.items.length) {
    list().replaceChildren(el('p', {
      className: 'videos__empty muted',
      textContent: 'No se detectaron videos. Reproduce el video unos segundos y vuelve a abrir este panel.',
    }));
    return;
  }

  // Primero los streams y los archivos más recientes.
  const stream = (k) => (k === 'hls' || k === 'dash' ? 0 : 1);
  const items = [...response.items].sort((a, b) => stream(a.kind) - stream(b.kind) || b.detectedAt - a.detectedAt);
  list().replaceChildren(...items.map((item) => {
    const { badge, info, action } = describe(item);
    const button = el('button', { className: 'media__btn', textContent: action || 'Protegido', disabled: !action, title: item.url });
    button.addEventListener('click', async () => {
      button.disabled = true;
      const res = await chrome.runtime.sendMessage({ type: 'media-download', tabId, url: item.url, kind: item.kind, filename: item.filename, referer: item.referer });
      button.textContent = res?.ok ? '✓' : '✗';
      if (res?.ok && res.opened === 'manager') button.title = 'Añadido al gestor de descargas';
      if (!res?.ok) button.title = res?.error || 'Error';
      setTimeout(() => {
        button.textContent = action;
        button.disabled = false;
      }, 1500);
    });
    return el('div', { className: 'media' }, [
      el('span', { className: 'media__badge', textContent: badge }),
      el('div', { className: 'media__body' }, [
        el('div', { className: 'media__name', textContent: item.name, title: item.url }),
        el('div', { className: 'media__info', textContent: info }),
      ]),
      button,
    ]);
  }));
}

// Enlaces que se descargan con yt-dlp: YouTube, Vimeo, TikTok, Instagram y Facebook.
const YTDLP_SITES = [
  ['YouTube', /^https?:\/\/([\w-]+\.)?(youtube\.com|youtu\.be)\//i],
  ['Vimeo', /^https?:\/\/([\w-]+\.)?vimeo\.com\/(?:.*\/)?\d{5,}/i],
  ['TikTok', /^https?:\/\/(?:(?:vm|vt)\.tiktok\.com\/\w+|([\w-]+\.)?tiktok\.com\/(?:@[^/]*\/video\/\d+|t\/\w+|(?:embed(?:\/v\d)?|player\/v\d|v)\/\d{10,}))/i],
  ['Instagram', /^https?:\/\/([\w-]+\.)?instagram\.com\/(?:(?:[\w.]+\/)?(?:p|reels?|tv)\/[\w-]{5,}|stories\/[\w.]+\/\d+)/i],
  ['Facebook', /^https?:\/\/(?:fb\.watch\/\w|([\w-]+\.)?facebook\.com\/(?:reel\/\d|watch\/?(?:live\/?)?\?(?:.*&)?v=\d|video\.php\?(?:.*&)?v=\d|story\.php\?|permalink\.php\?|plugins\/video\.php\?|groups\/[^/]+\/(?:posts|permalink)\/|share\/[vrp]\/\w|[\w.-]+\/(?:videos|posts)\/))/i],
];
const ytdlpSite = (url) => YTDLP_SITES.find(([, re]) => re.test(url))?.[0] || null;
// OK.ru no pasa por yt-dlp: se baja el MP4 directo, así que solo se elige la calidad.
const OKRU = /^https?:\/\/([\w-]+\.)?ok\.ru\/(?:video|videoembed|live)\/\d+/i;

// Opciones de descarga (las mismas que la app Flask de yt-dlp). Se muestran con enlaces de
// YouTube o Vimeo; con los de OK.ru, solo la calidad.
function setupYouTubeOptions(input) {
  const panel = document.getElementById('yt-options');
  const title = document.getElementById('yt-title');
  const audio = document.getElementById('yt-audio');
  const subs = document.getElementById('yt-subs');
  const calidad = document.getElementById('yt-calidad');
  const bitrate = document.getElementById('yt-bitrate');

  const sync = () => {
    const url = input.value.trim();
    const site = ytdlpSite(url);
    const okru = OKRU.test(url);
    panel.hidden = !site && !okru;
    if (site) {
      title.textContent = `${site} · se descarga con yt-dlp`;
      // Título del video (oEmbed), para saber qué se va a bajar.
      oembedInfo(url, site).then((info) => {
        if (info && input.value.trim() === url) title.textContent = `${site} · ${info.title}${info.author ? ` — ${info.author}` : ''}`;
      });
    }
    if (okru) title.textContent = 'OK.ru · descarga directa en MP4';
    audio.closest('label').hidden = okru;
    subs.closest('label').hidden = okru;
    if (okru) audio.checked = false;
    calidad.hidden = audio.checked;
    bitrate.hidden = !audio.checked;
    subs.disabled = audio.checked; // los subtítulos solo se incrustan en video
  };
  input.addEventListener('input', sync);
  audio.addEventListener('change', sync);
  sync();

  return {
    sync,
    values: () => ({
      soloAudio: audio.checked,
      calidad: audio.checked ? bitrate.value : calidad.value,
      subtitulos: !audio.checked && subs.checked,
    }),
  };
}

// Enlace pegado a mano: archivo directo (mp4, webm…), lista HLS (.m3u8) o video de YouTube o Vimeo.
function setupPaste(getTabId) {
  const form = document.getElementById('video-url-form');
  const input = document.getElementById('video-url');
  const youtube = setupYouTubeOptions(input);
  const button = form.querySelector('button');
  const status = document.getElementById('video-url-status');
  const setStatus = (text, isError = false) => {
    status.hidden = !text;
    status.textContent = text;
    status.classList.toggle('warn', isError);
  };

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    button.disabled = true;
    setStatus('Iniciando la descarga…');
    const res = await chrome.runtime.sendMessage({
      type: 'media-download', tabId: getTabId(), url: input.value, kind: 'auto', ytdlp: youtube.values(),
    });
    button.disabled = false;
    if (!res?.ok) return setStatus(res?.error || 'No se pudo descargar.', true);
    setStatus({
      hls: 'Se abrió la página de descarga del stream.',
      file: 'El servidor exige venir de su página: se abrió una pestaña que lo descarga con ese permiso.',
      ytdlp: 'Se abrió la pestaña de descarga (yt-dlp).',
      manager: 'Añadido al gestor de descargas (varias conexiones, se puede pausar).',
    }[res.opened] || 'Descarga iniciada.');
    input.value = '';
    youtube.sync();
  });

  // En la página de un video de YouTube o Vimeo se rellena el enlace del video de la pestaña.
  return (url) => {
    input.value = url;
    youtube.sync();
  };
}

export function setupVideos() {
  let tabId = null;
  const prefill = setupPaste(() => tabId);
  return async (id) => {
    tabId = id;
    const response = await chrome.runtime.sendMessage({ type: 'media-list', tabId: id });
    if (response?.ytdlp) prefill(response.ytdlp.url);
    render(id, response);
  };
}

