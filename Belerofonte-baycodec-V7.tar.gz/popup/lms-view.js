// Sección "Analizar LMS" del popup: plataforma educativa, versión, soporte y plugins.

const dateShort = new Intl.DateTimeFormat('es', { dateStyle: 'medium' });
const monthYear = new Intl.DateTimeFormat('es', { month: 'long', year: 'numeric', timeZone: 'UTC' });

function el(tag, props = {}, children = []) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children.filter((c) => c != null && c !== false));
  return node;
}

const muted = (text) => el('span', { className: 'muted', textContent: text });
const chip = (text, variant = '', title = '') => el('span', { className: `chip${variant ? ` chip--${variant}` : ''}`, textContent: text, title });
const fmtMonth = (iso) => (iso ? monthYear.format(new Date(iso)) : '');

const KIND_LABEL = {
  open: 'Código abierto',
  cloud: 'En la nube',
  commercial: 'Comercial / académica',
  corporate: 'Corporativa',
  custom: 'Desarrollo propio / a medida',
  sso: 'Inicio de sesión único de la institución',
};

// Moodle: rama, fechas de soporte y si hay versiones más nuevas.
function supportLines(s) {
  if (!s || s.status === 'unknown') return { detail: s?.latest ? `La última versión de Moodle es ${s.latest}.` : null, warn: false };
  const lts = s.isLTS ? ' (LTS, soporte extendido)' : '';
  const lines = {
    supported: `✓ Con soporte${lts}: correcciones hasta ${fmtMonth(s.generalEnd)} y seguridad hasta ${fmtMonth(s.securityEnd)}.`,
    security: `⚠ Solo recibe parches de seguridad${lts}, hasta ${fmtMonth(s.securityEnd)}.`,
    unsupported: `⛔ Sin soporte desde ${fmtMonth(s.securityEnd)}: ya no recibe parches de seguridad.`,
  };
  const extra = [];
  if (s.patchOutdated) extra.push(`Falta actualizar a ${s.latestInBranch}, el último parche de su rama.`);
  else if (s.patchMaybeOutdated) extra.push(`El último parche de la rama ${s.branch} es ${s.latestInBranch}: comprueba si ya está instalado.`);
  else if (s.latestInBranch) extra.push(`Último parche de la rama ${s.branch}: ${s.latestInBranch}.`);
  if (s.newerBranch) extra.push(`La última versión es ${s.latest}${s.latestLts && s.latestLts !== s.latest ? ` y la última LTS ${s.latestLts}` : ''}.`);
  return { detail: lines[s.status], extra, warn: s.status !== 'supported' || s.patchOutdated };
}

// Chamilo, ILIAS, Sakai: comparación con las versiones publicadas en GitHub.
function releaseLines(r, version) {
  if (!r) return { detail: null, warn: false };
  if (!version) return { detail: `La última versión publicada es ${r.latest}.`, warn: false };
  const extra = [];
  if (r.newerLine) extra.push(`Hay una línea más nueva: ${r.latest}.`);
  if (r.status === 'current') return { detail: `✓ Es la última de su línea (${r.latestInLine}).`, extra, warn: false };
  if (r.status === 'outdated') return { detail: `⚠ Desactualizado: la última de su línea es ${r.latestInLine}.`, extra, warn: true };
  return { detail: `La última versión publicada es ${r.latest}.`, extra, warn: false };
}

function versionView(profile) {
  const { name, version } = profile;
  const title = version.value
    ? `${name} ${version.value.replace(/^Totara /, '')}${version.atLeast ? ' o posterior' : ''}`
    : profile.kind === 'custom' ? `${name}${profile.title ? ` · «${profile.title.trim()}»` : ''}` : `${name} (versión no visible)`;
  const { detail, extra = [], warn } = profile.support !== undefined ? supportLines(profile.support) : releaseLines(profile.releases, version.value);

  const distinct = [...new Set(version.sources.map((s) => s.version))];
  const note = !version.sources.length
    ? profile.hiddenVersionNote || profile.note || 'No se encontró la versión en archivos públicos.'
    : distinct.length > 1
      ? version.sources.map((s) => `${s.source}: ${s.version}`).join(' · ')
      : `Detectado por: ${version.sources.map((s) => s.source).join(', ')}.`;

  return el('div', { className: `estimate${warn ? ' estimate--warn' : ''}` }, [
    el('div', { className: 'estimate__label', textContent: `Plataforma · ${KIND_LABEL[profile.kind] || 'LMS'}` }),
    el('div', { className: 'estimate__title', textContent: title }),
    detail && el('div', { className: 'estimate__detail', textContent: detail }),
    ...extra.map((text) => el('div', { className: 'estimate__note', textContent: text })),
    el('div', { className: 'estimate__note', textContent: note }),
    version.sources.length > 0 && profile.note && el('div', { className: 'estimate__note', textContent: profile.note }),
  ]);
}

function factsView(facts) {
  if (!facts?.length) return null;
  return el('dl', { className: 'domain__list' }, facts.flatMap(([label, value]) => [
    el('dt', { textContent: label }),
    el('dd', { textContent: String(value) }),
  ]));
}

// SSO: la aplicación a la que lleva el inicio de sesión.
function destinationView(d) {
  if (!d) return null;
  const rows = [
    ['Aplicación', d.title],
    ['Dirección', d.url],
    ['Descripción', d.description],
    ['Construida con', d.frameworks.join(', ')],
    ['Alojamiento', d.hosting.join(', ')],
    ['Cabeceras de seguridad', d.security],
    ['Aula virtual enlazada', d.virtualClass.join(', ')],
    ['Plataformas que menciona su código', d.mentions.map(([name, n]) => `${name} (${n})`).join(', ')],
    ['Otros sistemas de la institución', d.systems.filter((s) => !d.virtualClass.includes(s)).join(', ')],
    ...d.services.map(([group, names]) => [`Servicios · ${group}`, names.join(', ')]),
  ].filter(([, v]) => v);
  return el('section', { className: 'category wp__group' }, [
    el('h2', { textContent: 'Aplicación de destino' }),
    factsView(rows),
  ]);
}

function pluginView(plugin) {
  const link = plugin.core === false
    ? el('a', { href: `https://moodle.org/plugins/${plugin.component}`, target: '_blank', rel: 'noopener', textContent: plugin.component })
    : el('strong', { textContent: plugin.component });
  return el('li', { className: 'tech' }, [
    el('div', { className: 'tech__body' }, [
      el('div', { className: 'tech__name' }, [
        link,
        plugin.core === true ? chip('núcleo', 'muted', 'Viene con Moodle') : plugin.core === false ? chip('adicional', 'source', 'No forma parte de Moodle: plugin de terceros o propio') : null,
      ]),
      el('div', { className: 'tech__evidence', textContent: `Detectado por: ${plugin.evidence.join(', ')}` }),
    ]),
  ]);
}

function pluginsView(plugins) {
  if (!plugins) return null;
  const extra = plugins.filter((p) => p.core !== true);
  const core = plugins.filter((p) => p.core === true);
  return el('section', { className: 'category wp__group' }, [
    el('h2', { textContent: `Plugins adicionales (${extra.length})` }),
    extra.length
      ? el('ul', {}, extra.map(pluginView))
      : el('p', { className: 'wp__empty muted', textContent: 'No se detectó ningún plugin fuera del núcleo en esta página.' }),
    core.length > 0 && el('p', {
      className: 'wp__empty muted',
      textContent: `Del núcleo de Moodle (${core.length}): ${core.map((p) => p.component).join(', ')}`,
    }),
  ]);
}

function render(profile) {
  if (!profile.isLms) {
    return el('p', { className: 'state', textContent: 'Esta página no parece una plataforma educativa (no se reconoció Moodle, Chamilo, Canvas, Blackboard ni ningún otro LMS conocido).' });
  }
  const checked = new Date(profile.checkedAt);
  const others = profile.detected.filter((n) => n !== profile.name);

  return el('div', { className: 'domain__card' }, [
    el('div', { className: 'domain__title' }, [
      el('strong', { textContent: profile.siteName || new URL(profile.root).host }),
      muted(` · ${profile.name}`),
    ]),
    profile.description && el('p', { className: 'wp__empty muted', textContent: profile.description }),
    versionView(profile),
    factsView([
      ...(profile.facts || []),
      ...(profile.stack?.length ? [['Construido con', profile.stack.join(', ')]] : []),
      ...(profile.related?.length ? [['Sistemas relacionados', profile.related.join(', ')]] : []),
    ]),
    profile.services?.length > 0 && el('section', { className: 'category wp__group' }, [
      el('h2', { textContent: 'Servicios integrados (según su política de seguridad)' }),
      factsView(profile.services.map(([group, names]) => [group, names.join(', ')])),
    ]),
    others.length > 0 && el('p', { className: 'wp__empty muted', textContent: `También detectado: ${others.join(', ')}` }),
    destinationView(profile.destination),
    pluginsView(profile.plugins),
    el('p', {
      className: 'domain__sources muted',
      textContent: (profile.plugins ? 'Solo aparecen los plugins que dejan rastro en esta página: puede haber más. ' : '') +
        'Fuentes: HTML y archivos públicos del sitio' +
        (profile.support !== undefined ? ', calendario oficial de Moodle (moodledev.io)' : profile.releases ? ', versiones publicadas en GitHub' : '') + ' · ' +
        (profile.cached ? `en caché desde las ${checked.toLocaleTimeString('es', { hour: '2-digit', minute: '2-digit' })}` : `consultado el ${dateShort.format(checked)}`),
    }),
  ]);
}

export function setupLms(getTabId) {
  const button = document.getElementById('lms-btn');
  const result = document.getElementById('lms-result');
  const note = document.getElementById('lms-note');
  const toggle = document.getElementById('lms-toggle');
  let profile = null;

  const setExpanded = (expanded) => {
    result.hidden = !expanded;
    toggle.setAttribute('aria-expanded', String(expanded));
    toggle.textContent = expanded ? '▴ Ocultar' : '▾ Mostrar';
  };
  toggle.addEventListener('click', () => setExpanded(result.hidden));

  button.addEventListener('click', async () => {
    const refresh = !!profile;
    button.disabled = true;
    button.textContent = 'Analizando la plataforma educativa…';
    result.replaceChildren();
    setExpanded(true);
    toggle.hidden = true;

    const response = await chrome.runtime.sendMessage({ type: 'lms', tabId: getTabId(), refresh }).catch((err) => ({ ok: false, error: err.message }));
    button.disabled = false;
    if (!response?.ok) {
      button.textContent = '🎓 Reintentar';
      // Sin respuesta: el service worker es de una versión anterior (la extensión no se ha recargado).
      const error = response?.error ||
        'La extensión se actualizó pero sigue funcionando la versión anterior: pulsa ↻ Recargar en chrome://extensions y vuelve a abrir la página.';
      result.replaceChildren(el('p', { className: 'state state--error', textContent: error }));
      return;
    }

    const { ok, ...data } = response;
    profile = data;
    note.hidden = true;
    button.textContent = '↻ Volver a analizar LMS';
    toggle.hidden = false;
    result.replaceChildren(render(profile));
  });

  return () => profile;
}
