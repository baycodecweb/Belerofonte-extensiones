// Botón «⬇ Descargar» que aparece al pasar el ratón sobre un video (como el de IDM). Al pulsarlo
// muestra las formas de bajar ese video (yt-dlp, el archivo, streams HLS detectados…) y la elegida
// se descarga con la extensión. La interfaz va en un Shadow DOM cerrado: el CSS de la página no le
// afecta. Solo hace algo cuando el ratón se mueve y hay algún <video> grande en la página.
(() => {
  if (window.__belerofonteFloat) return;
  window.__belerofonteFloat = true;

  const MIN_WIDTH = 200;
  const MIN_HEIGHT = 112;
  const HIDE_MS = 2200;
  const videos = document.getElementsByTagName('video'); // colección viva: no hace falta vigilar el DOM

  let enabled = true;
  chrome.storage.local.get('dmFloat').then((v) => (enabled = v.dmFloat !== false)).catch(() => {});
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.dmFloat) {
      enabled = changes.dmFloat.newValue !== false;
      if (!enabled) hide(true);
    }
  });

  // Listas HLS que encuentra sniff.js (mundo de la página) al darle play: se pasan a la extensión
  // para que aparezcan en el botón y en «Videos de la página» aunque el <video> sea blob:.
  document.addEventListener('belerofonte-media-found', (event) => {
    try {
      const detail = JSON.parse(event.detail);
      chrome.runtime.sendMessage({ type: 'media-found', url: detail.url, text: detail.text, page: detail.page, kind: detail.kind }).catch(() => {});
    } catch { /* aviso mal formado */ }
  });

  let host = null;
  let button = null;
  let menu = null;
  let current = null;
  let hideTimer = null;
  let menuOpen = false;

  function ui() {
    if (host) return;
    host = document.createElement('belerofonte-float');
    host.style.cssText = 'all: initial; position: fixed; z-index: 2147483647; top: 0; left: 0; display: none;';
    const shadow = host.attachShadow({ mode: 'closed' });
    shadow.innerHTML = `
      <style>
        :host { all: initial; }
        * { box-sizing: border-box; font: 13px/1.35 system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; }
        .btn {
          display: flex; align-items: center; gap: 6px; padding: 6px 11px; border: 0; border-radius: 8px;
          background: rgba(79, 70, 229, .95); color: #fff; font-weight: 600; cursor: pointer;
          box-shadow: 0 2px 10px rgba(0, 0, 0, .35); white-space: nowrap;
        }
        .btn:hover { background: #4338ca; }
        .menu {
          position: absolute; top: calc(100% + 6px); right: 0; width: 320px; max-height: 360px; overflow: auto;
          padding: 6px; border-radius: 10px; background: #1c1c22; color: #ececf1;
          box-shadow: 0 8px 28px rgba(0, 0, 0, .45); display: none;
        }
        .menu.open { display: block; }
        .opt { display: block; width: 100%; padding: 8px 10px; border: 0; border-radius: 7px; background: none; color: inherit; text-align: left; cursor: pointer; }
        .opt:hover { background: #2e2e37; }
        .opt b { display: block; font-weight: 600; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .opt small { display: block; color: #9a9aa8; font-size: 11.5px; }
        .msg { padding: 8px 10px; color: #c9c9d3; }
        .foot { display: flex; justify-content: space-between; gap: 8px; padding: 6px 10px 2px; border-top: 1px solid #2e2e37; margin-top: 4px; }
        .link { border: 0; background: none; color: #8b85ff; cursor: pointer; padding: 0; font-size: 11.5px; }
      </style>
      <button class="btn" type="button" title="Descargar este video con Belerofonte">⬇ Descargar</button>
      <div class="menu" role="menu"></div>`;
    button = shadow.querySelector('.btn');
    menu = shadow.querySelector('.menu');
    button.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      menuOpen ? closeMenu() : openMenu();
    });
    host.addEventListener('mouseenter', () => clearTimeout(hideTimer));
    host.addEventListener('mouseleave', () => scheduleHide());
    // Que los clics en el botón no lleguen al reproductor (pausar, pantalla completa…).
    for (const type of ['mousedown', 'mouseup', 'pointerdown', 'pointerup', 'dblclick']) {
      host.addEventListener(type, (event) => event.stopPropagation());
    }
    (document.fullscreenElement && document.fullscreenElement.tagName !== 'VIDEO' ? document.fullscreenElement : document.documentElement).append(host);
  }

  function place() {
    if (!current || !host) return;
    const r = current.getBoundingClientRect();
    if (!r.width || r.bottom < 0 || r.top > innerHeight) return hide(true);
    host.style.display = 'block';
    const width = host.offsetWidth || 120;
    const top = Math.max(8, Math.min(r.top + 10, innerHeight - 44));
    const left = Math.max(8, Math.min(r.right - width - 10, innerWidth - width - 8));
    host.style.top = `${top}px`;
    host.style.left = `${left}px`;
  }

  function show(video) {
    ui();
    if (current !== video) closeMenu();
    current = video;
    clearTimeout(hideTimer);
    place();
    scheduleHide();
  }

  function scheduleHide() {
    clearTimeout(hideTimer);
    if (menuOpen) return;
    hideTimer = setTimeout(() => hide(), HIDE_MS);
  }

  function hide(force = false) {
    if (!host || (menuOpen && !force)) return;
    closeMenu();
    host.style.display = 'none';
    current = null;
  }

  function videoAt(x, y) {
    for (const video of videos) {
      const r = video.getBoundingClientRect();
      if (r.width < MIN_WIDTH || r.height < MIN_HEIGHT) continue;
      if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) return video;
    }
    return null;
  }

  let pending = false;
  document.addEventListener('mousemove', (event) => {
    if (!enabled || !videos.length || pending) return;
    pending = true;
    const { clientX, clientY } = event;
    requestAnimationFrame(() => {
      pending = false;
      const video = videoAt(clientX, clientY);
      if (video) show(video);
    });
  }, { passive: true, capture: true });

  addEventListener('scroll', () => current && place(), { passive: true, capture: true });
  addEventListener('resize', () => current && place(), { passive: true });
  document.addEventListener('fullscreenchange', () => {
    if (!host) return;
    const target = document.fullscreenElement;
    (target && target.tagName !== 'VIDEO' ? target : document.documentElement).append(host);
    hide(true);
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && menuOpen) hide(true);
  });
  document.addEventListener('click', (event) => {
    if (menuOpen && !event.composedPath().includes(host)) hide(true);
  }, true);

  function message(text) {
    menu.replaceChildren(Object.assign(document.createElement('div'), { className: 'msg', textContent: text }));
  }

  function footer() {
    const foot = Object.assign(document.createElement('div'), { className: 'foot' });
    const manager = Object.assign(document.createElement('button'), { className: 'link', type: 'button', textContent: '📥 Gestor de descargas' });
    manager.addEventListener('click', () => {
      chrome.runtime.sendMessage({ type: 'dm-open' }).catch(() => {});
      hide(true);
    });
    const off = Object.assign(document.createElement('button'), { className: 'link', type: 'button', textContent: 'Ocultar este botón' });
    off.title = 'Se vuelve a activar en Ajustes del gestor de descargas';
    off.addEventListener('click', () => chrome.storage.local.set({ dmFloat: false }));
    foot.append(manager, off);
    return foot;
  }

  async function openMenu() {
    if (!current) return;
    menuOpen = true;
    clearTimeout(hideTimer);
    menu.classList.add('open');
    message('Buscando el video…');
    let response;
    try {
      response = await chrome.runtime.sendMessage({ type: 'float-options', src: current.currentSrc || current.src || '', link: videoLink(current) });
    } catch {
      return message('La extensión se actualizó: recarga la página para usar el botón.');
    }
    if (!menuOpen) return;
    if (!response?.ok) return message(response?.error || 'No se pudieron buscar opciones.');
    if (!response.options.length) {
      message(isStreaming()
        ? 'Este reproductor transmite el video por partes (MediaSource). Dale a reproducir unos segundos para que pida su lista de video y vuelve a pulsar «Descargar».'
        : 'Todavía no se detecta el archivo de este video. Dale a reproducir unos segundos y vuelve a pulsar «Descargar».');
      menu.append(footer());
      return;
    }
    const nodes = response.options.map((option) => {
      const opt = Object.assign(document.createElement('button'), { className: 'opt', type: 'button', title: option.download.url });
      opt.append(
        Object.assign(document.createElement('b'), { textContent: option.label }),
        Object.assign(document.createElement('small'), { textContent: option.sub || '' }),
      );
      opt.addEventListener('click', () => choose(option));
      return opt;
    });
    menu.replaceChildren(...nodes, footer());
  }

  async function choose(option) {
    message('Iniciando la descarga…');
    try {
      const res = await chrome.runtime.sendMessage({ type: 'float-download', download: option.download });
      if (!res?.ok) return message(res?.error || 'No se pudo descargar.');
      message({
        manager: '✓ Añadido al gestor de descargas.',
        hls: '✓ Se abrió la pestaña para elegir la calidad y descargar.',
        ytdlp: '✓ Se abrió la pestaña de descarga (yt-dlp).',
      }[res.opened] || '✓ Descarga iniciada.');
      setTimeout(() => hide(true), 1800);
    } catch {
      message('La extensión se actualizó: recarga la página para usar el botón.');
    }
  }

  // Enlace del video que hay debajo del reproductor: en las vistas previas (portada de YouTube,
  // búsqueda, canales…) el <video> se pone encima de la miniatura, que es un enlace a ese video.
  const VIDEO_LINK = /\/watch\?|\/shorts\/|\/live\/|youtu\.be\/|\/reel\/|\/video\/|vimeo\.com\/\d/;
  function videoLink(video) {
    const own = video.closest('a[href]');
    if (own && VIDEO_LINK.test(own.href)) return own.href;
    const r = video.getBoundingClientRect();
    for (const [x, y] of [[0.5, 0.5], [0.2, 0.2], [0.8, 0.8]]) {
      for (const el of document.elementsFromPoint(r.left + r.width * x, r.top + r.height * y)) {
        if (el === host) continue;
        const a = el.closest('a[href]');
        if (a && VIDEO_LINK.test(a.href)) return a.href;
      }
    }
    // Vista previa de YouTube: su enlace va en el propio contenedor de la vista previa.
    const preview = video.closest('ytd-video-preview, #inline-preview-player, ytd-thumbnail')?.querySelector('a[href*="/watch"], a[href*="/shorts/"]')
      || document.querySelector('ytd-video-preview a#media-container-link, ytd-video-preview a[href*="/watch"]');
    return preview?.href || '';
  }

  // Un <video> con dirección blob: lo alimenta un reproductor por MediaSource (HLS o DASH).
  function isStreaming() {
    return /^blob:/i.test(current?.currentSrc || current?.src || '');
  }

  function closeMenu() {
    menuOpen = false;
    menu?.classList.remove('open');
  }
})();
