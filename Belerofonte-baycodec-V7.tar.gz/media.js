// Videos de la pestaña: detecta archivos (mp4, webm…) y listas HLS (.m3u8) que carga la página,
// clasifica las listas y lanza la descarga. No descarga contenido cifrado ni con DRM.

import { fetchPlaylist, parsePlaylist } from './video/hls.js';
import { parseMpd, dashSummary } from './video/dash.js';
import { okruId, okruVideo, pickQuality, safeFileName } from './okru.js';

const FILE_EXT = /\.(mp4|m4v|webm|mov|mkv|ogv|mp3|m4a|ogg|oga|wav|flac)(?:$|[?#])/i;
const HLS_EXT = /\.m3u8(?:$|[?#])/i;
const HLS_TYPE = /mpegurl/i;
const DASH_EXT = /\.mpd(?:$|[?#])/i;
const DASH_TYPE = /dash\+xml/i;
const isStream = (kind) => kind === 'hls' || kind === 'dash';
const MEDIA_TYPE = /^(video|audio)\//i;
// Segmentos sueltos de un stream: no se listan (se descargan a través de su lista).
const SEGMENT_EXT = /\.(ts|m4s|m4f|cmfv|cmfa|aac)(?:$|[?#])/i;
// Trozos de una pista DASH pedidos por rango en la URL (Instagram, Facebook): video y audio van por
// separado, así que descargarlos da un archivo sin sonido o incompleto.
const RANGE_SEGMENT = /[?&]bytestart=\d/i;
const MAX_PER_TAB = 40;
// YouTube no se descarga desde la red de la pestaña (sus streams van troceados y protegidos): se
// descarga con yt-dlp a través del conector nativo (native/). Ver video/video.js. Vimeo también usa
// yt-dlp, pero sus listas HLS (vimeocdn.com) sí se listan: si Vimeo bloquea a yt-dlp, el video que se
// reproduce en el navegador se puede bajar desde ahí (salvo que tenga DRM, que se marca como Protegido).
const BLOCKED_HOSTS = /(^|\.)(youtube\.com|youtube-nocookie\.com|youtu\.be|googlevideo\.com)$/i;
const YOUTUBE_HOSTS = /(^|\.)(youtube\.com|youtu\.be|youtube-nocookie\.com)$/i;

// Enlace de un video concreto de YouTube → youtube.com/watch?v=ID. La portada, la búsqueda o un canal
// no son un video (yt-dlp no sabría qué bajar): devuelven null.
//   /watch?v=ID · /shorts/ID · /live/ID · /embed/ID (también youtube-nocookie.com) · youtu.be/ID
export function youtubeVideoUrl(url) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return null;
  }
  if (!YOUTUBE_HOSTS.test(parsed.hostname)) return null;
  const id = /^youtu\.be$/i.test(parsed.hostname)
    ? parsed.pathname.split('/')[1]
    : parsed.pathname === '/watch' ? parsed.searchParams.get('v')
      : parsed.pathname.match(/^\/(?:shorts|live|embed|v)\/([\w-]{11})/)?.[1];
  return /^[\w-]{11}$/.test(id || '') ? `https://www.youtube.com/watch?v=${id}` : null;
}

const isYouTube = (url) => !!youtubeVideoUrl(url);

// Enlace de un video de Vimeo → el del reproductor (player.vimeo.com/video/ID), que yt-dlp puede leer
// sin iniciar sesión (con vimeo.com/ID pide una cuenta). Los videos ocultos llevan un hash (?h=…).
//   vimeo.com/123 · vimeo.com/123/abc · vimeo.com/channels/x/123 · player.vimeo.com/video/123?h=abc
export function vimeoPlayerUrl(url) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return null;
  }
  if (!/(^|\.)vimeo\.com$/i.test(parsed.hostname)) return null;
  const match = parsed.pathname.match(/(?:^|\/)(\d{5,})(?:\/([0-9a-f]{6,}))?\/?$/i);
  if (!match) return null;
  const hash = parsed.searchParams.get('h') || match[2];
  return `https://player.vimeo.com/video/${match[1]}${hash ? `?h=${hash}` : ''}`;
}

// Enlace de un video de TikTok → el que entiende yt-dlp. Los cortos (vm.tiktok.com/…, /t/…) se pasan
// tal cual (yt-dlp sigue la redirección); los del reproductor insertado (/embed/v2/ID, /player/v1/ID)
// no los admite, así que se cambian por /@/video/ID.
//   tiktok.com/@usuario/video/123 · vm.tiktok.com/ZMabc/ · tiktok.com/t/ZTabc/ · tiktok.com/embed/v2/123
export function tiktokUrl(url) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return null;
  }
  if (!/(^|\.)tiktok\.com$/i.test(parsed.hostname)) return null;
  if (/^(vm|vt)\./i.test(parsed.hostname) || /^\/t\/\w+/.test(parsed.pathname)) return parsed.href;
  if (/^\/@[^/]*\/video\/\d+/.test(parsed.pathname)) return `https://www.tiktok.com${parsed.pathname}`;
  const id = parsed.pathname.match(/^\/(?:embed(?:\/v\d)?|player\/v\d|v)\/(\d{10,})/)?.[1];
  return id ? `https://www.tiktok.com/@/video/${id}` : null;
}

// Enlace de una publicación de Instagram → su forma canónica. Las historias (que exigen sesión) se
// pasan tal cual. La mayoría de reels solo se leen con la sesión iniciada: video/video.js envía a
// yt-dlp las cookies de instagram.com.
//   instagram.com/reel/CODE · /reels/CODE · /p/CODE · /usuario/p/CODE · /tv/CODE · /p/CODE/embed
export function instagramUrl(url) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return null;
  }
  if (!/(^|\.)instagram\.com$/i.test(parsed.hostname)) return null;
  if (/^\/stories\/[\w.]+\/\d+/.test(parsed.pathname)) return `https://www.instagram.com${parsed.pathname}`;
  const match = parsed.pathname.match(/^\/(?:[\w.]+\/)?(p|reels?|tv)\/([\w-]{5,})/);
  if (!match) return null;
  return `https://www.instagram.com/${match[1] === 'reels' ? 'reel' : match[1]}/${match[2]}/`;
}

// Enlace de un video de Facebook → con www.facebook.com (m., web. y mbasic. son la misma web). Los
// videos privados o de grupos exigen sesión: video/video.js envía a yt-dlp las cookies de facebook.com.
//   /reel/ID · /watch/?v=ID · /usuario/videos/ID · /video.php?v=ID · /groups/…/posts/ID ·
//   /usuario/posts/ID · /story.php · /permalink.php · /plugins/video.php?href=…
// Los de compartir (/share/v/…, /share/r/…, fb.watch/…) yt-dlp no los entiende: se siguen antes (shareTarget).
const FACEBOOK_PATH = /^\/(?:reel\/\d|watch\/?(?:live\/?)?$|video\.php$|story\.php$|permalink\.php$|plugins\/video\.php$|groups\/[^/]+\/(?:posts|permalink)\/|[\w.-]+\/(?:videos|posts)\/)/;
const FACEBOOK_SHARE = /^\/share\/[vrp]\/\w+/;

export function facebookUrl(url) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return null;
  }
  if (/^fb\.watch$/i.test(parsed.hostname)) return parsed.pathname.length > 1 ? parsed.href : null;
  if (!/(^|\.)facebook\.com$/i.test(parsed.hostname)) return null;
  if (!FACEBOOK_PATH.test(parsed.pathname) && !FACEBOOK_SHARE.test(parsed.pathname)) return null;
  if (/^\/(?:watch|video\.php$)/.test(parsed.pathname) && !parsed.searchParams.get('v')) return null;
  parsed.hostname = 'www.facebook.com';
  return parsed.href;
}

const isFacebookShare = (url) => {
  try {
    const { hostname, pathname } = new URL(url);
    return /^fb\.watch$/i.test(hostname) || FACEBOOK_SHARE.test(pathname);
  } catch {
    return false;
  }
};

// Sigue un enlace de compartir de Facebook hasta el video (con tu sesión, por si es de un grupo o
// privado). Si no se puede, se devuelve el original y yt-dlp lo intenta igualmente.
async function shareTarget(url) {
  try {
    const response = await fetch(url, { credentials: 'include', redirect: 'follow' });
    response.body?.cancel();
    const target = facebookUrl(response.url);
    return target && !isFacebookShare(target) ? target : url;
  } catch {
    return url;
  }
}

// ¿Lo descarga yt-dlp? Devuelve el nombre del sitio o null.
const ytdlpSite = (url) =>
  isYouTube(url) ? 'YouTube'
    : vimeoPlayerUrl(url) ? 'Vimeo'
      : tiktokUrl(url) ? 'TikTok'
        : instagramUrl(url) ? 'Instagram'
          : facebookUrl(url) ? 'Facebook'
            : null;
const ytdlpUrl = (url, site) =>
  ({ YouTube: youtubeVideoUrl, Vimeo: vimeoPlayerUrl, TikTok: tiktokUrl, Instagram: instagramUrl, Facebook: facebookUrl })[site]?.(url) || url;

const mediaKey = (tabId) => `media:${tabId}`;
const byTab = new Map(); // tabId -> Map(url -> entrada)
const classifying = new Map(); // url -> promesa

const isBlocked = (url) => {
  try {
    return BLOCKED_HOSTS.test(new URL(url).hostname);
  } catch {
    return false;
  }
};

async function tabMedia(tabId) {
  if (!byTab.has(tabId)) {
    const stored = (await chrome.storage.session.get(mediaKey(tabId)))[mediaKey(tabId)] || [];
    byTab.set(tabId, new Map(stored.map((m) => [m.url, m])));
  }
  return byTab.get(tabId);
}

const persist = (tabId) => chrome.storage.session.set({ [mediaKey(tabId)]: [...byTab.get(tabId).values()] });

const header = (headers = [], name) => headers.find((h) => h.name.toLowerCase() === name)?.value || '';

function fileName(url) {
  try {
    const parts = new URL(url).pathname.split('/').filter(Boolean).map(decodeURIComponent);
    const last = parts.pop() || 'video';
    // Nombres genéricos de listas ("index.m3u8", "playlist.m3u8"…): se añade la carpeta para distinguirlas.
    if (/^(index|playlist|master|chunklist|prog_index|manifest|stream)\b.*\.m3u8$/i.test(last) && parts.length) {
      return `${parts.pop()}/${last}`;
    }
    return last;
  } catch {
    return 'video';
  }
}

// Tamaño total: en respuestas parciales (206) viene en Content-Range ("bytes 0-1023/52428800").
function totalSize(headers, statusCode) {
  const range = header(headers, 'content-range').match(/\/(\d+)$/);
  if (range) return Number(range[1]);
  const length = Number(header(headers, 'content-length'));
  return statusCode === 200 && length ? length : null;
}

// Lista HLS creada en memoria por el reproductor (blob:): su texto se guarda aquí porque la
// dirección blob: solo existe dentro de la página. La usan classify y la página de descarga.
const inlineKey = (url) => `inline:${url}`;
async function loadPlaylist(url) {
  if (/^https?:/i.test(url)) return fetchPlaylist(url);
  const stored = (await chrome.storage.session.get(inlineKey(url)))[inlineKey(url)];
  if (!stored) throw new Error('la lista ya no está disponible: vuelve a reproducir el video');
  return parsePlaylist(stored.text, stored.base);
}

// Muchos servidores solo entregan la lista con el Referer del reproductor: mientras se lee, una regla
// temporal se lo añade a las peticiones de la extensión hacia ese servidor.
let classifyRule = 0;
async function withReferer(referer, url, task) {
  let target = '';
  try {
    target = new URL(url).hostname;
  } catch { /* blob: */ }
  if (!httpUrl(referer) || !target) return task();
  const id = 1_500_000 + (classifyRule++ % 1000);
  try {
    await chrome.declarativeNetRequest.updateSessionRules({
      removeRuleIds: [id],
      addRules: [{
        id,
        priority: 1,
        condition: { initiatorDomains: [chrome.runtime.id], requestDomains: [target], resourceTypes: ['xmlhttprequest', 'other'] },
        action: {
          type: 'modifyHeaders',
          requestHeaders: [
            { header: 'referer', operation: 'set', value: referer },
            { header: 'origin', operation: 'set', value: new URL(referer).origin },
          ],
        },
      }],
    });
  } catch {
    return task();
  }
  try {
    return await task();
  } finally {
    chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [id] }).catch(() => {});
  }
}

function classify(entry) {
  return withReferer(entry.referer, entry.url, () => classifyNow(entry));
}

// Manifiesto DASH: de la red o, si el reproductor lo creó en memoria, del texto guardado.
async function loadManifest(url) {
  if (/^https?:/i.test(url)) {
    const response = await fetch(url, { credentials: 'include' });
    if (!response.ok) throw new Error(`El servidor respondió ${response.status} al pedir el manifiesto.`);
    return parseMpd(await response.text(), response.url || url);
  }
  const stored = (await chrome.storage.session.get(inlineKey(url)))[inlineKey(url)];
  if (!stored) throw new Error('el manifiesto ya no está disponible: vuelve a reproducir el video');
  return parseMpd(stored.text, stored.base);
}

async function classifyNow(entry) {
  if (entry.kind === 'dash') {
    try {
      entry.info = dashSummary(await loadManifest(entry.url));
    } catch (err) {
      entry.info = { error: err.message };
    }
    return;
  }
  try {
    const playlist = await loadPlaylist(entry.url);
    if (playlist.type === 'master') {
      const audioUris = playlist.renditions.map((r) => r.uri).filter(Boolean);
      entry.info = {
        playlist: 'master',
        subtitles: playlist.renditions.filter((r) => r.type === 'SUBTITLES' && r.uri).map((r) => r.language || r.name),
        qualities: playlist.variants.length,
        maxHeight: Math.max(0, ...playlist.variants.map((v) => v.height || 0)) || null,
        children: [...playlist.variants.map((v) => v.uri), ...audioUris],
      };
      // Para saber si está cifrado hay que mirar una de sus listas de medios.
      const first = playlist.variants[0];
      if (first) {
        const media = await fetchPlaylist(first.uri);
        Object.assign(entry.info, { encryption: media.encryption, live: media.live, duration: media.duration });
      }
    } else {
      entry.info = { playlist: 'media', encryption: playlist.encryption, live: playlist.live, duration: playlist.duration };
    }
  } catch (err) {
    entry.info = { error: err.message };
  }
}

async function addMedia(tabId, entry) {
  const list = await tabMedia(tabId);
  const existing = list.get(entry.url);
  if (existing) {
    if (!existing.size && entry.size) existing.size = entry.size;
    return;
  }
  if (list.size >= MAX_PER_TAB) list.delete(list.keys().next().value);
  list.set(entry.url, entry);
  if (isStream(entry.kind)) {
    const job = classify(entry).then(() => persist(tabId));
    classifying.set(entry.url, job);
    job.finally(() => classifying.delete(entry.url));
  }
  persist(tabId);
}

// --- Detección ------------------------------------------------------------------------

chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    if (details.tabId < 0 || details.statusCode >= 400) return;
    if (details.initiator?.startsWith('chrome-extension://')) return; // peticiones de la propia extensión
    const { url } = details;
    if (!/^https?:/i.test(url) || isBlocked(url) || SEGMENT_EXT.test(url) || RANGE_SEGMENT.test(url)) return;
    const type = header(details.responseHeaders, 'content-type');

    if (HLS_EXT.test(url) || HLS_TYPE.test(type)) {
      // documentUrl: la página o el iframe del reproductor que pidió la lista (su Referer suele hacer falta).
      addMedia(details.tabId, { url, kind: 'hls', name: fileName(url), referer: httpUrl(details.documentUrl) || '', detectedAt: Date.now() });
    } else if (DASH_EXT.test(url) || DASH_TYPE.test(type)) {
      addMedia(details.tabId, { url, kind: 'dash', name: fileName(url), referer: httpUrl(details.documentUrl) || '', detectedAt: Date.now() });
    } else if (FILE_EXT.test(url) || MEDIA_TYPE.test(type)) {
      if (/mp2t|iso.segment/i.test(type)) return;
      addMedia(details.tabId, {
        url,
        kind: 'file',
        name: fileName(url),
        type: type.split(';')[0] || null,
        size: totalSize(details.responseHeaders, details.statusCode),
        detectedAt: Date.now(),
      });
    }
  },
  { urls: ['<all_urls>'], types: ['media', 'xmlhttprequest', 'other', 'object'] },
  ['responseHeaders'],
);

// Al cargar otra página en la pestaña se vacía la lista.
chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    if (details.tabId < 0) return;
    byTab.set(details.tabId, new Map());
    chrome.storage.session.remove(mediaKey(details.tabId));
  },
  { urls: ['<all_urls>'], types: ['main_frame'] },
);

chrome.tabs.onRemoved.addListener((tabId) => {
  byTab.delete(tabId);
  chrome.storage.session.remove(mediaKey(tabId));
});

// Videos que ya estaban en caché y no pasaron por la red: se buscan en el DOM. También los
// reproductores de Vimeo insertados (<iframe src="player.vimeo.com/video/…">), que baja yt-dlp.
function findVideoElements() {
  const urls = [];
  for (const node of document.querySelectorAll('video, video source, audio, audio source')) {
    for (const url of [node.currentSrc, node.src]) if (url && /^https?:/i.test(url)) urls.push(url);
  }
  for (const frame of document.querySelectorAll('iframe[src*="player.vimeo.com/video/"], iframe[src*="ok.ru/videoembed/"], iframe[src*="tiktok.com/"]')) {
    urls.push(frame.src);
  }
  // TikTok insertado con su código oficial: <blockquote class="tiktok-embed" cite="…/video/ID">.
  for (const quote of document.querySelectorAll('blockquote.tiktok-embed[cite]')) urls.push(quote.cite);
  // Instagram insertado: <iframe src="…/p/CODE/embed"> o <blockquote class="instagram-media" data-instgrm-permalink>.
  for (const frame of document.querySelectorAll('iframe[src*="instagram.com/"]')) urls.push(frame.src);
  // Facebook insertado: <iframe src="facebook.com/plugins/video.php?href=…"> o <div class="fb-video" data-href>.
  for (const frame of document.querySelectorAll('iframe[src*="facebook.com/plugins/video.php"]')) urls.push(frame.src);
  for (const div of document.querySelectorAll('.fb-video[data-href]')) urls.push(div.dataset.href);
  for (const quote of document.querySelectorAll('blockquote.instagram-media[data-instgrm-permalink]')) {
    urls.push(quote.dataset.instgrmPermalink);
  }
  return [...new Set(urls)];
}

const MAX_OKRU_EMBEDS = 3;

// Un video de OK.ru → una entrada por calidad (MP4 directo); en directo, su lista HLS para grabarla.
async function okruItems(id) {
  const video = await okruVideo(id);
  if (video.live || !video.qualities.length) {
    return video.hls ? [{ url: video.hls, kind: 'hls', site: 'OK.ru', name: video.title, detectedAt: Date.now() }] : [];
  }
  return video.qualities.map((q) => ({
    url: q.url,
    kind: 'file',
    site: 'OK.ru',
    quality: q.height ? `${q.height}p` : q.name,
    name: video.title,
    filename: `${safeFileName(video.title)} [${q.height ? `${q.height}p` : q.name}].mp4`,
    detectedAt: Date.now(),
  }));
}

// --- API para el popup ----------------------------------------------------------------

export async function listMedia({ tabId }) {
  const tab = await chrome.tabs.get(tabId);
  // En la página de un video de YouTube o Vimeo se rellena el enlace para bajarlo con yt-dlp. En Vimeo
  // se listan además los streams que haya cargado el reproductor (alternativa si yt-dlp falla).
  const site = ytdlpSite(tab.url || '');
  const ytdlp = site ? { url: ytdlpUrl(tab.url, site), title: tab.title, site } : null;
  if (site === 'YouTube' || isBlocked(tab.url || '')) return { ytdlp, items: [] };
  // En la página de un video de OK.ru solo interesan sus calidades (no los anuncios ni los trozos).
  const okId = okruId(tab.url || '');
  if (okId) return { ytdlp: null, items: await okruItems(okId) };

  const extra = []; // videos de OK.ru insertados: sus enlaces caducan, así que no se guardan
  try {
    const frames = await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, func: findVideoElements });
    const okIds = new Set();
    for (const url of frames.flatMap((f) => f.result || [])) {
      const embedded = okruId(url);
      if (embedded) {
        okIds.add(embedded);
        continue;
      }
      const vimeo = vimeoPlayerUrl(url);
      if (vimeo) {
        addMedia(tabId, { url: vimeo, kind: 'ytdlp', site: 'Vimeo', name: `Vimeo ${vimeo.match(/\d+/)[0]}`, detectedAt: Date.now() });
        continue;
      }
      const tiktok = tiktokUrl(url);
      if (tiktok) {
        // En la propia web de TikTok ya se ofrece el video de la pestaña (y el feed carga muchos).
        if (site !== 'TikTok') {
          addMedia(tabId, { url: tiktok, kind: 'ytdlp', site: 'TikTok', name: `TikTok ${tiktok.match(/\d{10,}/)?.[0] || ''}`.trim(), detectedAt: Date.now() });
        }
        continue;
      }
      const instagram = instagramUrl(url);
      if (instagram) {
        if (site !== 'Instagram') {
          addMedia(tabId, { url: instagram, kind: 'ytdlp', site: 'Instagram', name: `Instagram ${instagram.split('/')[4]}`, detectedAt: Date.now() });
        }
        continue;
      }
      const facebook = facebookUrl(url);
      if (facebook) {
        if (site !== 'Facebook') {
          addMedia(tabId, { url: facebook, kind: 'ytdlp', site: 'Facebook', name: `Facebook ${facebook.match(/\d{6,}/)?.[0] || 'video'}`, detectedAt: Date.now() });
        }
        continue;
      }
      if (isBlocked(url)) continue;
      addMedia(tabId, HLS_EXT.test(url)
        ? { url, kind: 'hls', name: fileName(url), detectedAt: Date.now() }
        : { url, kind: 'file', name: fileName(url), type: null, size: null, detectedAt: Date.now() });
    }
    const found = await Promise.allSettled([...okIds].slice(0, MAX_OKRU_EMBEDS).map(okruItems));
    extra.push(...found.flatMap((r) => (r.status === 'fulfilled' ? r.value : [])));
  } catch {
    // Páginas en las que no se puede inyectar: solo cuenta lo detectado por red.
  }

  await Promise.allSettled([...classifying.values()]);
  const list = [...(await tabMedia(tabId)).values()];

  // Las listas que forman parte de una maestra ya detectada no se muestran por separado.
  const children = new Set(list.flatMap((m) => m.info?.children || []));
  const items = list.filter((m) => !children.has(m.url));
  return { ytdlp, items: [...extra, ...items] };
}

// --- Referer ----------------------------------------------------------------------------
// Muchos servidores de video (sobre todo los de enlaces con token) rechazan las peticiones que no
// llevan como Referer la página donde está el video. fetch no permite fijarlo, así que la página de
// descarga de la extensión lo recibe con una regla de declarativeNetRequest limitada a su pestaña.
// (Los archivos directos los baja el gestor de descargas, que pone sus propias reglas; ver downloads/.
// reintenta desde la página de descarga.)

// Cada pestaña de descarga tiene su propia regla, con un ID fijo y muy por encima de los que usa el
// simulador (que toma los más bajos libres): así nunca se pisan ni se borran entre sí.
const REFERER_RULE_BASE = 1_000_000;
const refererRuleId = (tabId) => REFERER_RULE_BASE + tabId;

// La página de descarga lo pide antes de empezar: sus peticiones llevarán el Referer y el Origin de
// la web del video mientras la pestaña esté abierta.
export async function prepareReferer({ referer }, sender) {
  if (!httpUrl(referer) || !sender.tab) return {};
  const id = refererRuleId(sender.tab.id);
  await chrome.declarativeNetRequest.updateSessionRules({
    removeRuleIds: [id],
    addRules: [{
      id,
      priority: 1,
      condition: { tabIds: [sender.tab.id], resourceTypes: ['xmlhttprequest', 'media', 'other'] },
      action: {
        type: 'modifyHeaders',
        requestHeaders: [
          { header: 'referer', operation: 'set', value: referer },
          { header: 'origin', operation: 'set', value: new URL(referer).origin },
        ],
      },
    }],
  });
  return {};
}

chrome.tabs.onRemoved.addListener((tabId) => {
  chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [refererRuleId(tabId)] }).catch(() => {});
});

const httpUrl = (url) => (/^https?:/i.test(url || '') ? url : null);

function openDownloadPage(tab, params) {
  const page = new URL(chrome.runtime.getURL('video/video.html'));
  for (const [key, value] of Object.entries(params)) if (value) page.searchParams.set(key, value);
  return chrome.tabs.create({ url: page.href, windowId: tab.windowId, index: tab.index + 1, openerTabId: tab.id });
}

// --- Gestor de descargas (downloads/) ------------------------------------------------------------
// Los archivos directos se descargan con el gestor: varias conexiones, pausa y reanudación. Las
// entradas se le pasan como claves «dm:inbox:<id>» de chrome.storage.local, que la ventana del
// gestor lee (y borra) al abrirse o en cuanto aparecen.

const MANAGER_PATH = 'downloads/downloads.html';

export async function openManager() {
  const url = chrome.runtime.getURL(MANAGER_PATH);
  // Sin el permiso «tabs» no se ve la URL de las pestañas (tampoco las de la propia extensión):
  // runtime.getContexts sí encuentra las páginas abiertas de la extensión.
  const [existing] = await chrome.runtime.getContexts({ contextTypes: ['TAB'], documentUrls: [url] });
  if (existing && existing.tabId >= 0) {
    await chrome.windows.update(existing.windowId, { focused: true }).catch(() => {});
    await chrome.tabs.update(existing.tabId, { active: true }).catch(() => {});
    return { tabId: existing.tabId };
  }
  const win = await chrome.windows.create({ url, type: 'popup', width: 980, height: 700, focused: true });
  return { tabId: win.tabs?.[0]?.id };
}

// entry: { url, referer, pageUrl, filename } (descarga nueva) o { kind: 'hls' | 'ytdlp', name, size, path } (historial).
export async function queueDownload(entry, { open = true } = {}) {
  const id = crypto.randomUUID();
  await chrome.storage.local.set({ [`dm:inbox:${id}`]: { ...entry, id, added: Date.now() } });
  if (open) await openManager();
  return { opened: 'manager' };
}

// filename: nombre con el que guardarlo (si el enlace no lo lleva, p. ej. los de OK.ru).
function downloadFile(tab, url, referer, filename) {
  return queueDownload({ url, referer, filename: filename ? safeFileName(filename) : '', pageUrl: tab?.url || '' });
}

// ¿Es una lista HLS o un manifiesto DASH? Por la extensión o, si no la tiene, por el Content-Type
// que devuelve el servidor. Devuelve 'hls', 'dash' o null.
async function streamKind(url) {
  if (HLS_EXT.test(url)) return 'hls';
  if (DASH_EXT.test(url)) return 'dash';
  if (FILE_EXT.test(url)) return null;
  try {
    const response = await fetch(url, { method: 'HEAD', credentials: 'include' });
    const type = response.headers.get('content-type') || '';
    return HLS_TYPE.test(type) ? 'hls' : DASH_TYPE.test(type) ? 'dash' : null;
  } catch {
    return null;
  }
}

// kind: 'file' | 'hls' | 'ytdlp' | 'auto' (enlace pegado por el usuario).
// ytdlp: opciones para YouTube y Vimeo { calidad, soloAudio, subtitulos } (las mismas que la app Flask).
// fromManager: enlace pegado en la ventana del gestor (la pestaña activa no tiene nada que ver con él).
// referer: el del reproductor que pidió el video (puede ser un iframe de otro dominio); si no, la pestaña.
export async function downloadMedia({ tabId, url, kind, ytdlp = {}, filename, fromManager = false, referer: frameReferer }) {
  let parsed;
  try {
    parsed = new URL(url.trim());
  } catch {
    throw new Error('El enlace no es válido.');
  }
  const tab = await chrome.tabs.get(tabId);
  const referer = fromManager ? null : httpUrl(frameReferer) || httpUrl(tab.url);

  // Lista HLS o manifiesto DASH creado en memoria por el reproductor: se descarga con su texto guardado.
  if (parsed.protocol === 'blob:' && isStream(kind)) {
    if (!(await chrome.storage.session.get(inlineKey(parsed.href)))[inlineKey(parsed.href)]) {
      throw new Error('La lista del video ya no está disponible: vuelve a reproducirlo unos segundos.');
    }
    await openDownloadPage(tab, { url: parsed.href, inline: '1', kind: kind === 'dash' ? 'dash' : '', title: tab.title, referer });
    return { opened: 'hls' };
  }
  if (!/^https?:$/.test(parsed.protocol)) throw new Error('El enlace tiene que empezar por http:// o https://.');
  url = parsed.href;

  const site = ytdlpSite(url);
  if (site) {
    // El título de la pestaña solo sirve si la pestaña es la del propio video.
    const onVideoPage = !fromManager && ytdlpSite(tab.url || '') === site;
    await openDownloadPage(tab, {
      url: isFacebookShare(url) ? await shareTarget(url) : ytdlpUrl(url, site),
      kind: 'ytdlp',
      site,
      title: onVideoPage ? tab.title : '',
      // Vimeo: muchos videos insertados solo se pueden ver desde la web que los inserta.
      referer: site === 'Vimeo' && !onVideoPage ? referer : '',
      calidad: ytdlp.calidad || 'mejor',
      audio: ytdlp.soloAudio ? '1' : '',
      subs: ytdlp.subtitulos ? '1' : '',
    });
    return { opened: 'ytdlp' };
  }
  if (isBlocked(url)) {
    throw new Error('Este enlace es un trozo interno del reproductor: pega el enlace del video (youtube.com/watch?v=… o vimeo.com/…).');
  }

  // Enlace de OK.ru pegado: se lee su reproductor y se baja el MP4 de la calidad elegida.
  const okId = okruId(url);
  if (okId) {
    const video = await okruVideo(okId);
    const quality = pickQuality(video.qualities, ytdlp.calidad);
    if (!quality) {
      await openDownloadPage(tab, { url: video.hls, title: video.title, referer: 'https://ok.ru/' });
      return { opened: 'hls' };
    }
    const label = quality.height ? `${quality.height}p` : quality.name;
    return downloadFile(tab, quality.url, 'https://ok.ru/', `${video.title} [${label}].mp4`);
  }

  const stream = isStream(kind) ? kind : kind === 'auto' ? await streamKind(url) : null;
  if (stream) {
    await openDownloadPage(tab, { url, kind: stream === 'dash' ? 'dash' : '', title: fromManager ? '' : tab.title, referer });
    return { opened: 'hls' };
  }

  return downloadFile(fromManager ? null : tab, url, referer, filename);
}

// Enlace pegado en el gestor: las páginas de HLS y yt-dlp se abren en la ventana normal más reciente.
export async function addFromManager({ url }) {
  let win = null;
  try {
    win = await chrome.windows.getLastFocused({ windowTypes: ['normal'], populate: true });
  } catch { /* no hay ninguna ventana normal */ }
  let tab = win?.tabs?.find((t) => t.active);
  if (!tab) tab = (await chrome.windows.create({ focused: false })).tabs[0];
  return downloadMedia({ tabId: tab.id, url, kind: 'auto', fromManager: true });
}

// --- Botón flotante sobre los videos (float/float.js) ----------------------------------------
// Al pulsarlo, se le ofrecen las formas de bajar ese video: yt-dlp en los sitios que lo admiten, el
// archivo del <video> si tiene una URL normal y lo que haya detectado la extensión en la pestaña.

const mbText = (bytes) => (bytes >= 1073741824 ? `${(bytes / 1073741824).toFixed(1)} GB` : `${(bytes / 1048576).toFixed(1)} MB`);

function optionFor(item) {
  if (item.kind === 'ytdlp') {
    return { label: `Video de ${item.site}`, sub: 'yt-dlp · mejor calidad', download: { url: item.url, kind: 'ytdlp' } };
  }
  if (isStream(item.kind)) {
    const info = item.info || {};
    const label = item.kind === 'dash' ? 'Stream DASH' : 'Stream HLS';
    const download = { url: item.url, kind: item.kind, referer: item.referer };
    if (info.encryption?.length) return null;
    if (info.error) {
      // Desde aquí no se pudo leer (suele faltar el Referer del reproductor): la página de descarga lo reintenta con él.
      return { label: item.name, sub: `${label} → MP4 · se abrirá con el Referer del reproductor`, download };
    }
    const parts = [info.live ? '🔴 Directo: grabar' : `${label} → MP4`];
    if (info.maxHeight) parts.push(`hasta ${info.maxHeight}p`);
    if (info.qualities > 1) parts.push(`${info.qualities} calidades`);
    if (info.subtitles?.length) parts.push(`💬 ${[...new Set(info.subtitles)].join(', ')}`);
    return { label: item.name, sub: parts.join(' · '), download };
  }
  const sub = [item.quality, item.type, item.size && mbText(item.size), 'gestor de descargas'].filter(Boolean).join(' · ');
  return { label: item.name, sub, download: { url: item.url, kind: 'file', filename: item.filename, referer: item.referer } };
}

export async function floatOptions({ src, link }, sender) {
  const tabId = sender.tab?.id;
  if (tabId == null) throw new Error('No se encontró la pestaña.');
  const frameUrl = sender.url || '';
  const topUrl = sender.tab.url || '';
  const options = [];

  // link: el enlace del video que hay bajo el ratón (p. ej. la vista previa de una miniatura en la
  // portada de YouTube, donde la pestaña no es la de ningún video).
  const sitePage = [frameUrl, topUrl, link || ''].find((u) => ytdlpSite(u)) || null;
  if (sitePage) {
    const site = ytdlpSite(sitePage);
    options.push(
      { label: `Video de ${site} · mejor calidad`, sub: 'yt-dlp · MP4', download: { url: sitePage, kind: 'auto', ytdlp: { calidad: 'mejor' } } },
      { label: `Video de ${site} · 720p`, sub: 'yt-dlp · MP4 más ligero', download: { url: sitePage, kind: 'auto', ytdlp: { calidad: '720' } } },
      { label: 'Solo audio MP3', sub: 'yt-dlp · 192 kbps', download: { url: sitePage, kind: 'auto', ytdlp: { soloAudio: true, calidad: '192' } } },
    );
    if (site === 'YouTube') return { options };
  }

  const seen = new Set();
  if (src && /^https?:/i.test(src) && !isBlocked(src)) {
    seen.add(src);
    options.push(HLS_EXT.test(src)
      ? { label: fileName(src), sub: 'Stream HLS → MP4', download: { url: src, kind: 'hls' } }
      : DASH_EXT.test(src)
        ? { label: fileName(src), sub: 'Stream DASH → MP4', download: { url: src, kind: 'dash' } }
        : { label: fileName(src), sub: 'Archivo del video · gestor de descargas', download: { url: src, kind: 'file' } });
  }
  try {
    const { items } = await listMedia({ tabId });
    const sorted = [...items].sort((a, b) => (isStream(a.kind) ? 0 : 1) - (isStream(b.kind) ? 0 : 1) || b.detectedAt - a.detectedAt);
    for (const item of sorted) {
      if (seen.has(item.url) || (sitePage && item.kind === 'ytdlp')) continue;
      seen.add(item.url);
      const option = optionFor(item);
      if (option) options.push(option);
    }
  } catch { /* solo lo del propio <video> */ }
  return { options: options.slice(0, 8) };
}

export async function floatDownload({ download }, sender) {
  if (!download?.url || sender.tab?.id == null) throw new Error('Falta el enlace.');
  const { url, kind, ytdlp, filename, referer } = download;
  return downloadMedia({ tabId: sender.tab.id, url, kind: kind || 'auto', ytdlp, filename, referer });
}

// --- Listas HLS encontradas dentro de la página (float/sniff.js) -------------------------------
// Sirve para los reproductores con <video src="blob:…"> (MediaSource): la lista puede venir con
// otro nombre (.txt, .png, sin extensión), así que la red no la reconoce, o crearse en memoria.

export async function mediaFound({ url, text, kind: found }, sender) {
  const tabId = sender.tab?.id;
  if (tabId == null || typeof url !== 'string' || isBlocked(url)) return {};
  const frame = httpUrl(sender.url) || httpUrl(sender.tab.url) || '';
  const kind = found === 'dash' ? 'dash' : 'hls';

  if (/^https?:/i.test(url)) {
    if (SEGMENT_EXT.test(url) && !HLS_EXT.test(url)) return {};
    // Listas con nombres que no dicen nada («source», «api», «get»…): el título de la pestaña.
    const named = kind === 'dash' ? DASH_EXT.test(url) : HLS_EXT.test(url);
    const name = named ? fileName(url) : `${sender.tab.title || new URL(url).hostname} · stream`;
    await addMedia(tabId, { url, kind, name, referer: frame, detectedAt: Date.now() });
    return {};
  }
  if (kind === 'dash') {
    if (!/^blob:/i.test(url) || typeof text !== 'string' || !text.includes('<MPD')) return {};
    try {
      const manifest = parseMpd(text, frame || url);
      if (!manifest.variants.length || !manifest.variants.every((v) => /^https?:/i.test(v.representation.base))) return {};
    } catch {
      return {};
    }
    await chrome.storage.session.set({ [inlineKey(url)]: { text, base: frame || url } });
    await addMedia(tabId, { url, kind: 'dash', name: 'Manifiesto DASH del reproductor (en memoria)', referer: frame, detectedAt: Date.now() });
    return {};
  }
  if (!/^blob:/i.test(url) || typeof text !== 'string' || !text.trimStart().startsWith('#EXTM3U')) return {};
  // Solo sirve si sus enlaces son direcciones normales (las relativas a un blob: no se pueden pedir).
  let playlist;
  try {
    playlist = parsePlaylist(text, frame || url);
  } catch {
    return {};
  }
  const uris = playlist.type === 'master' ? playlist.variants.map((v) => v.uri) : playlist.segments.map((s) => s.uri);
  if (!uris.length || !uris.every((u) => /^https?:/i.test(u))) return {};
  await chrome.storage.session.set({ [inlineKey(url)]: { text, base: frame || url } });
  await addMedia(tabId, { url, kind: 'hls', name: 'Lista HLS del reproductor (en memoria)', referer: frame, detectedAt: Date.now() });
  return {};
}
