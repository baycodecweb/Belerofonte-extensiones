// Título (y autor) de un video a partir de su enlace, con oEmbed: el servicio público que YouTube,
// Vimeo y TikTok ofrecen para mostrar sus videos en otras webs. Es una petición pequeña, sin cuenta
// ni clave, y responde al momento (yt-dlp tarda unos segundos en leer el video).

const ENDPOINTS = {
  YouTube: 'https://www.youtube.com/oembed?format=json&url=',
  Vimeo: 'https://vimeo.com/api/oembed.json?url=',
  TikTok: 'https://www.tiktok.com/oembed?url=',
};

const cache = new Map();

// Devuelve { title, author } o null si el sitio no lo admite o el video es privado.
export function oembedInfo(url, site) {
  const endpoint = ENDPOINTS[site];
  if (!endpoint || !/^https?:/i.test(url || '')) return Promise.resolve(null);
  const key = `${site}|${url}`;
  if (!cache.has(key)) {
    cache.set(key, fetch(endpoint + encodeURIComponent(url), { credentials: 'omit', signal: AbortSignal.timeout(6000) })
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => (data?.title ? { title: String(data.title), author: String(data.author_name || '') } : null))
      .catch(() => null));
  }
  return cache.get(key);
}

// «(3) Título - YouTube» → «Título» (el número entre paréntesis son las notificaciones).
export function cleanTitle(title) {
  return (title || '')
    .replace(/^\(\d+\+?\)\s*/, '')
    .replace(/ - YouTube$| on Vimeo$| \| TikTok$| • Instagram$| \| Facebook$/, '')
    .trim();
}
