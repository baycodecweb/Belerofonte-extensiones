// Subtítulos de los streams HLS y DASH: lee WebVTT, TTML (también EBU-TT-D / IMSC) y los que van
// dentro de MP4 fragmentado (wvtt = WebVTT, stpp = TTML), une los segmentos en una sola lista de
// frases y la convierte a SRT o WebVTT.
//
// Cada frase es { start, end, text } en segundos. Los tiempos se ajustan para que coincidan con el
// video guardado, que empieza en 0:00 (ver shiftCues en video.js).

const ENTITIES = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ', lrm: '‎', rlm: '‏' };
const decode = (s) => s.replace(/&(#x[0-9a-f]+|#\d+|\w+);/gi, (m, e) => {
  if (e[0] === '#') return String.fromCodePoint(e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : Number(e.slice(1)));
  return ENTITIES[e.toLowerCase()] ?? m;
});

// --- WebVTT ---------------------------------------------------------------------------------

// «01:02:03.456», «02:03.456» o con coma.
function vttTime(value) {
  const m = /^(?:(\d+):)?(\d{1,2}):(\d{1,2})[.,](\d{1,3})$/.exec(value.trim());
  if (!m) return NaN;
  return Number(m[1] || 0) * 3600 + Number(m[2]) * 60 + Number(m[3]) + Number(m[4].padEnd(3, '0')) / 1000;
}

// Devuelve { cues, map } (map: X-TIMESTAMP-MAP de HLS, { mpegts, local } en segundos, o null).
export function parseVtt(text) {
  const clean = text.replace(/^﻿/, '').replace(/\r\n?/g, '\n');
  let map = null;
  const header = clean.split('\n\n')[0];
  const ts = /X-TIMESTAMP-MAP=([^\n]+)/.exec(header);
  if (ts) {
    const mpegts = /MPEGTS:(\d+)/.exec(ts[1]);
    const local = /LOCAL:([\d:.]+)/.exec(ts[1]);
    map = { mpegts: mpegts ? Number(mpegts[1]) / 90000 : 0, local: local ? vttTime(local[1]) : 0 };
  }
  const cues = [];
  for (const block of clean.split(/\n{2,}/)) {
    const lines = block.split('\n');
    const at = lines.findIndex((l) => l.includes('-->'));
    if (at < 0) continue; // cabecera, NOTE, STYLE, REGION
    const [from, rest] = lines[at].split('-->');
    const start = vttTime(from);
    const end = vttTime(rest.trim().split(/\s+/)[0]);
    const body = lines.slice(at + 1).join('\n').trim();
    if (Number.isFinite(start) && Number.isFinite(end) && body) cues.push({ start, end, text: body });
  }
  return { cues, map };
}

// --- TTML (EBU-TT-D, IMSC, DFXP) ----------------------------------------------------------------

function ttmlTime(value, rates) {
  if (!value) return NaN;
  const v = value.trim();
  let m = /^(\d+):(\d{2}):(\d{2})(?:\.(\d+))?$/.exec(v);
  if (m) return Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]) + (m[4] ? Number(`0.${m[4]}`) : 0);
  m = /^(\d+):(\d{2}):(\d{2}):(\d+)(?:\.(\d+))?$/.exec(v); // con fotogramas
  if (m) return Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]) + Number(m[4]) / rates.frame;
  m = /^(\d+(?:\.\d+)?)(h|m|s|ms|f|t)$/.exec(v);
  if (m) {
    const n = Number(m[1]);
    return { h: n * 3600, m: n * 60, s: n, ms: n / 1000, f: n / rates.frame, t: n / rates.tick }[m[2]];
  }
  return NaN;
}

export function parseTtml(xml) {
  const root = /<(?:\w+:)?tt\b([^>]*)>/.exec(xml)?.[1] || '';
  const attr = (attrs, name) => new RegExp(`(?:^|\\s)(?:\\w+:)?${name}\\s*=\\s*"([^"]*)"`).exec(attrs)?.[1];
  const frame = Number(attr(root, 'frameRate')) * (Number((attr(root, 'frameRateMultiplier') || '1 1').split(/\s+/)[0]) / Number((attr(root, 'frameRateMultiplier') || '1 1').split(/\s+/)[1] || 1)) || 30;
  const rates = { frame, tick: Number(attr(root, 'tickRate')) || frame || 1 };
  const cues = [];
  for (const m of xml.matchAll(/<(?:\w+:)?p\b([^>]*)>([\s\S]*?)<\/(?:\w+:)?p>/g)) {
    const attrs = m[1];
    const start = ttmlTime(attr(attrs, 'begin'), rates);
    let end = ttmlTime(attr(attrs, 'end'), rates);
    if (!Number.isFinite(end)) end = start + ttmlTime(attr(attrs, 'dur'), rates);
    const text = decode(m[2]
      .replace(/<(?:\w+:)?br\s*\/?>/g, '\n')
      .replace(/<(?:\w+:)?span\b[^>]*fontStyle\s*=\s*"italic"[^>]*>([\s\S]*?)<\/(?:\w+:)?span>/g, '<i>$1</i>')
      .replace(/<(?!\/?i>)[^>]+>/g, ''))
      .split('\n').map((l) => l.replace(/\s+/g, ' ').trim()).filter(Boolean).join('\n');
    if (Number.isFinite(start) && Number.isFinite(end) && text) cues.push({ start, end, text });
  }
  return cues;
}

// --- Subtítulos dentro de MP4 fragmentado (wvtt / stpp) ---------------------------------------------

const boxText = (b, at) => String.fromCharCode(b[at], b[at + 1], b[at + 2], b[at + 3]);
function boxes(bytes, start = 0, end = bytes.length) {
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const out = [];
  for (let at = start; at + 8 <= end;) {
    let size = dv.getUint32(at);
    let header = 8;
    if (size === 1) {
      size = Number(dv.getBigUint64(at + 8));
      header = 16;
    } else if (size === 0) size = end - at;
    if (size < header || at + size > end) break;
    out.push({ type: boxText(bytes, at + 4), start: at, end: at + size, payload: at + header });
    at += size;
  }
  return out;
}
const find = (bytes, box, type) => boxes(bytes, box.payload, box.end).find((b) => b.type === type);
const path = (bytes, from, types) => types.reduce((box, type) => box && find(bytes, box, type), from);

// Escala de tiempo y tipo de muestra (wvtt, stpp…) de la pista del segmento de inicio.
export function textTrackInfo(init) {
  const moov = boxes(init).find((b) => b.type === 'moov');
  const trak = moov && find(init, moov, 'trak');
  const mdhd = trak && path(init, trak, ['mdia', 'mdhd']);
  const stsd = trak && path(init, trak, ['mdia', 'minf', 'stbl', 'stsd']);
  if (!mdhd || !stsd) return null;
  const dv = new DataView(init.buffer, init.byteOffset, init.byteLength);
  const v1 = init[mdhd.payload] === 1;
  return { timescale: dv.getUint32(mdhd.payload + (v1 ? 20 : 12)), codec: boxText(init, stsd.payload + 12) };
}

// Muestras de un segmento fMP4: [{ time, duration, data }] (time en la escala de la pista).
function samples(bytes) {
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const out = [];
  for (const moof of boxes(bytes).filter((b) => b.type === 'moof')) {
    for (const traf of boxes(bytes, moof.payload, moof.end).filter((b) => b.type === 'traf')) {
      const tfhd = find(bytes, traf, 'tfhd');
      const tfdt = find(bytes, traf, 'tfdt');
      if (!tfhd) continue;
      const tf = dv.getUint32(tfhd.payload) & 0xffffff;
      let p = tfhd.payload + 8;
      const baseOffset = tf & 0x1 ? Number(dv.getBigUint64(p)) : moof.start;
      if (tf & 0x1) p += 8;
      if (tf & 0x2) p += 4;
      const defDuration = tf & 0x8 ? dv.getUint32(p) : 0;
      if (tf & 0x8) p += 4;
      const defSize = tf & 0x10 ? dv.getUint32(p) : 0;
      let time = tfdt ? (bytes[tfdt.payload] === 1 ? Number(dv.getBigUint64(tfdt.payload + 4)) : dv.getUint32(tfdt.payload + 4)) : 0;
      for (const trun of boxes(bytes, traf.payload, traf.end).filter((b) => b.type === 'trun')) {
        const fl = dv.getUint32(trun.payload) & 0xffffff;
        const count = dv.getUint32(trun.payload + 4);
        let q = trun.payload + 8;
        let dataAt = baseOffset;
        if (fl & 0x1) {
          dataAt = baseOffset + dv.getInt32(q);
          q += 4;
        }
        if (fl & 0x4) q += 4;
        for (let i = 0; i < count; i++) {
          const duration = fl & 0x100 ? dv.getUint32(q) : defDuration;
          if (fl & 0x100) q += 4;
          const size = fl & 0x200 ? dv.getUint32(q) : defSize;
          if (fl & 0x200) q += 4;
          if (fl & 0x400) q += 4;
          const cto = fl & 0x800 ? dv.getInt32(q) : 0;
          if (fl & 0x800) q += 4;
          out.push({ time: time + cto, duration, data: bytes.subarray(dataAt, dataAt + size) });
          dataAt += size;
          time += duration;
        }
      }
    }
  }
  return out;
}

// Frases de un segmento MP4 de subtítulos; tiempos en segundos de la línea de tiempo del stream.
export function cuesFromMp4(info, bytes) {
  const cues = [];
  const utf8 = new TextDecoder();
  for (const s of samples(bytes)) {
    const start = s.time / info.timescale;
    const end = (s.time + s.duration) / info.timescale;
    if (info.codec === 'wvtt') {
      // Cada muestra: cajas vttc (frase: payl = texto) o vtte (nada en pantalla).
      for (const vttc of boxes(s.data).filter((b) => b.type === 'vttc')) {
        const payl = find(s.data, vttc, 'payl');
        const text = payl ? utf8.decode(s.data.subarray(payl.payload, payl.end)).trim() : '';
        if (text) cues.push({ start, end, text });
      }
    } else {
      // stpp: un documento TTML por muestra. Sus tiempos suelen ser de la línea de tiempo del stream;
      // si son relativos a la muestra (todos caben en su duración), se le suma su inicio.
      // Se mira en qué ventana caben las frases: [inicio, fin] de la muestra (tiempos absolutos) o
      // [0, duración] (relativos a la muestra, como los escribe ffmpeg).
      const ttml = parseTtml(utf8.decode(s.data));
      const fitsAbsolute = ttml.every((c) => c.start >= start - 0.5 && c.end <= end + 0.5);
      const fitsRelative = ttml.every((c) => c.end <= end - start + 0.5);
      const relative = ttml.length > 0 && !fitsAbsolute && fitsRelative;
      for (const c of ttml) cues.push(relative ? { ...c, start: c.start + start, end: c.end + start } : c);
    }
  }
  return cues;
}

// --- Inicio del video (para sincronizar) ------------------------------------------------------------

// Primer PTS (segundos) de un segmento MPEG-TS: el del video si lo hay, si no el del audio.
export function tsStartTime(bytes) {
  let audio = null;
  for (let at = 0; at + 188 <= bytes.length; at += 188) {
    if (bytes[at] !== 0x47 || !(bytes[at + 1] & 0x40)) continue;
    const afc = (bytes[at + 3] >> 4) & 0x3;
    let p = at + 4;
    if (afc === 2) continue;
    if (afc === 3) p += 1 + bytes[p];
    if (bytes[p] !== 0 || bytes[p + 1] !== 0 || bytes[p + 2] !== 1) continue;
    const id = bytes[p + 3];
    if (!(bytes[p + 7] & 0x80)) continue; // sin PTS
    const b = bytes.subarray(p + 9, p + 14);
    const pts = (b[0] & 0x0e) * 536870912 + b[1] * 4194304 + (b[2] & 0xfe) * 16384 + b[3] * 128 + (b[4] >> 1);
    if (id >= 0xe0 && id <= 0xef) return pts / 90000;
    if (id >= 0xc0 && id <= 0xdf && audio == null) audio = pts / 90000;
  }
  return audio;
}

// --- Unir y convertir ----------------------------------------------------------------------------

// Une las frases de todos los segmentos: quita las repetidas y junta las que un segmento cortó en dos.
export function mergeCues(cues) {
  const sorted = cues
    .filter((c) => Number.isFinite(c.start) && Number.isFinite(c.end) && c.end > c.start && c.text)
    .sort((a, b) => a.start - b.start || a.end - b.end);
  const out = [];
  for (const cue of sorted) {
    const same = out.findLast((c) => c.text === cue.text && cue.start <= c.end + 0.05 && cue.start >= c.start - 0.05);
    if (same) same.end = Math.max(same.end, cue.end);
    else out.push({ ...cue });
  }
  return out;
}

const pad = (n, w = 2) => String(n).padStart(w, '0');
function clockText(seconds, separator) {
  const ms = Math.max(0, Math.round(seconds * 1000));
  return `${pad(Math.floor(ms / 3600000))}:${pad(Math.floor(ms / 60000) % 60)}:${pad(Math.floor(ms / 1000) % 60)}${separator}${pad(ms % 1000, 3)}`;
}

// SRT: solo admite <i>, <b> y <u>; se quitan las demás etiquetas de WebVTT (<c.clase>, <v Nombre>…).
export function toSrt(cues) {
  return cues.map((c, i) => {
    const text = decode(c.text.replace(/<(?!\/?[ibu]>)[^>]+>/g, ''));
    return `${i + 1}\n${clockText(c.start, ',')} --> ${clockText(c.end, ',')}\n${text}\n`;
  }).join('\n');
}

export function toVtt(cues) {
  return `WEBVTT\n\n${cues.map((c) => `${clockText(c.start, '.')} --> ${clockText(c.end, '.')}\n${c.text}\n`).join('\n')}`;
}
