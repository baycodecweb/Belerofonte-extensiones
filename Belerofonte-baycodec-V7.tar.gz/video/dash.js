// Lector de manifiestos DASH (.mpd). Convierte cada calidad de video y cada pista de audio en una
// «lista de medios» con la misma forma que las de HLS (video/hls.js): { map, segments, duration… },
// para descargarlas con el mismo código (segmentos en paralelo y unión de video + audio en un MP4).
//
// Admite las tres formas de indicar los segmentos:
//   SegmentTemplate  media="seg-$Number%05d$.m4s" (con duration o con SegmentTimeline y $Time$)
//   SegmentList      una SegmentURL por segmento
//   SegmentBase      un único archivo por calidad; los trozos salen de su índice (caja sidx)
// Directos (type="dynamic"): el manifiesto se vuelve a pedir cada pocos segundos y cada lectura da
// los segmentos publicados hasta ese momento (con SegmentTimeline) o se calculan con la hora del
// servidor (SegmentTemplate con duración fija; ver clockOffset). No admite contenido con DRM.
//
// Funciona también en el service worker (no usa DOMParser): incluye un lector XML mínimo.

// --- XML mínimo -------------------------------------------------------------------------------

const ENTITIES = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" };
const decode = (s) => s.replace(/&(#x[0-9a-f]+|#\d+|\w+);/gi, (m, e) => {
  if (e[0] === '#') return String.fromCodePoint(e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : Number(e.slice(1)));
  return ENTITIES[e] ?? m;
});

// Árbol { name, attrs, children, text } sin espacios de nombres («cenc:pssh» → «pssh»).
function parseXml(xml) {
  const root = { name: '#root', attrs: {}, children: [], text: '' };
  const stack = [root];
  const re = /<!--[\s\S]*?-->|<!\[CDATA\[([\s\S]*?)\]\]>|<\?[\s\S]*?\?>|<!DOCTYPE[^>]*>|<\/\s*([\w:.-]+)\s*>|<([\w:.-]+)((?:\s+[\w:.-]+\s*=\s*(?:"[^"]*"|'[^']*'))*)\s*(\/?)>|([^<]+)/g;
  for (const m of xml.matchAll(re)) {
    const top = stack[stack.length - 1];
    if (m[1] != null) top.text += m[1];
    else if (m[2]) {
      if (stack.length > 1) stack.pop();
    } else if (m[3]) {
      const attrs = {};
      for (const a of m[4].matchAll(/([\w:.-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g)) {
        attrs[a[1].split(':').pop()] = decode(a[2] ?? a[3]);
      }
      const node = { name: m[3].split(':').pop(), attrs, children: [], text: '' };
      top.children.push(node);
      if (!m[5]) stack.push(node);
    } else if (m[6]) top.text += decode(m[6]);
  }
  return root;
}

const kids = (node, name) => (node?.children || []).filter((c) => c.name === name);
const kid = (node, name) => kids(node, name)[0] || null;

// --- Utilidades -------------------------------------------------------------------------------

// «PT1H2M3.5S» → segundos.
export function isoDuration(value) {
  const m = /^P(?:(\d+(?:\.\d+)?)D)?(?:T(?:(\d+(?:\.\d+)?)H)?(?:(\d+(?:\.\d+)?)M)?(?:(\d+(?:\.\d+)?)S)?)?$/.exec((value || '').trim());
  if (!m) return 0;
  const [, d, h, min, s] = m.map((x) => Number(x) || 0);
  return d * 86400 + h * 3600 + min * 60 + s;
}

const resolve = (uri, base) => new URL(uri, base).href;

// «0-1023» → { start: 0, end: 1023 }
function byteRange(value) {
  const m = /^(\d+)-(\d+)$/.exec((value || '').trim());
  return m ? { start: Number(m[1]), end: Number(m[2]) } : null;
}

// Sustituye $RepresentationID$, $Bandwidth$, $Number%05d$, $Time$ y $$.
function fill(template, values) {
  return template.replace(/\$(\w*)(?:%0(\d+)d)?\$/g, (all, key, width) => {
    if (key === '') return '$';
    const value = values[key];
    if (value == null) return all;
    return width ? String(value).padStart(Number(width), '0') : String(value);
  });
}

// BaseURL acumulada: MPD → Period → AdaptationSet → Representation.
function baseOf(node, parentBase) {
  const base = kid(node, 'BaseURL');
  return base?.text.trim() ? resolve(base.text.trim(), parentBase) : parentBase;
}

// Atributos de SegmentTemplate / SegmentBase / SegmentList heredados (los del nivel más bajo mandan).
function inherited(levels, name) {
  let merged = null;
  for (const level of levels) {
    const node = kid(level, name);
    if (!node) continue;
    merged = merged
      ? { ...merged, attrs: { ...merged.attrs, ...node.attrs }, children: node.children.length ? node.children : merged.children }
      : { ...node, attrs: { ...node.attrs } };
  }
  return merged;
}

const attr = (levels, key) => {
  for (let i = levels.length - 1; i >= 0; i--) if (levels[i].attrs[key] != null) return levels[i].attrs[key];
  return null;
};

// --- Manifiesto ---------------------------------------------------------------------------------

// Devuelve { type: 'master', dash: true, live, duration, encryption, variants, renditions } con la
// forma de una lista maestra de HLS. Cada variante o pista de audio lleva su `representation`, que
// dashMedia() convierte en lista de medios.
export function parseMpd(text, manifestUrl) {
  const root = parseXml(text);
  const mpd = kid(root, 'MPD');
  if (!mpd) throw new Error('No es un manifiesto DASH válido.');
  const live = mpd.attrs.type === 'dynamic';
  const mpdBase = baseOf(mpd, manifestUrl);
  const total = isoDuration(mpd.attrs.mediaPresentationDuration);

  // Con varios periodos (anuncios, capítulos) se usa el más largo: suele ser el contenido principal.
  // En directo, el último: es el que se está emitiendo.
  const periods = kids(mpd, 'Period').map((p, i, all) => {
    const start = isoDuration(p.attrs.start);
    const next = all[i + 1] ? isoDuration(all[i + 1].attrs.start) : null;
    const duration = isoDuration(p.attrs.duration) || (next != null ? next - start : total - start) || total;
    return { node: p, duration, start };
  });
  if (!periods.length) throw new Error('El manifiesto DASH no tiene ningún periodo.');
  const period = live ? periods[periods.length - 1] : periods.reduce((a, b) => (b.duration > a.duration ? b : a));
  // Datos del directo: cuándo empezó la emisión y cada cuánto se actualiza el manifiesto.
  const liveInfo = live ? {
    availabilityStart: Date.parse(mpd.attrs.availabilityStartTime || '') || 0,
    periodStart: period.start,
    updatePeriod: isoDuration(mpd.attrs.minimumUpdatePeriod) || 0,
  } : null;
  const periodBase = baseOf(period.node, mpdBase);

  const variants = [];
  const renditions = [];
  const subtitles = [];
  const encryption = new Set();
  for (const set of kids(period.node, 'AdaptationSet')) {
    const setBase = baseOf(set, periodBase);
    const protectedSet = kids(set, 'ContentProtection').length > 0;
    for (const rep of kids(set, 'Representation')) {
      const levels = [mpd, period.node, set, rep];
      const mime = attr([set, rep], 'mimeType') || '';
      // Tipo de pista: contentType, el mimeType o, si faltan, el códec (avc1, hev1, vp9, av01… son video).
      const codecGuess = /^(avc|hev|hvc|vp0?[89]|av01|dvh)/i.test(attr([set, rep], 'codecs') || '') ? 'video' : 'audio';
      const codecs = attr([set, rep], 'codecs') || '';
      // Subtítulos: archivo .vtt/.ttml, segmentos de texto o MP4 con wvtt (WebVTT) / stpp (TTML).
      const isText = set.attrs.contentType === 'text' || /^text\/vtt|ttml/i.test(mime) || /^(wvtt|stpp)/i.test(codecs);
      const type = isText ? 'text' : set.attrs.contentType || mime.split('/')[0] || codecGuess;
      if (type !== 'video' && type !== 'audio' && type !== 'text') continue; // imágenes (miniaturas)…
      if (protectedSet || kids(rep, 'ContentProtection').length) encryption.add('DRM (ContentProtection)');
      const representation = {
        id: rep.attrs.id || '',
        bandwidth: Number(rep.attrs.bandwidth) || 0,
        base: baseOf(rep, setBase),
        levels,
        periodDuration: period.duration,
        mime,
        live: liveInfo,
        // Para reconocer la misma calidad en el manifiesto actualizado del directo.
        key: `${type}|${rep.attrs.id || ''}|${rep.attrs.bandwidth || ''}`,
      };
      if (type === 'text') {
        const lang = (set.attrs.lang || rep.attrs.lang || '').replace(/^und$/i, '');
        const label = kid(set, 'Label')?.text.trim() || '';
        const role = kid(set, 'Role')?.attrs.value || '';
        subtitles.push({
          uri: `dash:s${subtitles.length}`,
          name: [label || lang || `Subtítulos ${subtitles.length + 1}`, role === 'caption' ? 'para sordos' : '', role === 'forced-subtitle' ? 'forzados' : ''].filter(Boolean).join(' · '),
          language: lang,
          representation,
        });
      } else if (type === 'video') {
        variants.push({
          uri: `dash:${variants.length}`,
          bandwidth: representation.bandwidth,
          width: Number(attr([set, rep], 'width')) || null,
          height: Number(attr([set, rep], 'height')) || null,
          codecs: attr([set, rep], 'codecs') || '',
          audio: 'dash-audio',
          mime,
          representation,
        });
      } else {
        const lang = (set.attrs.lang || rep.attrs.lang || '').replace(/^und$/i, ''); // «und»: sin definir
        const label = kid(set, 'Label')?.text.trim() || '';
        renditions.push({
          type: 'AUDIO',
          group: 'dash-audio',
          name: [label || lang || 'Audio', representation.bandwidth ? `${Math.round(representation.bandwidth / 1000)} kbps` : ''].filter(Boolean).join(' · '),
          language: lang,
          isDefault: false,
          uri: `dash:a${renditions.length}`,
          mime,
          representation,
        });
      }
    }
  }
  variants.sort((a, b) => (b.height || 0) - (a.height || 0) || b.bandwidth - a.bandwidth);
  // Audio por defecto: el de más calidad del idioma más común (o el primero).
  renditions.sort((a, b) => b.representation.bandwidth - a.representation.bandwidth);
  if (renditions.length) renditions[0].isDefault = true;
  // Solo audio (p. ej. un podcast): las pistas de audio hacen de «calidades».
  if (!variants.length) {
    variants.push(...renditions.map((r) => ({ ...r, uri: r.uri, height: null, width: null, codecs: '', audio: null })));
    renditions.length = 0;
  }
  const utcTiming = kids(mpd, 'UTCTiming').map((t) => ({ scheme: t.attrs.schemeIdUri || '', value: t.attrs.value || '' }));
  return {
    type: 'master', dash: true, live, duration: live ? 0 : period.duration || total, encryption: [...encryption], variants, renditions, subtitles,
    utcTiming, updatePeriod: liveInfo?.updatePeriod || 0,
  };
}

// Diferencia (ms) entre el reloj del servidor y el de este equipo. En los directos sin SegmentTimeline
// los segmentos disponibles se calculan con la hora: con el reloj desajustado se pedirían segmentos
// que aún no existen (o ya se borraron). Se usa UTCTiming del manifiesto o, si no hay, la cabecera Date.
export async function clockOffset(utcTiming = [], dateHeader = '') {
  for (const { scheme, value } of utcTiming) {
    try {
      let server = NaN;
      if (/direct/.test(scheme)) server = Date.parse(value);
      else if (/http-(iso|xsdate)/.test(scheme)) {
        server = Date.parse((await (await fetch(value, { cache: 'no-store' })).text()).trim());
      } else if (/http-head/.test(scheme)) {
        server = Date.parse((await fetch(value, { method: 'HEAD', cache: 'no-store' })).headers.get('date'));
      }
      if (Number.isFinite(server)) return server - Date.now();
    } catch { /* siguiente método */ }
  }
  const fromHeader = Date.parse(dateHeader || '');
  return Number.isFinite(fromHeader) ? fromHeader - Date.now() : 0;
}

// --- Segmentos de una calidad -------------------------------------------------------------------

// Lista de medios { type: 'media', map, segments, duration, encryption, live } de una representación.
// fetchRange(url, range) se usa solo con SegmentBase, para leer el índice (sidx).
// options.now: hora del servidor (ms) para los directos.
export async function dashMedia(representation, fetchRange, { now = Date.now() } = {}) {
  const { levels, base, id, bandwidth, periodDuration, live } = representation;
  const values = { RepresentationID: id, Bandwidth: bandwidth };
  const segments = [];
  let map = null;
  let presentationOffset = 0; // presentationTimeOffset en segundos (para sincronizar subtítulos)

  const template = inherited(levels.slice(1), 'SegmentTemplate');
  const list = inherited(levels.slice(1), 'SegmentList');
  const segBase = inherited(levels.slice(1), 'SegmentBase');

  if (template) {
    const a = template.attrs;
    const timescale = Number(a.timescale) || 1;
    const startNumber = a.startNumber != null ? Number(a.startNumber) : 1;
    if (a.initialization) map = { uri: resolve(fill(a.initialization, values), base), range: null };
    const timeline = kid(template, 'SegmentTimeline');
    const pto = Number(a.presentationTimeOffset) || 0;
    presentationOffset = pto / timescale;
    // Tiempo de emisión transcurrido (en la escala del manifiesto) hasta ahora, en directo.
    const elapsed = live ? Math.max(0, (now - live.availabilityStart) / 1000 - live.periodStart + (Number(a.availabilityTimeOffset) || 0)) : 0;
    if (timeline) {
      let time = 0;
      let number = startNumber;
      const entries = kids(timeline, 'S');
      const end = live ? elapsed * timescale + pto : periodDuration * timescale;
      entries.forEach((s, i) => {
        if (s.attrs.t != null) time = Number(s.attrs.t);
        const d = Number(s.attrs.d);
        let repeat = Number(s.attrs.r) || 0;
        if (repeat < 0) {
          // r=-1: se repite hasta el siguiente S o hasta el final del periodo.
          const until = entries[i + 1]?.attrs.t != null ? Number(entries[i + 1].attrs.t) : end;
          repeat = Math.max(0, Math.ceil((until - time) / d) - 1);
        }
        for (let k = 0; k <= repeat; k++) {
          // En directo el número puede reiniciarse al deslizar la ventana: el tiempo identifica el segmento.
          segments.push({ uri: resolve(fill(a.media, { ...values, Number: number, Time: time }), base), duration: d / timescale, range: null, sequence: live ? time : number });
          time += d;
          number++;
        }
      });
    } else if (a.duration && live) {
      // Directo sin lista de segmentos: el último publicado es el que terminó antes de «ahora».
      const segDuration = Number(a.duration) / timescale;
      const last = startNumber + Math.floor(elapsed / segDuration) - 1;
      for (let number = Math.max(startNumber, last - 2); number <= last; number++) {
        segments.push({
          uri: resolve(fill(a.media, { ...values, Number: number, Time: Math.round((number - startNumber) * Number(a.duration)) + pto }), base),
          duration: segDuration,
          range: null,
          sequence: number,
        });
      }
    } else if (a.duration) {
      const segDuration = Number(a.duration) / timescale;
      const count = Math.max(1, Math.ceil(periodDuration / segDuration - 1e-6));
      for (let k = 0; k < count; k++) {
        const number = startNumber + k;
        segments.push({
          uri: resolve(fill(a.media, { ...values, Number: number, Time: Math.round(k * Number(a.duration)) }), base),
          duration: Math.min(segDuration, periodDuration - k * segDuration),
          range: null,
          sequence: number,
        });
      }
    } else if (a.media) {
      segments.push({ uri: resolve(fill(a.media, { ...values, Number: startNumber, Time: 0 }), base), duration: periodDuration, range: null, sequence: 0 });
    }
  } else if (list) {
    const timescale = Number(list.attrs.timescale) || 1;
    const segDuration = list.attrs.duration ? Number(list.attrs.duration) / timescale : 0;
    const init = kid(list, 'Initialization');
    if (init) map = { uri: resolve(init.attrs.sourceURL || '', base), range: byteRange(init.attrs.range) };
    kids(list, 'SegmentURL').forEach((s, k) => {
      segments.push({ uri: resolve(s.attrs.media || '', base), range: byteRange(s.attrs.mediaRange), duration: segDuration, sequence: k });
    });
  } else {
    // SegmentBase (o nada): un único archivo. Con indexRange se lee el sidx para trocearlo y bajarlo en paralelo.
    const initRange = byteRange(kid(segBase, 'Initialization')?.attrs.range);
    const indexRange = byteRange(segBase?.attrs.indexRange);
    if (indexRange && fetchRange) {
      const sidx = await fetchRange(base, indexRange);
      const parsed = parseSidx(sidx, indexRange.end + 1);
      if (parsed.length) {
        map = { uri: base, range: initRange || { start: 0, end: indexRange.start - 1 } };
        segments.push(...parsed.map((s, k) => ({ uri: base, range: { start: s.start, end: s.end }, duration: s.duration, sequence: k })));
      }
    }
    if (!segments.length) segments.push({ uri: base, range: null, duration: periodDuration, sequence: 0 });
  }

  return {
    type: 'media',
    dash: true,
    presentationOffset,
    // Un solo archivo sin trocear (p. ej. subtítulos .vtt/.ttml enteros): sus tiempos son de presentación.
    sidecar: !map && segments.length === 1 && !segments[0].range,
    map,
    segments,
    duration: segments.reduce((sum, s) => sum + (s.duration || 0), 0) || periodDuration,
    encryption: [],
    live: !!live,
    targetDuration: Math.max(...segments.map((s) => s.duration || 0), 1),
  };
}

// Caja sidx: tamaños y duraciones de los trozos del archivo. first = byte donde empieza el primero
// (justo después del sidx, más first_offset).
function parseSidx(bytes, after) {
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let at = 0;
  // Puede venir precedida de otras cajas: se busca «sidx».
  while (at + 8 <= bytes.length && String.fromCharCode(...bytes.subarray(at + 4, at + 8)) !== 'sidx') {
    const size = dv.getUint32(at);
    if (size < 8) return [];
    at += size;
  }
  if (at + 8 > bytes.length) return [];
  const version = bytes[at + 8];
  let p = at + 12 + 4; // tamaño + tipo + versión/flags + reference_ID
  const timescale = dv.getUint32(p);
  p += 4;
  let firstOffset;
  if (version === 0) {
    p += 4; // earliest_presentation_time
    firstOffset = dv.getUint32(p);
    p += 4;
  } else {
    p += 8;
    firstOffset = Number(dv.getBigUint64(p));
    p += 8;
  }
  p += 2; // reservado
  const count = dv.getUint16(p);
  p += 2;
  const boxEnd = at + dv.getUint32(at);
  let start = after - (bytes.length - boxEnd) + firstOffset; // after = byte siguiente al rango leído
  const out = [];
  for (let i = 0; i < count; i++) {
    const ref = dv.getUint32(p);
    const duration = dv.getUint32(p + 4);
    p += 12;
    if (ref >>> 31) return []; // índice de índices: no admitido (se baja el archivo entero)
    const size = ref & 0x7fffffff;
    out.push({ start, end: start + size - 1, duration: duration / timescale });
    start += size;
  }
  return out;
}

// Resumen para la lista de videos de la extensión (como classify con HLS).
export function dashSummary(manifest) {
  return {
    playlist: 'master',
    dash: true,
    qualities: manifest.variants.length,
    maxHeight: Math.max(0, ...manifest.variants.map((v) => v.height || 0)) || null,
    encryption: manifest.encryption,
    live: manifest.live,
    duration: manifest.duration,
    subtitles: manifest.subtitles.map((s) => s.language || s.name),
  };
}
