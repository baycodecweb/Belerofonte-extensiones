// Descarga de un stream HLS: elige calidad, baja los segmentos en paralelo y los une en un MP4
// (video y audio juntos). Los streams en directo se graban hasta que el usuario pulsa "Detener y guardar".
// Si el stream está cifrado (AES-128, SAMPLE-AES o DRM) no se descarga.

import { fetchPlaylist, parsePlaylist } from './hls.js';
import { parseMpd, dashMedia, clockOffset } from './dash.js';
import { oembedInfo, cleanTitle } from './oembed.js';
import { transmux, mergeTracks, hasVideo, rebaseTime } from './mp4.js';
import { parseVtt, parseTtml, textTrackInfo, cuesFromMp4, tsStartTime, mergeCues, toSrt, toVtt } from './subtitles.js';

const PARALLEL = 6;
const RETRIES = 3;

const params = new URLSearchParams(location.search);
const sourceUrl = params.get('url');
const pageTitle = params.get('title') || '';
const referer = params.get('referer');
const sourceKind = params.get('kind'); // 'file' (mp4, webm…), 'ytdlp' (YouTube, Vimeo) o vacío (lista HLS)
// inline=1: lista HLS que el reproductor creó en memoria (blob:); su texto lo guardó el service worker.
const inline = params.get('inline') === '1';

async function inlineText() {
  const key = `inline:${sourceUrl}`;
  const stored = (await chrome.storage.session.get(key))[key];
  if (!stored) throw new Error('la lista ya no está disponible: vuelve a reproducir el video');
  return stored;
}

// DASH (kind=dash): el manifiesto .mpd se presenta como una lista maestra; cada calidad y cada pista de
// audio tiene una dirección «dash:…» que se convierte en lista de medios al elegirla (video/dash.js).
const dashReps = new Map();
const dashCache = new Map();
const fetchRange = (url, range) => fetchBytes(url, range, new AbortController().signal);
let dashClock = null; // diferencia con el reloj del servidor (directos)

async function readManifest() {
  if (inline) {
    const { text, base } = await inlineText();
    return { manifest: parseMpd(text, base), date: '' };
  }
  const response = await fetch(sourceUrl, { credentials: 'include', cache: 'no-store' });
  if (!response.ok) throw new Error(`El servidor respondió ${response.status} al pedir el manifiesto.`);
  return { manifest: parseMpd(await response.text(), response.url || sourceUrl), date: response.headers.get('date') || '' };
}

async function loadPlaylist(uri) {
  if (uri.startsWith('dash:')) {
    const rep = dashReps.get(uri);
    if (rep?.live) {
      // Directo: cada vez se lee el manifiesto actualizado y se busca la misma calidad en él.
      const { manifest } = await readManifest();
      const fresh = [...manifest.variants, ...manifest.renditions].find((v) => v.representation.key === rep.key)?.representation || rep;
      return dashMedia(fresh, fetchRange, { now: Date.now() + (dashClock || 0) });
    }
    if (!dashCache.has(uri)) dashCache.set(uri, dashMedia(rep, fetchRange));
    return dashCache.get(uri);
  }
  if (sourceKind === 'dash' && uri === sourceUrl) {
    const { manifest, date } = await readManifest();
    if (manifest.live && dashClock == null) dashClock = await clockOffset(manifest.utcTiming, date);
    for (const v of [...manifest.variants, ...manifest.renditions, ...(manifest.subtitles || [])]) dashReps.set(v.uri, v.representation);
    return manifest;
  }
  if (inline && uri === sourceUrl) {
    const { text, base } = await inlineText();
    return parsePlaylist(text, base);
  }
  return fetchPlaylist(uri);
}

const $ = (id) => document.getElementById(id);
const heading = $('heading');
const meta = $('meta');
const notice = $('notice');
const choose = $('choose');
const variantsEl = $('variants');
const audioRow = $('audio-row');
const audioSelect = $('audio');
const progress = $('progress');
const progressFill = $('progress-fill');
const progressText = $('progress-text');
const startBtn = $('start');
const stopBtn = $('stop');
const cancelBtn = $('cancel');
const result = $('result');
const filesEl = $('files');
const resultNote = $('result-note');

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const mb = (bytes) => `${(bytes / 1048576).toFixed(1)} MB`;
const clock = (seconds) => {
  const s = Math.round(seconds);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  return `${h ? `${h}:` : ''}${String(m).padStart(h ? 2 : 1, '0')}:${String(s % 60).padStart(2, '0')}`;
};
const mbps = (bps) => `${(bps / 1e6).toFixed(1)} Mbps`;

function showNotice(text) {
  notice.hidden = !text;
  notice.textContent = text;
}

function fail(text) {
  showNotice(text);
  meta.textContent = '';
  for (const el of [choose, progress, startBtn, stopBtn, cancelBtn]) el.hidden = true;
}

function baseName() {
  const raw = pageTitle || new URL(sourceUrl).pathname.split('/').pop().replace(/\.(m3u8|mpd)$/i, '') || 'video';
  return raw.replace(/[\\/:*?"<>|\u0000-\u001f]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 100) || 'video';
}

// --- Red ---------------------------------------------------------------------------------

async function fetchBytes(url, range, signal) {
  for (let attempt = 0; ; attempt++) {
    try {
      const response = await fetch(url, {
        credentials: 'include',
        signal,
        headers: range ? { Range: `bytes=${range.start}-${range.end}` } : {},
      });
      if (!response.ok) throw new Error(`el servidor respondió ${response.status}`);
      return new Uint8Array(await response.arrayBuffer());
    } catch (err) {
      if (signal.aborted || attempt >= RETRIES) throw err;
      await sleep(1000 * (attempt + 1));
    }
  }
}

// Tipo de archivo según los primeros bytes de los datos.
function detectContainer(bytes) {
  if (bytes[0] === 0x1a && bytes[1] === 0x45 && bytes[2] === 0xdf && bytes[3] === 0xa3) return { ext: 'webm', type: 'video/webm' };
  const tag = String.fromCharCode(...bytes.subarray(4, 8));
  if (['ftyp', 'styp', 'moof', 'sidx', 'moov'].includes(tag)) return { ext: 'mp4', type: 'video/mp4' };
  if (bytes[0] === 0x47) return { ext: 'ts', type: 'video/mp2t' };
  if (String.fromCharCode(...bytes.subarray(0, 3)) === 'ID3' || (bytes[0] === 0xff && (bytes[1] & 0xf0) === 0xf0)) {
    return { ext: 'aac', type: 'audio/aac' };
  }
  return { ext: 'ts', type: 'video/mp2t' };
}

// --- Descarga de una pista (video o audio) ---------------------------------------------

class Track {
  constructor(label, uri) {
    this.label = label;
    this.uri = uri;
    this.parts = [];
    this.bytes = 0;
    this.done = 0;
    this.total = 0;
    this.duration = 0;
  }

  async run(playlist, signal, stopSignal, onProgress) {
    if (playlist.map) {
      const init = await fetchBytes(playlist.map.uri, playlist.map.range, signal);
      this.init = init;
      this.bytes += init.length;
    }
    return playlist.live ? this.record(playlist, signal, stopSignal, onProgress) : this.download(playlist, signal, onProgress);
  }

  // Video bajo demanda: todos los segmentos, varios a la vez, en orden.
  async download(playlist, signal, onProgress) {
    const { segments } = playlist;
    this.total = segments.length;
    const parts = new Array(segments.length);
    let next = 0;
    const worker = async () => {
      while (next < segments.length) {
        const i = next++;
        parts[i] = await fetchBytes(segments[i].uri, segments[i].range, signal);
        this.bytes += parts[i].length;
        this.done++;
        this.duration += segments[i].duration;
        onProgress();
      }
    };
    await Promise.all(Array.from({ length: Math.min(PARALLEL, segments.length) }, worker));
    this.parts = parts;
  }

  // Directo: se vuelve a pedir la lista cada pocos segundos y se añaden los segmentos nuevos.
  async record(playlist, signal, stopSignal, onProgress) {
    const seen = new Set();
    let current = playlist;
    let last = null; // último segmento grabado: solo se bajan los posteriores
    // DASH puede publicar horas de directo hacia atrás (DVR): se empieza en el borde, como el reproductor.
    let first = playlist.dash ? playlist.segments.slice(-3) : playlist.segments;
    this.gaps = 0;
    while (!stopSignal.aborted) {
      for (const segment of first || current.segments) {
        if (seen.has(segment.sequence) || stopSignal.aborted) continue;
        if (last != null && segment.sequence <= last) continue;
        seen.add(segment.sequence);
        let bytes;
        try {
          bytes = await fetchBytes(segment.uri, segment.range, signal);
        } catch (err) {
          // En DASH un segmento puede no estar aún (o ya no) en el servidor: se salta y se sigue grabando.
          if (signal.aborted || !current.dash) throw err;
          this.gaps++;
          continue;
        }
        last = segment.sequence;
        this.parts.push(bytes);
        this.bytes += bytes.length;
        this.done++;
        this.duration += segment.duration;
        onProgress();
      }
      first = null;
      if (!current.live) break; // el directo terminó
      await Promise.race([sleep(Math.max(1, current.targetDuration / 2) * 1000), new Promise((r) => stopSignal.addEventListener('abort', r))]);
      if (stopSignal.aborted) break;
      current = await loadPlaylist(this.uri);
      if (current.encryption.length) throw new Error('el stream pasó a estar cifrado');
    }
  }

  chunks() {
    return this.init ? [this.init, ...this.parts] : this.parts;
  }

  container() {
    return detectContainer(this.chunks().find((p) => p?.length) || new Uint8Array(8));
  }

  // Trozos de un MP4 fragmentado ([init, ...fragmentos]); los MPEG-TS/AAC se remuxan con mux.js.
  async toMp4(onProgress) {
    if (this.container().ext === 'mp4') return this.chunks();
    // WebM (DASH de algunos sitios): no se puede pasar a MP4 sin recodificar; se guarda tal cual.
    if (this.container().ext === 'webm') throw new Error('las pistas son WebM');
    return transmux(this.parts, onProgress);
  }
}

// --- Flujo principal ----------------------------------------------------------------------

let master = null;

function renderChoices(playlist) {
  master = playlist;
  choose.hidden = false;
  variantsEl.replaceChildren(...playlist.variants.map((variant, i) => {
    const label = document.createElement('label');
    label.className = 'variant';
    const input = Object.assign(document.createElement('input'), { type: 'radio', name: 'variant', value: String(i), checked: i === 0 });
    const quality = document.createElement('b');
    quality.textContent = variant.height ? `${variant.height}p` : `Opción ${i + 1}`;
    const details = document.createElement('span');
    details.textContent = [variant.width && `${variant.width}×${variant.height}`, variant.bandwidth && mbps(variant.bandwidth), variant.codecs]
      .filter(Boolean).join(' · ');
    label.append(input, quality, details);
    return label;
  }));
  variantsEl.addEventListener('change', updateAudio);
  updateAudio();
  renderSubtitles(playlist);
}

// --- Subtítulos ----------------------------------------------------------------------------
// HLS: pistas #EXT-X-MEDIA:TYPE=SUBTITLES (WebVTT por segmentos o en MP4). DASH: pistas de texto
// (archivo .vtt/.ttml, segmentos de texto o MP4 con wvtt/stpp). Se marca la del idioma del navegador.

let subtitleTracks = [];
const subsRow = $('subs-row');
const subsOnlyBtn = $('subs-only');

function renderSubtitles(playlist) {
  subtitleTracks = playlist.dash
    ? playlist.subtitles || []
    : playlist.renditions.filter((r) => r.type === 'SUBTITLES' && r.uri);
  // En directo no se graban subtítulos (solo video y audio).
  const show = subtitleTracks.length > 0 && !playlist.live;
  subsRow.hidden = !show;
  subsOnlyBtn.hidden = !show;
  if (!show) return;
  const mine = (navigator.language || 'es').slice(0, 2).toLowerCase();
  $('subs-list').replaceChildren(...subtitleTracks.map((track, i) => {
    const label = document.createElement('label');
    const input = Object.assign(document.createElement('input'), { type: 'checkbox', value: String(i) });
    input.checked = (track.language || '').toLowerCase().startsWith(mine);
    label.append(input, track.name || track.language || `Subtítulos ${i + 1}`);
    if (track.language && track.name && !track.name.toLowerCase().includes(track.language.toLowerCase())) {
      label.append(Object.assign(document.createElement('span'), { className: 'muted', textContent: ` (${track.language})` }));
    }
    return label;
  }));
}

const selectedSubtitles = () => [...$('subs-list').querySelectorAll('input:checked')].map((i) => subtitleTracks[Number(i.value)]);

async function fetchAll(segments, signal, onDone = () => {}) {
  const out = new Array(segments.length);
  let next = 0;
  const worker = async () => {
    while (next < segments.length) {
      const i = next++;
      out[i] = await fetchBytes(segments[i].uri, segments[i].range, signal);
      onDone();
    }
  };
  await Promise.all(Array.from({ length: Math.min(PARALLEL, segments.length) }, worker));
  return out;
}

// Frases de una pista, con los tiempos del video guardado (que empieza en 0:00).
//   start:      instante del stream que corresponde al 0:00 del video guardado (segundos)
//   videoPto:   presentationTimeOffset del video (DASH), para los subtítulos con tiempos de presentación
async function buildSubtitles(track, { start, videoPto }, signal) {
  const playlist = await loadPlaylist(track.uri);
  const init = playlist.map ? await fetchBytes(playlist.map.uri, playlist.map.range, signal) : null;
  const info = init ? textTrackInfo(init) : null;
  const parts = await fetchAll(playlist.segments, signal);
  const utf8 = new TextDecoder();
  const cues = [];
  const shift = (list, by) => list.forEach((c) => cues.push({ ...c, start: c.start + by, end: c.end + by }));
  for (const bytes of parts) {
    const head = utf8.decode(bytes.subarray(0, 64)).replace(/^\uFEFF/, '').trimStart();
    if (head.startsWith('WEBVTT')) {
      const { cues: list, map } = parseVtt(utf8.decode(bytes));
      if (playlist.dash) shift(list, videoPto - start);
      // HLS: X-TIMESTAMP-MAP dice qué instante del video (MPEGTS) corresponde al tiempo LOCAL de las frases.
      else shift(list, map ? map.mpegts - map.local - start : 0);
    } else if (head.startsWith('<')) {
      shift(parseTtml(utf8.decode(bytes)), playlist.dash ? videoPto - start : 0);
    } else {
      // MP4 (wvtt/stpp): tiempos de la línea de tiempo del stream. Sin segmento de inicio aparte, el
      // archivo entero (con su moov) hace de inicio.
      const mp4 = info || textTrackInfo(bytes);
      if (mp4) shift(cuesFromMp4(mp4, bytes), (playlist.dash ? videoPto - (playlist.presentationOffset || 0) : 0) - start);
    }
  }
  return mergeCues(cues);
}

// Guarda los subtítulos elegidos junto al video: «Nombre.es.srt».
async function saveSubtitles(tracks, timing, fileBase, signal) {
  const format = $('subs-format').value;
  const used = new Set();
  const results = [];
  for (const [i, track] of tracks.entries()) {
    progressText.textContent = `Descargando subtítulos ${track.name || track.language || i + 1}…`;
    try {
      const cues = await buildSubtitles(track, timing, signal);
      if (!cues.length) {
        results.push(`${track.name || track.language}: sin frases`);
        continue;
      }
      let tag = (track.language || `sub${i + 1}`).replace(/[^\w-]+/g, '');
      while (used.has(tag)) tag += `-${i + 1}`;
      used.add(tag);
      const text = format === 'vtt' ? toVtt(cues) : toSrt(cues);
      // Tipo genérico: con text/plain el navegador cambiaría la extensión .srt/.vtt por .txt.
      const { li } = await saveBlob(new Blob([text], { type: 'application/octet-stream' }), `${fileBase}.${tag}.${format}`);
      filesEl.append(li);
      results.push(`${track.name || track.language}: ${cues.length} frases`);
    } catch (err) {
      if (signal.aborted) throw err;
      results.push(`${track.name || track.language}: no se pudieron descargar (${err.message})`);
    }
  }
  return results;
}

// Solo los subtítulos: se mira el primer segmento del video elegido para sincronizarlos igual que si
// se hubiera descargado el video.
subsOnlyBtn.addEventListener('click', async () => {
  const tracks = selectedSubtitles();
  if (!tracks.length) return showNotice('Marca al menos un idioma de subtítulos.');
  const variant = selectedVariant();
  const qualityTag = variant?.height ? `-${variant.height}p` : '';
  startBtn.hidden = true;
  subsOnlyBtn.hidden = true;
  showNotice('');
  progress.hidden = false;
  const abort = new AbortController();
  cancelBtn.hidden = false;
  cancelBtn.onclick = () => abort.abort();
  try {
    progressText.textContent = 'Sincronizando con el video…';
    const timing = await streamStart(variant.uri, abort.signal);
    filesEl.replaceChildren();
    const results = await saveSubtitles(tracks, timing, `${baseName()}${qualityTag}`, abort.signal);
    cancelBtn.hidden = true;
    progressFill.style.width = '100%';
    progressText.textContent = 'Listo';
    resultNote.textContent = results.join(' · ');
    result.hidden = false;
    startBtn.hidden = false;
  } catch (err) {
    if (abort.signal.aborted) return fail('Descarga cancelada.');
    fail(`No se pudieron descargar los subtítulos (${err.message}).`);
  }
});

// Instante del stream que será el 0:00 del video guardado, leyendo solo su primer segmento.
async function streamStart(videoUri, signal) {
  const playlist = await loadPlaylist(videoUri);
  const first = playlist.segments[0];
  const bytes = first ? await fetchBytes(first.uri, first.range, signal) : new Uint8Array();
  const videoPto = playlist.presentationOffset || 0;
  if (bytes[0] === 0x47) return { start: tsStartTime(bytes) ?? 0, videoPto };
  const init = playlist.map ? await fetchBytes(playlist.map.uri, playlist.map.range, signal) : null;
  return { start: init ? rebaseTime([init, bytes.slice()]) : 0, videoPto };
}

// Pistas de audio separadas del video (grupo AUDIO de la variante elegida).
function updateAudio() {
  const variant = selectedVariant();
  const options = master.renditions.filter((r) => r.type === 'AUDIO' && r.group === variant.audio && r.uri);
  audioRow.hidden = !options.length;
  audioSelect.replaceChildren(...options.map((r) => {
    const option = Object.assign(document.createElement('option'), { value: r.uri, textContent: r.name || r.language || 'Audio' });
    option.selected = r.isDefault;
    return option;
  }));
}

const selectedVariant = () => master.variants[Number(variantsEl.querySelector('input:checked')?.value || 0)];

async function start() {
  const variant = master ? selectedVariant() : null;
  const videoUri = variant ? variant.uri : sourceUrl;
  const audioUri = master && !audioRow.hidden ? audioSelect.value : null;
  const qualityTag = variant?.height ? `-${variant.height}p` : '';

  startBtn.hidden = true;
  subsOnlyBtn.hidden = true;
  choose.querySelectorAll('input, select').forEach((el) => (el.disabled = true));
  showNotice('');
  meta.textContent = 'Preparando…';

  const abort = new AbortController();
  const stop = new AbortController();
  cancelBtn.hidden = false;
  cancelBtn.onclick = () => abort.abort();

  try {
    const tracks = [new Track('Video', videoUri)];
    if (audioUri) tracks.push(new Track('Audio', audioUri));
    const playlists = await Promise.all(tracks.map((t) => loadPlaylist(t.uri)));

    const encrypted = playlists.flatMap((p) => p.encryption);
    if (encrypted.length) {
      return fail(`Este video está protegido (cifrado ${[...new Set(encrypted)].join(', ')}). No se puede descargar.`);
    }

    const live = playlists.some((p) => p.live);
    if (live) {
      stopBtn.hidden = false;
      stopBtn.onclick = () => stop.abort();
      progressFill.classList.add('live');
      heading.textContent = '⏺ Grabando directo';
    }
    progress.hidden = false;

    const started = performance.now();
    const totalDuration = Math.max(...playlists.map((p) => p.duration));
    const onProgress = () => {
      const bytes = tracks.reduce((sum, t) => sum + t.bytes, 0);
      const seconds = (performance.now() - started) / 1000;
      const speed = bytes / Math.max(seconds, 0.1);
      if (live) {
        const gaps = tracks.reduce((sum, t) => sum + (t.gaps || 0), 0);
        progressText.textContent = `Grabado ${clock(tracks[0].duration)} · ${mb(bytes)} · ${mb(speed)}/s` +
          (gaps ? ` · ${gaps} ${gaps === 1 ? 'segmento no disponible' : 'segmentos no disponibles'} (saltados)` : '');
        return;
      }
      const done = tracks.reduce((sum, t) => sum + t.done, 0);
      const total = tracks.reduce((sum, t) => sum + t.total, 0) || 1;
      const ratio = done / total;
      progressFill.style.width = `${(ratio * 100).toFixed(1)}%`;
      const eta = ratio > 0 ? seconds / ratio - seconds : 0;
      progressText.textContent = `${Math.round(ratio * 100)} % · segmento ${done} de ${total} · ${mb(bytes)} · ` +
        `${mb(speed)}/s${ratio > 0 && ratio < 1 ? ` · quedan ${clock(eta)}` : ''}`;
    };
    meta.textContent = live
      ? 'Directo: se graba desde ahora hasta que pulses «Detener y guardar».'
      : `Duración ${clock(totalDuration)} · ${playlists[0].segments.length} segmentos`;
    onProgress();

    await Promise.all(tracks.map((t, i) => t.run(playlists[i], abort.signal, stop.signal, onProgress)));

    stopBtn.hidden = true;
    progressFill.classList.remove('live');
    progressFill.style.width = '100%';
    const subs = live ? [] : selectedSubtitles();
    await save(tracks, qualityTag, live, subs, abort.signal, playlists[0].presentationOffset || 0);
    cancelBtn.hidden = true;
  } catch (err) {
    if (abort.signal.aborted) return fail('Descarga cancelada.');
    fail(`No se pudo descargar el video (${err.message}).`);
  }
}

// Intenta guardar un único MP4 (video + audio). Si no se puede, guarda cada pista en su formato original.
// Devuelve también `start`: el instante del stream que corresponde al 0:00 del archivo guardado
// (para sincronizar los subtítulos). Con subtítulos o en directo, el MP4 se pone a empezar en 0:00.
async function buildFiles(tracks, live = false, withSubs = false) {
  try {
    const converted = [];
    for (const track of tracks) {
      converted.push(await track.toMp4((done, total) => {
        progressText.textContent = `Convirtiendo ${track.label.toLowerCase()} a MP4… ${Math.round((done / total) * 100)} %`;
      }));
    }
    const chunks = converted.length > 1 ? mergeTracks(converted[0], converted[1]) : converted[0];
    // MPEG-TS: mux.js ya pone el video a empezar en 0:00 (desde su primer instante, el PTS).
    const fromTs = tracks[0].container().ext === 'ts';
    let start = fromTs ? tsStartTime(tracks[0].parts[0] || new Uint8Array()) ?? 0 : 0;
    if (live || withSubs) start += rebaseTime(chunks);
    const video = hasVideo(chunks.find((c) => c.length && String.fromCharCode(...c.subarray(4, 8)) === 'moov') || converted[0][0]);
    return {
      files: [{ blob: new Blob(chunks, { type: video ? 'video/mp4' : 'audio/mp4' }), ext: video ? 'mp4' : 'm4a', suffix: '' }],
      note: '',
      start,
    };
  } catch (err) {
    console.warn('No se pudo convertir a MP4:', err);
    const files = tracks.map((track) => {
      const { ext, type } = track.container();
      return { blob: new Blob(track.chunks(), { type }), ext, suffix: tracks.length > 1 ? `-${track.label.toLowerCase()}` : '' };
    });
    const notes = [`No se pudo convertir a MP4 (${err.message}); se guardó el formato original.`];
    if (files.some((f) => f.ext === 'ts')) {
      notes.push('El .ts se reproduce en VLC o mpv. Para pasarlo a MP4 sin perder calidad: ffmpeg -i video.ts -c copy video.mp4');
    }
    if (files.length > 1) notes.push('Para unir video y audio: ffmpeg -i video.ts -i audio.aac -c copy video.mp4');
    const first = tracks[0].parts[0];
    return { files, note: notes.join(' '), start: first?.[0] === 0x47 ? tsStartTime(first) ?? 0 : 0 };
  }
}

// Guarda el archivo con el gestor de descargas del navegador: así «Mostrar en la carpeta» abre la
// carpeta con el archivo ya seleccionado. Si no se puede, queda el enlace de descarga de siempre.
function smallButton(text, onClick) {
  const b = Object.assign(document.createElement('button'), { className: 'btn btn--small', textContent: text });
  b.addEventListener('click', onClick);
  return b;
}

async function saveBlob(blob, fileName) {
  const url = URL.createObjectURL(blob);
  const link = Object.assign(document.createElement('a'), { href: url, download: fileName, textContent: `⬇ ${fileName} (${mb(blob.size)})` });
  const li = document.createElement('li');
  li.append(link);
  try {
    const id = await chrome.downloads.download({ url, filename: fileName, conflictAction: 'uniquify', saveAs: false });
    const actions = document.createElement('span');
    actions.className = 'file-actions';
    actions.append(
      smallButton('▶ Abrir', () => chrome.downloads.open(id).catch(() => {})),
      smallButton('🗂 Mostrar en la carpeta', () => chrome.downloads.show(id)),
    );
    li.append(actions);
    return { li, id };
  } catch {
    link.click();
    return { li, id: null };
  }
}

async function save(tracks, qualityTag, live = false, subs = [], signal = new AbortController().signal, videoPto = 0) {
  const name = baseName();
  const { files, note, start } = await buildFiles(tracks, live, subs.length > 0);
  const saved = [];
  for (const { blob, ext, suffix } of files) saved.push(await saveBlob(blob, `${name}${qualityTag}${suffix}.${ext}`));
  filesEl.replaceChildren(...saved.map((s) => s.li));
  record({
    kind: 'hls',
    name: files.map(({ ext, suffix }) => `${name}${qualityTag}${suffix}.${ext}`).join(' + '),
    size: files.reduce((sum, f) => sum + f.blob.size, 0),
    downloadId: saved[0]?.id ?? null,
  });

  const subResults = subs.length ? await saveSubtitles(subs, { start, videoPto }, `${name}${qualityTag}`, signal) : [];

  progressText.textContent = `Listo · ${files.map((f) => f.ext.toUpperCase()).join(' + ')} · ${mb(files.reduce((sum, f) => sum + f.blob.size, 0))}` +
    (subResults.length ? ` · subtítulos: ${subResults.join(', ')}` : '');
  resultNote.textContent = note;
  result.hidden = false;
  heading.textContent = 'Video descargado';
  meta.textContent = 'Si la descarga no empezó sola, usa los enlaces de abajo.';
}

// Apunta la descarga terminada en el historial del gestor de descargas.
function record(entry) {
  chrome.runtime.sendMessage({ type: 'dm-record', entry: { ...entry, url: sourceUrl, pageUrl: referer || '' } }).catch(() => {});
}

// --- Archivo directo (mp4, webm…) --------------------------------------------------------
// Se usa cuando el gestor de descargas del navegador recibe un 403: desde aquí la petición lleva
// el Referer de la página del video.

const EXT_BY_TYPE = { 'video/mp4': 'mp4', 'video/webm': 'webm', 'video/quicktime': 'mov', 'audio/mpeg': 'mp3', 'audio/mp4': 'm4a', 'audio/ogg': 'ogg' };

function directFileName(response) {
  const disposition = response.headers.get('content-disposition') || '';
  const fromHeader = disposition.match(/filename\*=UTF-8''([^;]+)|filename="?([^";]+)"?/i);
  if (fromHeader) return decodeURIComponent(fromHeader[1] || fromHeader[2]);
  let fromUrl = '';
  try {
    fromUrl = decodeURIComponent(new URL(sourceUrl).pathname.split('/').filter(Boolean).pop() || '');
  } catch {}
  if (/\.\w{2,4}$/.test(fromUrl)) return fromUrl;
  // Enlaces sin nombre de archivo (p. ej. los de OK.ru o con token): el título y la extensión del tipo.
  const type = (response.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
  return `${baseName()}.${EXT_BY_TYPE[type] || 'mp4'}`;
}

async function downloadDirect() {
  const abort = new AbortController();
  cancelBtn.hidden = false;
  cancelBtn.onclick = () => abort.abort();
  progress.hidden = false;
  meta.textContent = 'Descargando con el Referer de la página del video…';

  try {
    const response = await fetch(sourceUrl, { credentials: 'include', signal: abort.signal });
    if (response.status === 403 || response.status === 410) {
      return fail(`El servidor rechazó la descarga (${response.status}). Lo más probable es que el enlace haya caducado: ` +
        'recarga la página del video y vuelve a descargarlo (o copia el enlace nuevo).');
    }
    if (!response.ok) return fail(`El servidor respondió ${response.status}.`);

    const name = directFileName(response);
    heading.textContent = name;
    const total = Number(response.headers.get('content-length')) || 0;
    const reader = response.body.getReader();
    const chunks = [];
    let bytes = 0;
    const started = performance.now();
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(value);
      bytes += value.length;
      const seconds = (performance.now() - started) / 1000;
      const speed = bytes / Math.max(seconds, 0.1);
      if (total) {
        const ratio = bytes / total;
        progressFill.style.width = `${(ratio * 100).toFixed(1)}%`;
        progressText.textContent = `${Math.round(ratio * 100)} % · ${mb(bytes)} de ${mb(total)} · ${mb(speed)}/s` +
          (ratio < 1 ? ` · quedan ${clock((total - bytes) / speed)}` : '');
      } else {
        progressText.textContent = `${mb(bytes)} · ${mb(speed)}/s`;
      }
    }

    const blob = new Blob(chunks, { type: response.headers.get('content-type') || 'video/mp4' });
    cancelBtn.hidden = true;
    progressFill.style.width = '100%';
    progressText.textContent = `Listo · ${mb(blob.size)}`;
    const { li } = await saveBlob(blob, name.replace(/[\\/:*?"<>|\u0000-\u001f]+/g, ' ').trim() || 'video.mp4');
    filesEl.replaceChildren(li);
    resultNote.textContent = '';
    result.hidden = false;
    heading.textContent = 'Video descargado';
    meta.textContent = 'Si la descarga no empezó sola, usa el enlace de abajo.';
  } catch (err) {
    if (abort.signal.aborted) return fail('Descarga cancelada.');
    fail(`No se pudo descargar el video (${err.message}).`);
  }
}

// --- YouTube y Vimeo con yt-dlp ----------------------------------------------------------------
// La extensión arranca yt-dlp a través del conector nativo (native/belerofonte_ytdlp.py), que se
// registra una sola vez con native/instalar.sh (Linux) o native\instalar.bat (Windows). El archivo se
// guarda en la carpeta de descargas.
const NATIVE_HOST = 'com.baycodec.belerofonte_ytdlp';
const IS_WINDOWS = /Windows/i.test(navigator.userAgent);
const INSTALL_CMD = IS_WINDOWS
  ? 'descarga el instalador con el botón de abajo y ábrelo (instala yt-dlp, ffmpeg y lo demás que haga falta)'
  : 'en una terminal, dentro de la carpeta de la extensión: ./native/instalar.sh';
const INSTALL_HINT = `Falta instalar el conector de yt-dlp (solo una vez): ${INSTALL_CMD}.` +
  (IS_WINDOWS ? '' : ' Luego recarga la extensión.');

// --- Instalador para Windows -------------------------------------------------------------------
// Un solo .bat que lleva dentro el conector (belerofonte_ytdlp.py) y su instalador (instalar.ps1),
// leídos de la propia extensión. Al abrirlo los copia a %LOCALAPPDATA%\Belerofonte-Baycodec\native y
// ejecuta el instalador con el ID de esta extensión, así que no hace falta buscar la carpeta native.
const toBase64 = (buffer) => {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(binary);
};

async function buildInstaller() {
  const read = async (path) => toBase64(await (await fetch(chrome.runtime.getURL(path))).arrayBuffer());
  const [hostPy, installPs1] = await Promise.all([read('native/belerofonte_ytdlp.py'), read('native/instalar.ps1')]);
  const id = chrome.runtime.id;
  // cmd solo lee hasta «exit /b»; PowerShell busca la marca y ejecuta lo que hay detrás.
  const lines = [
    '@echo off',
    'rem Instalador del conector de descargas de Belerofonte-Baycodec (yt-dlp, ffmpeg, Deno).',
    `rem Generado por la extension ${id}. Instala en %LOCALAPPDATA%\\Belerofonte-Baycodec, sin administrador.`,
    'set "BELEROFONTE_SELF=%~f0"',
    'powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$t = [IO.File]::ReadAllText($env:BELEROFONTE_SELF);' +
      " $i = $t.IndexOf('#BELEROFONTE' + '-PAYLOAD'); Invoke-Expression $t.Substring($i)\"",
    'echo.',
    'pause',
    'exit /b',
    '#BELEROFONTE-PAYLOAD',
    "$ErrorActionPreference = 'Stop'",
    "$dir = Join-Path $env:LOCALAPPDATA 'Belerofonte-Baycodec\\native'",
    'New-Item -ItemType Directory -Force -Path $dir | Out-Null',
    `[IO.File]::WriteAllBytes((Join-Path $dir 'belerofonte_ytdlp.py'), [Convert]::FromBase64String('${hostPy}'))`,
    `[IO.File]::WriteAllBytes((Join-Path $dir 'instalar.ps1'), [Convert]::FromBase64String('${installPs1}'))`,
    `& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $dir 'instalar.ps1') -Id '${id}'`,
    '',
  ];
  return new Blob([lines.join('\r\n')], { type: 'application/octet-stream' });
}

function showInstaller() {
  if (!IS_WINDOWS) return;
  $('installer').hidden = false;
  const note = $('installer-note');
  $('get-installer').onclick = async () => {
    try {
      const url = URL.createObjectURL(await buildInstaller());
      const link = Object.assign(document.createElement('a'), { href: url, download: 'instalar-belerofonte.bat' });
      document.body.append(link);
      link.click();
      link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 60_000);
      note.textContent = 'Instalador descargado: ábrelo desde la barra de descargas del navegador o tu carpeta Descargas.';
    } catch (err) {
      note.textContent = `No se pudo preparar el instalador (${err.message}).`;
    }
  };
  $('retry').onclick = () => location.reload();
}

// Errores de yt-dlp que tienen una explicación concreta.
function ytdlpError(message) {
  if (/DRM/i.test(message)) return 'Este video está protegido con DRM: no se puede descargar.';
  // Vimeo bloquea a veces las conexiones que no vienen de un navegador ("couldn't verify the security
  // of your connection"), aunque el video sea público.
  if (/vimeo/i.test(message) && /HTTP Error 40[13]/i.test(message)) {
    return 'Vimeo no deja que yt-dlp acceda a este video (bloquea las conexiones que no vienen de un navegador). ' +
      'Alternativa: abre el video en su pestaña, reprodúcelo unos segundos y vuelve a abrir el popup: ' +
      'en «Videos de la página» aparecerá su stream para descargarlo desde el navegador (si no tiene DRM).';
  }
  // TikTok rechaza a los clientes que no se parecen a un navegador: yt-dlp necesita curl_cffi para
  // imitarlo. Con curl_cffi, el mismo error indica que el video está bloqueado en tu país.
  if (/tiktok/i.test(message) && /IP address is blocked|impersonat/i.test(message)) {
    return 'TikTok no deja que yt-dlp acceda a este video. Si pasa con todos los videos de TikTok, falta curl_cffi en el ' +
      `conector: ${INSTALL_CMD} y recarga la extensión. Si solo pasa con este, el video no está disponible en tu país.`;
  }
  if (/instagram/i.test(message) && /empty media response|login required|rate-limit|not granting access|cookies/i.test(message)) {
    return 'Instagram solo deja ver este video con la sesión iniciada. Entra en instagram.com en este navegador ' +
      '(la extensión le pasa a yt-dlp tu sesión) y vuelve a descargarlo. Si ya la tenías iniciada, puede que la ' +
      'publicación sea privada o que Instagram esté limitando las peticiones: espera unos minutos.';
  }
  if (/facebook/i.test(message) && /login|log in|registered users|Cannot parse data|No video formats found/i.test(message)) {
    return 'Facebook no muestra este video sin la sesión iniciada (o la publicación no tiene video). Entra en facebook.com ' +
      'en este navegador (la extensión le pasa a yt-dlp tu sesión) y vuelve a descargarlo. Si ya la tenías iniciada, puede ' +
      'que el video sea privado o que Facebook esté limitando las peticiones: espera unos minutos.';
  }
  if (/HTTP Error 40[13]|logged-in|private|password/i.test(message)) {
    return 'Este video es privado o solo se puede ver desde la web que lo inserta. ' +
      'Abre esa web y descárgalo desde el popup (sección Videos de la página).';
  }
  if (/HTTP Error 404|No video formats found/i.test(message)) return 'El video no existe o ya no está disponible.';
  return `yt-dlp no pudo descargar el video: ${message}`;
}

function downloadYtdlp() {
  const soloAudio = params.get('audio') === '1';
  const subtitulos = params.get('subs') === '1';
  const calidad = params.get('calidad') || (soloAudio ? '192' : 'mejor');
  const options = soloAudio
    ? `Solo audio MP3 · ${calidad} kbps`
    : `Video ${calidad === 'mejor' ? 'en la mejor calidad' : `hasta ${calidad}p`}${subtitulos ? ' · con subtítulos' : ''}`;
  const site = params.get('site') || 'YouTube';
  // Título del video: el de la pestaña si se descargó desde ella; si no (enlace pegado, vista previa…),
  // se pide al momento con oEmbed, y yt-dlp lo confirma en cuanto lee el video.
  let videoTitle = cleanTitle(pageTitle);
  const showTitle = (title) => {
    if (!title) return;
    videoTitle = cleanTitle(title);
    heading.textContent = videoTitle;
    document.title = `${videoTitle} · Descargar`;
  };
  heading.textContent = videoTitle || `Video de ${site}`;
  if (videoTitle) showTitle(videoTitle);
  else oembedInfo(sourceUrl, site).then((info) => !videoTitle && info && showTitle(info.title));
  meta.textContent = `${options} · yt-dlp`;
  progress.hidden = false;
  progressText.textContent = 'Arrancando yt-dlp…';

  let port;
  try {
    port = chrome.runtime.connectNative(NATIVE_HOST);
  } catch {
    fail(INSTALL_HINT);
    return showInstaller();
  }
  let finished = false;
  cancelBtn.hidden = false;
  cancelBtn.onclick = () => {
    finished = true;
    port.disconnect(); // el conector borra el archivo a medias y termina
    fail('Descarga cancelada.');
  };

  port.onDisconnect.addListener(() => {
    if (finished) return;
    const error = chrome.runtime.lastError?.message || '';
    if (/not found|forbidden/i.test(error)) {
      fail(INSTALL_HINT);
      showInstaller();
    } else {
      fail(`El conector de yt-dlp se cerró inesperadamente${error ? ` (${error})` : ''}.`);
    }
  });

  port.onMessage.addListener((message) => {
    if (message.type === 'progress') {
      if (message.titulo && message.titulo !== videoTitle) showTitle(message.titulo);
      progressFill.style.width = `${message.porcentaje || 0}%`;
      progressText.textContent = message.mensaje ||
        `${message.porcentaje || 0} %${message.total ? ` · ${mb(message.descargado)} de ${mb(message.total)}` : ''}` +
        `${message.velocidad ? ` · ${message.velocidad}` : ''}`;
    } else if (message.type === 'error') {
      finished = true;
      port.disconnect();
      fail(ytdlpError(message.mensaje));
    } else if (message.type === 'done') {
      finished = true;
      port.disconnect();
      cancelBtn.hidden = true;
      progressFill.style.width = '100%';
      progressText.textContent = `Listo${message.tamano ? ` · ${mb(message.tamano)}` : ''}`;

      const open = Object.assign(document.createElement('button'), { className: 'btn', textContent: '🗂 Mostrar en la carpeta', title: 'Abre la carpeta con el archivo seleccionado' });
      open.addEventListener('click', () => chrome.runtime.sendNativeMessage(NATIVE_HOST, { action: 'reveal', path: message.ruta }));
      const li = document.createElement('li');
      li.append(`${message.archivo} `, open);
      filesEl.replaceChildren(li);
      resultNote.textContent = `Guardado en ${message.ruta}`;
      record({ kind: 'ytdlp', name: message.archivo, size: message.tamano, path: message.ruta });
      result.hidden = false;
      showTitle(message.titulo || videoTitle);
      if (!videoTitle) heading.textContent = soloAudio ? 'Audio descargado' : 'Video descargado';
      meta.textContent = `✓ ${soloAudio ? 'Audio descargado' : 'Video descargado'} · ${options}`;
    }
  });

  siteCookies(params.get('site')).then((cookies) => {
    if (!finished) port.postMessage({ action: 'download', url: sourceUrl, solo_audio: soloAudio, calidad, subtitulos, referer, cookies });
  });
}

// Instagram (casi siempre) y Facebook (videos privados y de grupos) exigen la sesión iniciada: se pasan
// a yt-dlp las cookies de ese sitio (solo las suyas, y solo al conector local, que las borra al terminar).
const COOKIE_DOMAINS = { Instagram: 'instagram.com', Facebook: 'facebook.com' };

async function siteCookies(site) {
  const domain = COOKIE_DOMAINS[site];
  if (!domain) return [];
  try {
    const list = await chrome.cookies.getAll({ domain });
    return list.map(({ domain, hostOnly, path, secure, expirationDate, name, value }) =>
      ({ domain, hostOnly, path, secure, expirationDate, name, value }));
  } catch {
    return [];
  }
}

async function init() {
  if (!sourceUrl) return fail('Falta la dirección del video.');
  heading.textContent = baseName();
  try {
    // Las peticiones de esta pestaña llevarán el Referer de la web del video (algunos servidores lo exigen).
    if (referer) await chrome.runtime.sendMessage({ type: 'media-referer', referer });
    if (sourceKind === 'file') return downloadDirect();
    if (sourceKind === 'ytdlp') return downloadYtdlp();
    const playlist = await loadPlaylist(sourceUrl);
    if (playlist.type === 'master') {
      if (playlist.encryption?.length) return fail(`Este video está protegido (${playlist.encryption.join(', ')}). No se puede descargar.`);
      if (!playlist.variants.length) return fail('La lista no contiene ninguna calidad descargable.');
      renderChoices(playlist);
      meta.textContent = playlist.variants.length === 1 ? '1 calidad disponible' : `${playlist.variants.length} calidades disponibles`;
    } else {
      if (playlist.encryption.length) return fail(`Este video está protegido (cifrado ${playlist.encryption.join(', ')}). No se puede descargar.`);
      meta.textContent = playlist.live ? 'Directo' : `Duración ${clock(playlist.duration)} · ${playlist.segments.length} segmentos`;
    }
    const live = playlist.live && (playlist.type === 'media' || playlist.dash);
    if (live && playlist.dash) meta.textContent = `🔴 Directo DASH · ${meta.textContent}`;
    startBtn.textContent = live ? '⏺ Grabar directo' : '⬇ Descargar';
    startBtn.hidden = false;
    startBtn.onclick = start;
  } catch (err) {
    fail(`No se pudo leer la lista del video (${err.message}).`);
  }
}

init();
