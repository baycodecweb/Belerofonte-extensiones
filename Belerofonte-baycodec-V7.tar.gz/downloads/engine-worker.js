// Motor del gestor de descargas (Web Worker). Descarga un archivo con varias conexiones a la vez,
// cada una pidiendo un trozo distinto con la cabecera Range, y escribe cada trozo directamente en
// su sitio dentro de un archivo del almacenamiento privado de la extensión (OPFS).
//
// - División dinámica (como IDM): cuando una conexión termina su trozo, la parte que más le falta
//   a otra conexión se divide por la mitad y la conexión libre se queda con la segunda mitad.
// - Pausa: se cortan las conexiones; lo escrito queda en disco y la posición de cada trozo se envía
//   a la página, que la guarda. Al reanudar se pide cada trozo desde donde quedó (con If-Range: si
//   el archivo cambió en el servidor, se empieza de cero).
// - Si el servidor no admite Range, se descarga con una sola conexión y no se puede reanudar.
//
// Mensajes que recibe:  { cmd: 'start', job }  { cmd: 'pause', id }  { cmd: 'cancel', id }  { cmd: 'delete', id }
// Mensajes que envía:   { type: 'info', id, ... }  { type: 'progress', id, parts, bytes, active }
//                       { type: 'done', id, size }  { type: 'paused', id, parts, bytes }
//                       { type: 'error', id, message, parts, bytes }

const DIR = 'belerofonte-descargas';
const MIN_SPLIT = 2 * 1024 * 1024; // no se divide un trozo al que le faltan menos de 2 MB
const MAX_RETRIES = 6;
const PROGRESS_MS = 300;
const FATAL = new Set([401, 403, 404, 410]);

const jobs = new Map();
const sleep = (ms, signal) => new Promise((resolve) => {
  const timer = setTimeout(resolve, ms);
  signal?.addEventListener('abort', () => { clearTimeout(timer); resolve(); }, { once: true });
});

class HttpError extends Error {
  constructor(status) {
    super(`el servidor respondió ${status}`);
    this.status = status;
  }
}

const STATUS_TEXT = {
  401: 'el servidor pide iniciar sesión (401)',
  403: 'el servidor rechazó la descarga (403): el enlace pudo caducar; vuelve a la página del video y descárgalo otra vez',
  404: 'el archivo ya no existe en el servidor (404)',
  410: 'el enlace caducó (410): vuelve a la página del video y descárgalo otra vez',
};

async function fileHandle(id, create = true) {
  const root = await navigator.storage.getDirectory();
  const dir = await root.getDirectoryHandle(DIR, { create: true });
  return dir.getFileHandle(id, { create });
}

// Nombre del archivo según Content-Disposition (si lo trae).
function dispositionName(response) {
  const value = response.headers.get('content-disposition') || '';
  const match = value.match(/filename\*\s*=\s*(?:UTF-8|utf-8)''([^;]+)|filename\s*=\s*"?([^";]+)"?/);
  if (!match) return '';
  try {
    return decodeURIComponent((match[1] || match[2]).trim());
  } catch {
    return (match[1] || match[2]).trim();
  }
}

// Primera petición: ¿admite Range?, tamaño, nombre, tipo y validador (ETag / Last-Modified).
// Si el servidor ignora el Range (200), esa misma respuesta se usa para descargar con una conexión.
async function probe(job) {
  const response = await fetch(job.url, {
    headers: { Range: 'bytes=0-0' }, credentials: 'include', cache: 'no-store', signal: job.signal,
  });
  if (!response.ok) throw new HttpError(response.status);
  const info = {
    filename: dispositionName(response),
    contentType: (response.headers.get('content-type') || '').split(';')[0].trim(),
    finalUrl: response.url,
  };
  const etag = response.headers.get('etag');
  const lastModified = response.headers.get('last-modified');
  // Un ETag débil (W/…) no vale para If-Range.
  info.validator = etag && !etag.startsWith('W/') ? etag : lastModified || '';

  if (response.status === 206) {
    const total = Number((response.headers.get('content-range') || '').split('/')[1]);
    response.body?.cancel();
    info.resumable = Number.isFinite(total) && total > 0;
    info.size = info.resumable ? total : null;
    return { info };
  }
  const length = Number(response.headers.get('content-length'));
  info.resumable = false;
  info.size = length > 0 ? length : null;
  return { info, response };
}

function remaining(part) {
  return part.end - part.pos + 1;
}

// Reparte el archivo en trozos iguales (uno por conexión, sin bajar de 1 MB por trozo).
function split(size, connections) {
  const count = Math.max(1, Math.min(connections, Math.ceil(size / (1024 * 1024))));
  const step = Math.ceil(size / count);
  const parts = [];
  for (let start = 0; start < size; start += step) parts.push({ start, end: Math.min(start + step, size) - 1, pos: start });
  return parts;
}

// Escribe un trozo recibido, sin pasarse del final de su parte (que puede haber encogido al dividirla).
function write(job, part, chunk) {
  const room = job.size == null ? chunk.length : remaining(part);
  const data = chunk.length > room ? chunk.subarray(0, room) : chunk;
  if (data.length) {
    job.handle.write(data, { at: part.pos });
    part.pos += data.length;
    job.bytes += data.length;
  }
  return chunk.length > room; // true: esta parte ya está completa
}

async function readInto(job, part, response) {
  const reader = response.body.getReader();
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) return true;
      if (write(job, part, value)) {
        reader.cancel().catch(() => {});
        return true;
      }
      if (job.size != null && remaining(part) <= 0) {
        reader.cancel().catch(() => {});
        return true;
      }
    }
  } finally {
    reader.releaseLock?.();
  }
}

// Descarga una parte desde part.pos hasta part.end, con reintentos si se corta la conexión.
async function runPart(job, part, firstResponse) {
  let attempts = 0;
  let response = firstResponse;
  while (!job.signal.aborted && (job.size == null || remaining(part) > 0)) {
    try {
      if (!response) {
        const headers = {};
        if (job.resumable) {
          headers.Range = `bytes=${part.pos}-${part.end}`;
          if (job.validator) headers['If-Range'] = job.validator;
        }
        response = await fetch(job.url, { headers, credentials: 'include', cache: 'no-store', signal: job.signal });
        if (response.status === 416 && job.resumable) return; // ya no queda nada que pedir
        if (!response.ok) throw new HttpError(response.status);
        if (job.resumable && response.status === 200) {
          // El servidor mandó el archivo entero: cambió desde que se empezó (o dejó de admitir Range).
          response.body?.cancel();
          const error = new Error('el archivo cambió en el servidor: se descarga de nuevo desde el principio');
          error.restart = true;
          throw error;
        }
      }
      const before = part.pos;
      await readInto(job, part, response);
      response = null;
      if (part.pos > before) attempts = 0;
      if (job.size == null) {
        // Sin tamaño conocido: termina cuando el servidor cierra la respuesta.
        job.size = part.pos;
        part.end = part.pos - 1;
        return;
      }
    } catch (err) {
      response = null;
      if (job.signal.aborted) return;
      if (err.restart || (err.status && FATAL.has(err.status))) throw err;
      if (!job.resumable) throw new Error(`se cortó la conexión y el servidor no permite continuar (${err.message})`);
      attempts += 1;
      if (attempts > MAX_RETRIES) throw err;
      await sleep(1000 * attempts, job.signal);
    }
  }
}

// La parte a la que más le falta, si merece la pena dividirla.
function steal(job) {
  let biggest = null;
  for (const part of job.parts) if (!biggest || remaining(part) > remaining(biggest)) biggest = part;
  if (!biggest || remaining(biggest) < MIN_SPLIT * 2) return null;
  const mid = biggest.pos + Math.floor(remaining(biggest) / 2);
  const part = { start: mid, end: biggest.end, pos: mid };
  biggest.end = mid - 1;
  job.parts.push(part);
  return part;
}

async function runJob(job, firstResponse) {
  const running = new Map(); // parte -> promesa
  const busy = new Set();
  const launch = (part, response) => {
    busy.add(part);
    const promise = runPart(job, part, response).finally(() => {
      busy.delete(part);
      running.delete(part);
    });
    running.set(part, promise);
  };

  if (firstResponse) {
    launch(job.parts[0], firstResponse);
  } else {
    for (const part of job.parts) {
      if (running.size >= job.connections) break;
      if (remaining(part) > 0) launch(part);
    }
  }

  while (running.size) {
    await Promise.race(running.values());
    if (job.signal.aborted) break;
    if (!job.resumable) continue;
    while (running.size < job.connections) {
      const pending = job.parts.find((p) => remaining(p) > 0 && !busy.has(p));
      const next = pending || steal(job);
      if (!next) break;
      launch(next);
    }
  }
  await Promise.allSettled(running.values());
}

function snapshot(job) {
  return job.parts.map(({ start, end, pos }) => ({ start, end, pos }));
}

function report(job) {
  postMessage({ type: 'progress', id: job.id, parts: snapshot(job), bytes: job.bytes, size: job.size, active: job.activeCount() });
}

async function start(data) {
  if (jobs.has(data.id)) return;
  const controller = new AbortController();
  const job = {
    ...data,
    parts: (data.parts || []).map((p) => ({ ...p })),
    controller,
    signal: controller.signal,
    bytes: 0,
    activeCount: () => job.parts.filter((p) => remaining(p) > 0).length,
  };
  jobs.set(job.id, job);
  let timer = null;

  try {
    const file = await fileHandle(job.id);
    job.handle = await file.createSyncAccessHandle();

    let firstResponse = null;
    if (!job.probed) {
      const { info, response } = await probe(job);
      Object.assign(job, info, { probed: true });
      postMessage({ type: 'info', id: job.id, ...info });
      firstResponse = response || null;
    }

    if (!job.resumable) {
      // Sin reanudación: una sola conexión y siempre desde el principio (se vacía lo que hubiera).
      job.handle.truncate(0);
      job.parts = [{ start: 0, end: job.size != null ? job.size - 1 : Number.MAX_SAFE_INTEGER, pos: 0 }];
      if (!firstResponse) {
        const response = await fetch(job.url, { credentials: 'include', cache: 'no-store', signal: job.signal });
        if (!response.ok) throw new HttpError(response.status);
        firstResponse = response;
      }
    } else if (!job.parts.length) {
      job.parts = split(job.size, job.connections);
    }
    job.bytes = job.parts.reduce((sum, p) => sum + (p.pos - p.start), 0);

    timer = setInterval(() => report(job), PROGRESS_MS);
    try {
      await runJob(job, firstResponse);
    } catch (err) {
      if (err.restart) {
        // Empezar de cero con el archivo nuevo.
        job.handle.truncate(0);
        job.probed = false;
        clearInterval(timer);
        job.handle.close();
        jobs.delete(job.id);
        postMessage({ type: 'restart', id: job.id, message: err.message });
        return;
      }
      throw err;
    }
    clearInterval(timer);
    job.handle.flush();

    if (job.signal.aborted) {
      const reason = job.signal.reason;
      job.handle.close();
      jobs.delete(job.id);
      if (reason === 'cancel') {
        await removeFile(job.id);
        postMessage({ type: 'cancelled', id: job.id });
      } else {
        postMessage({ type: 'paused', id: job.id, parts: snapshot(job), bytes: job.bytes, size: job.size });
      }
      return;
    }

    if (job.size != null && job.handle.getSize() !== job.size) job.handle.truncate(job.size);
    const size = job.handle.getSize();
    job.handle.close();
    jobs.delete(job.id);
    postMessage({ type: 'done', id: job.id, size, parts: snapshot(job) });
  } catch (err) {
    clearInterval(timer);
    try {
      job.handle?.flush();
      job.handle?.close();
    } catch { /* ya cerrado */ }
    jobs.delete(job.id);
    const message = err.status ? STATUS_TEXT[err.status] || err.message : err.message;
    postMessage({ type: 'error', id: job.id, message, status: err.status || 0, parts: snapshot(job), bytes: job.bytes, size: job.size });
  }
}

async function removeFile(id) {
  try {
    const root = await navigator.storage.getDirectory();
    const dir = await root.getDirectoryHandle(DIR, { create: true });
    await dir.removeEntry(id);
  } catch { /* no existía */ }
}

onmessage = async ({ data }) => {
  const job = jobs.get(data.id);
  if (data.cmd === 'start') start(data.job);
  else if (data.cmd === 'pause') job?.controller.abort('pause');
  else if (data.cmd === 'cancel') {
    if (job) job.controller.abort('cancel');
    else {
      await removeFile(data.id);
      postMessage({ type: 'cancelled', id: data.id });
    }
  } else if (data.cmd === 'delete') {
    if (!job) await removeFile(data.id);
  }
};
