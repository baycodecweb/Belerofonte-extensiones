// Gestor de descargas: lista, cola, pausa/reanudación e historial. El trabajo de red y disco lo
// hace engine-worker.js; esta página decide qué se descarga, guarda el estado en chrome.storage
// y, al terminar, entrega el archivo al gestor de descargas del navegador (carpeta Descargas).
//
// Las descargas nuevas llegan como claves «dm:inbox:<id>» en chrome.storage.local (las escribe el
// service worker desde el popup, el botón flotante o las páginas de HLS y yt-dlp). Cada clave se
// borra al leerla, así nunca se pierde ni se duplica una entrada.

const LIST_KEY = 'dm:list';
const SETTINGS_KEY = 'dm:settings';
const INBOX = 'dm:inbox:';
const FLOAT_KEY = 'dmFloat';
const MAX_HISTORY = 300;
const RULE_BASE = 2_000_000; // reglas de Referer (las de media.js empiezan en 1 000 000)
const NATIVE_HOST = 'com.baycodec.belerofonte_ytdlp';

const EXT_BY_TYPE = {
  'video/mp4': 'mp4', 'video/webm': 'webm', 'video/quicktime': 'mov', 'video/x-matroska': 'mkv', 'audio/mpeg': 'mp3',
  'audio/mp4': 'm4a', 'audio/ogg': 'ogg', 'application/pdf': 'pdf', 'application/zip': 'zip', 'image/jpeg': 'jpg',
  'image/png': 'png', 'application/x-msdownload': 'exe', 'application/vnd.android.package-archive': 'apk',
};

const $ = (id) => document.getElementById(id);
const listEl = $('list');
const worker = new Worker('engine-worker.js');

let items = [];
let owner = false; // solo una ventana del gestor descarga (ver el candado al final)
let settings = { connections: 8, simultaneous: 3, seq: 0 };
let filter = 'all';
const rows = new Map(); // id -> elementos de la fila
const speeds = new Map(); // id -> [{ t, bytes }]
const savingUrls = new Map(); // downloadId del navegador -> { id, url }

// --- Utilidades -----------------------------------------------------------------------------

const size = (bytes) => {
  if (bytes == null) return '?';
  if (bytes >= 1073741824) return `${(bytes / 1073741824).toFixed(2)} GB`;
  if (bytes >= 1048576) return `${(bytes / 1048576).toFixed(1)} MB`;
  return `${Math.max(1, Math.round(bytes / 1024))} KB`;
};
const clock = (seconds) => {
  const s = Math.max(0, Math.round(seconds));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  return `${h ? `${h}:` : ''}${String(m).padStart(h ? 2 : 1, '0')}:${String(s % 60).padStart(2, '0')}`;
};
const safeName = (name) => name.replace(/[\\/:*?"<>|\u0000-\u001f]+/g, ' ').replace(/\s+/g, ' ').replace(/^[.\s]+|[.\s]+$/g, '').slice(0, 180) || 'descarga';
const host = (url) => {
  try {
    return new URL(url).hostname;
  } catch {
    return '';
  }
};
const find = (id) => items.find((i) => i.id === id);
const isActive = (item) => ['queued', 'downloading', 'saving'].includes(item.state);

function urlName(url) {
  try {
    const last = new URL(url).pathname.split('/').filter(Boolean).pop() || '';
    return decodeURIComponent(last);
  } catch {
    return '';
  }
}

// Nombre final: el pedido, el del servidor o el de la URL, con la extensión del tipo si no la tiene.
function finalName(item, info = {}) {
  let name = item.filename || info.filename || urlName(info.finalUrl || item.url) || 'descarga';
  name = safeName(name);
  if (!/\.\w{2,5}$/.test(name)) {
    const ext = EXT_BY_TYPE[info.contentType || item.contentType] || (info.contentType?.startsWith('video/') ? 'mp4' : '');
    if (ext) name += `.${ext}`;
  }
  return name;
}

// --- Estado guardado ----------------------------------------------------------------------

// Como mucho una escritura por segundo durante las descargas (sin aplazarla sin fin: si no, con el
// progreso llegando cada 300 ms nunca se guardaría) y al instante en los cambios de estado.
let saveTimer = null;
function save(now = false) {
  const write = () => {
    clearTimeout(saveTimer);
    saveTimer = null;
    return chrome.storage.local.set({ [LIST_KEY]: items.map(({ speed, ...rest }) => rest) });
  };
  if (now) return write();
  saveTimer ??= setTimeout(write, 1000);
}

async function load() {
  const stored = await chrome.storage.local.get([LIST_KEY, SETTINGS_KEY, FLOAT_KEY]);
  items = stored[LIST_KEY] || [];
  settings = { ...settings, ...(stored[SETTINGS_KEY] || {}) };
  $('set-connections').value = String(settings.connections);
  $('set-simultaneous').value = String(settings.simultaneous);
  $('set-float').checked = stored[FLOAT_KEY] !== false;
  // Lo que se estaba descargando cuando se cerró la ventana vuelve a la cola (y continúa solo).
  for (const item of items) {
    if (item.state === 'downloading') item.state = 'queued';
    item.savingStarted = false;
  }
}

// --- Entradas nuevas ----------------------------------------------------------------------

function addItem(entry) {
  const item = {
    id: entry.id || crypto.randomUUID(),
    kind: entry.kind || 'file',
    url: entry.url,
    referer: entry.referer || '',
    pageUrl: entry.pageUrl || '',
    filename: entry.filename || '',
    name: entry.name || (entry.filename ? safeName(entry.filename) : urlName(entry.url) || host(entry.url) || 'descarga'),
    size: entry.size ?? null,
    path: entry.path || '',
    downloadId: entry.downloadId ?? null,
    added: entry.added || Date.now(),
    state: entry.kind && entry.kind !== 'file' ? 'complete' : 'queued',
    finished: entry.kind && entry.kind !== 'file' ? entry.added || Date.now() : null,
    parts: [],
    bytes: entry.size || 0,
    num: ++settings.seq,
  };
  if (items.some((i) => i.id === item.id)) return;
  items.unshift(item);
  trimHistory();
  chrome.storage.local.set({ [SETTINGS_KEY]: settings });
  save(true);
  render();
  schedule();
}

// El historial no crece sin límite: se quitan las completadas más antiguas.
function trimHistory() {
  while (items.length > MAX_HISTORY) {
    const index = items.findLastIndex((i) => i.state === 'complete' || i.state === 'error');
    if (index < 0) break;
    items.splice(index, 1);
  }
}

async function readInbox() {
  const all = await chrome.storage.local.get(null);
  const keys = Object.keys(all).filter((k) => k.startsWith(INBOX)).sort((a, b) => (all[a].added || 0) - (all[b].added || 0));
  if (!keys.length) return;
  await chrome.storage.local.remove(keys);
  for (const key of keys) addItem(all[key]);
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (!owner) return;
  if (area === 'local' && Object.keys(changes).some((k) => k.startsWith(INBOX) && changes[k].newValue)) readInbox();
});

// --- Referer: reglas de declarativeNetRequest para las peticiones de esta extensión ------------
// Muchos servidores de video solo entregan el archivo si la petición dice venir de su página.

function ruleId(item) {
  return RULE_BASE + (item.num % 900_000);
}

async function setReferer(item) {
  const target = host(item.url);
  if (!item.referer || !target) return;
  try {
    await chrome.declarativeNetRequest.updateSessionRules({
      removeRuleIds: [ruleId(item)],
      addRules: [{
        id: ruleId(item),
        priority: 2,
        condition: { initiatorDomains: [chrome.runtime.id], requestDomains: [target], resourceTypes: ['xmlhttprequest', 'other'] },
        action: {
          type: 'modifyHeaders',
          requestHeaders: [
            { header: 'referer', operation: 'set', value: item.referer },
            { header: 'origin', operation: 'set', value: new URL(item.referer).origin },
          ],
        },
      }],
    });
  } catch { /* sin regla la descarga se intenta igual */ }
}

function clearReferer(item) {
  chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [ruleId(item)] }).catch(() => {});
}

// --- Cola ---------------------------------------------------------------------------------

function schedule() {
  for (const item of items.filter((i) => i.state === 'saving' && !i.savingStarted)) saveToDisk(item);
  let running = items.filter((i) => i.state === 'downloading').length;
  // Las más antiguas primero (la lista se muestra con la más nueva arriba).
  for (const item of [...items].reverse()) {
    if (running >= settings.simultaneous) break;
    if (item.state !== 'queued') continue;
    start(item);
    running++;
  }
  updateSummary();
}

async function start(item) {
  item.state = 'downloading';
  item.error = '';
  speeds.set(item.id, []);
  await setReferer(item);
  worker.postMessage({
    cmd: 'start',
    job: {
      id: item.id, url: item.url, connections: settings.connections, probed: !!item.probed, resumable: item.resumable,
      size: item.size, validator: item.validator || '', parts: item.parts || [],
    },
  });
  save(true);
  updateRow(item);
}

function pause(item) {
  if (item.state === 'queued') item.state = 'paused';
  else if (item.state === 'downloading') worker.postMessage({ cmd: 'pause', id: item.id });
  save(true);
  updateRow(item);
  schedule();
}

function resume(item) {
  if (item.state !== 'paused' && item.state !== 'error') return;
  if (item.state === 'error' && item.retryFromStart) {
    item.parts = [];
    item.probed = false;
    item.bytes = 0;
  }
  item.state = 'queued';
  save(true);
  updateRow(item);
  schedule();
}

function cancel(item) {
  if (item.state === 'downloading') worker.postMessage({ cmd: 'cancel', id: item.id });
  else worker.postMessage({ cmd: 'delete', id: item.id });
  clearReferer(item);
  items = items.filter((i) => i !== item);
  save(true);
  render();
  schedule();
}

// --- Mensajes del motor ---------------------------------------------------------------------

worker.onmessage = ({ data }) => {
  const item = find(data.id);
  if (!item) return;
  if (data.parts) item.parts = data.parts;
  if (data.bytes != null) item.bytes = data.bytes;
  if (data.size != null) item.size = data.size;

  switch (data.type) {
    case 'info':
      Object.assign(item, {
        probed: true, resumable: data.resumable, size: data.size, validator: data.validator, contentType: data.contentType,
      });
      item.name = finalName(item, data);
      save(true);
      updateRow(item, true);
      break;
    case 'progress': {
      const samples = speeds.get(item.id) || [];
      const now = performance.now();
      samples.push({ t: now, bytes: item.bytes });
      while (samples.length > 2 && now - samples[0].t > 4000) samples.shift();
      speeds.set(item.id, samples);
      const first = samples[0];
      item.speed = now > first.t ? ((item.bytes - first.bytes) * 1000) / (now - first.t) : 0;
      item.active = data.active;
      save();
      updateRow(item);
      updateSummary();
      break;
    }
    case 'paused':
      item.state = 'paused';
      item.speed = 0;
      clearReferer(item);
      save(true);
      updateRow(item);
      schedule();
      break;
    case 'restart':
      item.parts = [];
      item.probed = false;
      item.bytes = 0;
      item.state = 'queued';
      save(true);
      schedule();
      break;
    case 'error':
      item.state = 'error';
      item.error = data.message;
      item.speed = 0;
      item.retryFromStart = !item.resumable;
      clearReferer(item);
      save(true);
      updateRow(item, true);
      schedule();
      break;
    case 'done':
      item.state = 'saving';
      item.speed = 0;
      item.bytes = data.size;
      item.size = data.size;
      clearReferer(item);
      save(true);
      updateRow(item, true);
      schedule();
      break;
    case 'cancelled':
      break;
  }
};

// --- Entrega al navegador (carpeta Descargas) --------------------------------------------------
// El archivo está en el almacenamiento privado de la extensión: se pasa al gestor de descargas del
// navegador y, cuando termina de copiarlo, se borra la copia privada.

async function saveToDisk(item) {
  item.savingStarted = true;
  try {
    const root = await navigator.storage.getDirectory();
    const dir = await root.getDirectoryHandle('belerofonte-descargas', { create: true });
    const file = await (await dir.getFileHandle(item.id)).getFile();
    // Con su tipo MIME: sin él, el navegador puede cambiarle la extensión (p. ej. a .txt).
    const url = URL.createObjectURL(new Blob([file], { type: item.contentType || 'application/octet-stream' }));
    const downloadId = await chrome.downloads.download({ url, filename: item.name, conflictAction: 'uniquify', saveAs: false });
    savingUrls.set(downloadId, { id: item.id, url });
    item.downloadId = downloadId;
    save(true);
  } catch (err) {
    item.savingStarted = false;
    item.state = 'error';
    item.error = `No se pudo guardar el archivo (${err.message}).`;
    item.retryFromStart = true;
    save(true);
    updateRow(item, true);
  }
}

chrome.downloads.onChanged.addListener(async (delta) => {
  const entry = savingUrls.get(delta.id);
  if (!entry || !delta.state) return;
  const item = find(entry.id);
  if (delta.state.current === 'complete') {
    savingUrls.delete(delta.id);
    URL.revokeObjectURL(entry.url);
    worker.postMessage({ cmd: 'delete', id: entry.id });
    if (item) {
      const [download] = await chrome.downloads.search({ id: delta.id });
      Object.assign(item, { state: 'complete', finished: Date.now(), path: download?.filename || '', parts: [], savingStarted: false });
      if (download?.filename) item.name = download.filename.split(/[\\/]/).pop();
    }
  } else if (delta.state.current === 'interrupted') {
    savingUrls.delete(delta.id);
    URL.revokeObjectURL(entry.url);
    if (item) {
      // El archivo sigue en el almacenamiento privado: «Reintentar» lo vuelve a entregar.
      Object.assign(item, { state: 'error', error: 'El navegador no pudo guardar el archivo en la carpeta de descargas.', savingStarted: false, saveFailed: true });
    }
  }
  if (item) {
    save(true);
    updateRow(item, true);
    updateSummary();
  }
});

// --- Interfaz -----------------------------------------------------------------------------

function el(tag, props = {}, children = []) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children.filter(Boolean));
  return node;
}

function badge(item) {
  if (item.kind === 'ytdlp') return 'yt-dlp';
  if (item.kind === 'hls') return 'HLS';
  return (item.name.match(/\.(\w{2,5})$/)?.[1] || 'FILE').toUpperCase().slice(0, 5);
}

function visible(item) {
  if (filter === 'active') return isActive(item) || item.state === 'paused';
  if (filter === 'complete') return item.state === 'complete';
  if (filter === 'error') return item.state === 'error';
  return true;
}

function render() {
  const shown = items.filter(visible);
  $('empty').hidden = shown.length > 0;
  $('empty').textContent = items.length
    ? 'No hay descargas en esta vista.'
    : 'No hay descargas. Pega un enlace arriba, usa el botón «⬇ Descargar» que aparece sobre los videos o la sección Videos del popup.';
  const nodes = shown.map((item) => {
    let row = rows.get(item.id);
    if (!row) {
      row = buildRow(item);
      rows.set(item.id, row);
    }
    updateRow(item, true);
    return row.li;
  });
  for (const [id] of rows) if (!find(id)) rows.delete(id);
  listEl.replaceChildren(...nodes);
  updateSummary();
}

function buildRow(item) {
  const row = {
    badge: el('span', { className: 'item__badge' }),
    name: el('div', { className: 'item__name' }),
    source: el('div', { className: 'item__source muted' }),
    bar: el('div', { className: 'item__bar' }),
    status: el('span', { className: 'item__status' }),
    actions: el('div', { className: 'item__actions' }),
  };
  row.li = el('li', { className: 'item' }, [
    row.badge,
    el('div', {}, [row.name, row.source]),
    row.bar,
    el('div', { className: 'item__meta' }, [row.status, row.actions]),
  ]);
  return row;
}

function button(text, onClick, primary = false) {
  const b = el('button', { className: `btn${primary ? ' btn--primary' : ''}`, textContent: text });
  b.addEventListener('click', onClick);
  return b;
}

function statusText(item) {
  const total = item.size;
  const pct = total ? Math.floor((item.bytes / total) * 100) : null;
  switch (item.state) {
    case 'queued':
      return `En cola${item.bytes ? ` · ${size(item.bytes)}${total ? ` de ${size(total)}` : ''} descargado` : ''}`;
    case 'downloading': {
      if (!item.probed) return 'Conectando…';
      const speed = item.speed || 0;
      const parts = [
        pct != null ? `${pct} %` : null,
        `${size(item.bytes)}${total ? ` de ${size(total)}` : ''}`,
        `${size(speed)}/s`,
        total && speed > 0 ? `quedan ${clock((total - item.bytes) / speed)}` : null,
        item.resumable ? `${item.active || 0} ${item.active === 1 ? 'conexión' : 'conexiones'}` : '1 conexión · el servidor no permite pausar',
      ];
      return parts.filter(Boolean).join(' · ');
    }
    case 'paused':
      return `Pausado · ${size(item.bytes)}${total ? ` de ${size(total)} (${pct} %)` : ''}${item.resumable === false ? ' · al reanudar empezará de cero' : ''}`;
    case 'saving':
      return 'Guardando en la carpeta de descargas…';
    case 'complete':
      return `Completado · ${size(item.size)} · ${new Date(item.finished || item.added).toLocaleString('es', { dateStyle: 'short', timeStyle: 'short' })}`;
    case 'error':
      return `Error: ${item.error || 'desconocido'}`;
    default:
      return '';
  }
}

function updateBar(row, item) {
  const total = item.size;
  row.bar.classList.toggle('indeterminate', item.state === 'downloading' && !total);
  if (item.state === 'complete' || item.state === 'saving') {
    row.bar.replaceChildren(Object.assign(el('span'), { style: 'left:0;width:100%' }));
    return;
  }
  if (!total) {
    row.bar.replaceChildren(item.state === 'downloading' ? el('span') : '');
    return;
  }
  // Un tramo por parte: muestra qué ha bajado cada conexión.
  const spans = (item.parts?.length ? item.parts : [{ start: 0, pos: item.bytes }]).map((p) => {
    const span = el('span');
    span.style.left = `${(p.start / total) * 100}%`;
    span.style.width = `${(Math.max(0, p.pos - p.start) / total) * 100}%`;
    return span;
  });
  row.bar.replaceChildren(...spans);
}

function updateRow(item, full = false) {
  const row = rows.get(item.id);
  if (!row) return;
  row.li.className = `item state-${item.state}`;
  row.status.textContent = statusText(item);
  updateBar(row, item);
  if (!full && row.lastState === item.state) return;
  row.lastState = item.state;
  row.badge.textContent = badge(item);
  row.name.textContent = item.name;
  row.name.title = item.path || item.name;
  // Web de origen y servidor del archivo (una sola vez si coinciden).
  row.source.textContent = [...new Set([host(item.pageUrl), host(item.url)].filter(Boolean))].join(' → ');
  row.source.title = item.url;

  const actions = [];
  if (item.state === 'downloading' || item.state === 'queued') actions.push(button('⏸ Pausar', () => pause(item)));
  if (item.state === 'paused') actions.push(button('▶ Reanudar', () => resume(item), true));
  if (item.state === 'error') {
    actions.push(button('↻ Reintentar', () => {
      if (item.saveFailed) {
        item.saveFailed = false;
        item.state = 'saving';
        schedule();
        updateRow(item, true);
      } else resume(item);
    }, true));
  }
  if (item.state === 'complete') {
    if (item.downloadId != null) {
      actions.push(button('📂 Abrir', () => chrome.downloads.open(item.downloadId).catch(() => showMissing(item))));
      actions.push(button('🗂 Mostrar en la carpeta', () => chrome.downloads.show(item.downloadId)));
    } else if (item.kind === 'ytdlp' && item.path) {
      actions.push(button('🗂 Mostrar en la carpeta', () => chrome.runtime.sendNativeMessage(NATIVE_HOST, { action: 'reveal', path: item.path }).catch(() => {})));
    }
  }
  if (item.url && item.kind === 'file') actions.push(button('⧉ Enlace', () => navigator.clipboard.writeText(item.url)));
  if (item.state === 'complete' || item.state === 'error' || item.state === 'paused' || item.state === 'queued') {
    actions.push(button(item.state === 'complete' ? '✕ Quitar' : '🗑 Cancelar', () => cancel(item)));
  }
  row.actions.replaceChildren(...actions);
}

function showMissing(item) {
  item.error = 'El archivo ya no está en la carpeta de descargas.';
  const row = rows.get(item.id);
  if (row) row.status.textContent = item.error;
}

function updateSummary() {
  const downloading = items.filter((i) => i.state === 'downloading');
  const queued = items.filter((i) => i.state === 'queued').length;
  const speed = downloading.reduce((sum, i) => sum + (i.speed || 0), 0);
  const parts = [];
  if (downloading.length) parts.push(`${downloading.length} descargando · ${size(speed)}/s`);
  if (queued) parts.push(`${queued} en cola`);
  const paused = items.filter((i) => i.state === 'paused').length;
  if (paused) parts.push(`${paused} en pausa`);
  const done = items.filter((i) => i.state === 'complete').length;
  if (done) parts.push(`${done} completadas`);
  $('summary').textContent = parts.join(' · ') || 'Sin descargas en curso';
  $('keep-open').hidden = !downloading.length && !queued;

  const known = downloading.filter((i) => i.size);
  const pct = known.length
    ? Math.floor((known.reduce((s, i) => s + i.bytes, 0) / known.reduce((s, i) => s + i.size, 0)) * 100)
    : null;
  document.title = downloading.length ? `${pct != null ? `${pct} % · ` : ''}Descargando · Belerofonte` : 'Gestor de descargas · Belerofonte-Baycodec';
}

// --- Controles ----------------------------------------------------------------------------

$('add-form').addEventListener('submit', (event) => {
  event.preventDefault();
  const input = $('add-url');
  try {
    const url = new URL(input.value.trim());
    if (!/^https?:$/.test(url.protocol)) throw new Error();
    // Los enlaces de YouTube, Vimeo, listas .m3u8… los resuelve el service worker como en el popup.
    chrome.runtime.sendMessage({ type: 'dm-add-url', url: url.href }).then((res) => {
      if (!res?.ok) alertRow(res?.error || 'No se pudo añadir el enlace.');
    });
    input.value = '';
  } catch {
    alertRow('El enlace tiene que empezar por http:// o https://.');
  }
});

function alertRow(text) {
  const input = $('add-url');
  input.setCustomValidity(text);
  input.reportValidity();
  setTimeout(() => input.setCustomValidity(''), 3000);
}

for (const chip of document.querySelectorAll('.chip-btn')) {
  chip.addEventListener('click', () => {
    filter = chip.dataset.filter;
    document.querySelectorAll('.chip-btn').forEach((c) => c.classList.toggle('active', c === chip));
    render();
  });
}

$('pause-all').addEventListener('click', () => items.filter((i) => i.state === 'downloading' || i.state === 'queued').forEach(pause));
$('resume-all').addEventListener('click', () => items.filter((i) => i.state === 'paused').forEach(resume));
$('clear-done').addEventListener('click', () => {
  items = items.filter((i) => i.state !== 'complete');
  save(true);
  render();
});

$('settings-btn').addEventListener('click', () => {
  const panel = $('settings');
  panel.hidden = !panel.hidden;
  $('settings-btn').setAttribute('aria-expanded', String(!panel.hidden));
});
$('set-connections').addEventListener('change', (e) => {
  settings.connections = Number(e.target.value);
  chrome.storage.local.set({ [SETTINGS_KEY]: settings });
});
$('set-simultaneous').addEventListener('change', (e) => {
  settings.simultaneous = Number(e.target.value);
  chrome.storage.local.set({ [SETTINGS_KEY]: settings });
  schedule();
});
$('set-float').addEventListener('change', (e) => chrome.storage.local.set({ [FLOAT_KEY]: e.target.checked }));

// Al cerrar, se guarda dónde se quedó cada parte.
window.addEventListener('pagehide', () => owner && save(true));

// Cerrar la ventana con descargas en curso: se avisa (al volver a abrirla continúan).
window.addEventListener('beforeunload', (event) => {
  if (items.some((i) => i.state === 'downloading' || i.state === 'saving')) {
    event.preventDefault();
    event.returnValue = '';
  }
});

// Una sola ventana del gestor puede descargar: si ya hay otra abierta, esta solo lo avisa.
owner = await new Promise((resolve) => {
  navigator.locks.request('belerofonte-gestor-descargas', { ifAvailable: true }, (lock) => {
    resolve(!!lock);
    return lock ? new Promise(() => {}) : undefined; // se mantiene hasta cerrar la ventana
  });
});

if (owner) {
  await load();
  render();
  await readInbox();
  schedule();
} else {
  document.querySelector('.dm').replaceChildren(Object.assign(document.createElement('p'), {
    className: 'notice',
    textContent: 'El gestor de descargas ya está abierto en otra ventana. Cierra esta y usa aquella.',
  }));
}
