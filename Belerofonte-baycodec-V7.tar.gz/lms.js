// Análisis de plataformas educativas (LMS): versión, soporte, tema y plugins.
// Igual que wordpress.js, solo lee archivos públicos (los que puede abrir cualquier visitante)
// y compara con las fuentes oficiales de cada proyecto para saber si está al día.

import { compareVersions, fetchText, fetchJson, attempt, mostCommon } from './wordpress.js';

const MAX_HTML = 1_500_000;
const MAX_PLUGINS = 80;
const DAY = 24 * 60 * 60 * 1000;

// --- Datos que se leen dentro de la página -----------------------------------------
// Se serializan y se ejecutan en la pestaña: no pueden usar nada de fuera de su cuerpo.

function collectLmsHints(maxHtml) {
  const urls = new Set();
  for (const node of document.querySelectorAll('[src], [href]')) {
    for (const attr of ['src', 'href']) {
      const value = node.getAttribute(attr);
      if (!value) continue;
      try {
        urls.add(new URL(value, document.baseURI).href);
      } catch {}
    }
  }
  try {
    for (const entry of performance.getEntriesByType('resource')) urls.add(entry.name);
  } catch {}
  // Formularios (para describir el acceso) y texto visible (pie de página, créditos).
  const forms = [...document.forms].slice(0, 10).map((form) => ({
    action: form.action || '',
    inputs: [...form.elements].filter((e) => e.name || e.type === 'password').slice(0, 20)
      .map((e) => ({ name: e.name || '', type: (e.type || '').toLowerCase(), label: (e.labels?.[0]?.textContent || e.placeholder || '').trim().slice(0, 60) })),
  }));
  const text = (document.body?.innerText || '').slice(0, 30000);
  return {
    url: location.href,
    title: document.title,
    html: document.documentElement.outerHTML.slice(0, maxHtml),
    urls: [...urls].slice(0, 3000),
    forms,
    text,
    author: document.querySelector('meta[name="author" i]')?.content || '',
    lang: document.querySelector('meta[name="accept-language" i], meta[http-equiv="content-language" i]')?.content || document.documentElement.lang || '',
    images: [...document.images].slice(0, 40).map((img) => ({ src: img.currentSrc || img.src, alt: (img.alt || '').trim().slice(0, 120) })),
  };
}

// Mundo principal: configuración que Moodle (y Totara) publican en window.M.cfg.
function collectLmsRuntime() {
  try {
    const cfg = window.M?.cfg;
    if (!cfg || typeof cfg !== 'object') return null;
    const pick = {};
    for (const key of ['wwwroot', 'theme', 'language', 'jsrev', 'themerev', 'apibase']) {
      if (['string', 'number'].includes(typeof cfg[key])) pick[key] = String(cfg[key]);
    }
    return pick;
  } catch {
    return null;
  }
}

// --- Utilidades -----------------------------------------------------------------------

const MONTHS = { january: 0, february: 1, march: 2, april: 3, may: 4, june: 5, july: 6, august: 7, september: 8, october: 9, november: 10, december: 11 };

// "5 October 2026" → Date (formato de los datos oficiales de Moodle).
function parseDate(text) {
  const m = String(text || '').match(/^(\d{1,2})\s+([a-z]+)\s+(\d{4})$/i);
  if (!m || !(m[2].toLowerCase() in MONTHS)) return null;
  return new Date(Date.UTC(+m[3], MONTHS[m[2].toLowerCase()], +m[1]));
}

const branchOf = (version) => version?.match(/^\d+\.\d+/)?.[0] || null;
const unescapeHtml = (html) => html.replace(/\\\//g, '/').replace(/&amp;/g, '&');

// Datos de fuera que no cambian a menudo: se guardan un día en memoria.
const remoteCache = new Map();
async function cachedJson(url) {
  const hit = remoteCache.get(url);
  if (hit && Date.now() - hit.at < DAY) return hit.data;
  const data = await fetchJson(url);
  remoteCache.set(url, { at: Date.now(), data });
  return data;
}

// Última versión estable de un proyecto en GitHub, en general y dentro de la misma línea.
// line(version) devuelve la "línea" a comparar: '1.11' para Chamilo 1.11.x, '9' para ILIAS 9.x…
async function githubLatest(repo, version, line, { tags = false } = {}) {
  const list = await cachedJson(`https://api.github.com/repos/${repo}/${tags ? 'tags' : 'releases'}?per_page=100`);
  const stable = (Array.isArray(list) ? list : [])
    .filter((r) => !r.prerelease && !r.draft)
    .map((r) => String(r.tag_name || r.name || '').replace(/^v/i, ''))
    .filter((v) => /^\d+(?:\.\d+)+$/.test(v))
    .sort((a, b) => compareVersions(b, a));
  if (!stable.length) return null;
  const sameLine = version ? stable.find((v) => line(v) === line(version)) : null;
  return {
    latest: stable[0],
    latestInLine: sameLine || null,
    status: version && sameLine ? (compareVersions(version, sameLine) < 0 ? 'outdated' : 'current') : 'unknown',
    newerLine: version ? compareVersions(line(stable[0]), line(version)) > 0 : false,
  };
}

const KIND = {
  'Moodle': 'open', 'Moodle Workplace': 'commercial', 'Totara Learn': 'commercial', 'Chamilo': 'open', 'Canvas LMS': 'open',
  'Open edX': 'open', 'Sakai': 'open', 'ILIAS': 'open', 'Forma LMS': 'open', 'ATutor': 'open', 'Frappe LMS': 'open',
  'Google Classroom': 'cloud', 'Microsoft Teams': 'cloud', 'Schoology': 'cloud', 'NEO LMS': 'cloud', 'EdApp': 'cloud',
  'Blackboard Learn': 'commercial', 'D2L Brightspace': 'commercial', 'Educativa': 'commercial',
  'Docebo': 'corporate', 'TalentLMS': 'corporate', 'SAP SuccessFactors Learning': 'corporate', 'Cornerstone OnDemand': 'corporate',
  'iSpring Learn': 'corporate', 'Litmos': 'corporate', 'Absorb LMS': 'corporate',
  'SIAPP': 'commercial', 'Q10': 'cloud', 'Aula virtual propia': 'custom', 'Inicio de sesión único (SSO)': 'sso',
};

// --- Moodle ------------------------------------------------------------------------------

// docs.moodle.org/405/ → 4.5; /311/ → 3.11; /39/ → 3.9.
function docsBranch(html) {
  const codes = [...html.matchAll(/docs\.moodle\.org\/(\d{2,3})\/[a-z]{2}\b/g)].map((m) => m[1]);
  const code = mostCommon(codes);
  if (!code) return null;
  return code.length === 3 ? `${code[0]}.${parseInt(code.slice(1), 10)}` : `${code[0]}.${code[1]}`;
}

// Enlace «Descargar la app móvil»: download.moodle.org/mobile?version=2020110902 lleva el número
// de compilación del sitio ($CFG->version), que identifica la versión exacta.
const buildOf = (html) => html.match(/download\.moodle\.org\/mobile\?version=(\d{10})/)?.[1] || null;

async function releaseFromBuild(build) {
  if (!build) return null;
  const data = await cachedJson('https://raw.githubusercontent.com/moodle/devdocs/main/data/versions.json');
  const num = Number(build);
  // Misma rama (comparten los 8 primeros dígitos); se toma el último parche publicado que no lo supere.
  const candidates = (data?.versions || []).flatMap((v) => v.releases || [])
    .filter((r) => Number.isFinite(r.version) && Math.floor(r.version / 100) === Math.floor(num / 100) && r.version <= num)
    .sort((a, b) => b.version - a.version);
  return candidates[0]?.name || null;
}

// Los archivos de notas de actualización solo se amplían cuando una versión trae cambios de API:
// la rama es fiable, pero el parche es un mínimo (4.5.12 puede ser 4.5.12 o posterior).
// No se usa admin/environment.xml: incluye ya los requisitos de ramas futuras.

// lib/upgrade.txt (hasta 4.4): "=== 4.3 ===" encabeza los cambios de la versión instalada.
// Si el sitio se actualizó copiando encima, puede quedar el de una versión anterior.
async function fromUpgradeTxt(root) {
  const text = await fetchText(`${root}/lib/upgrade.txt`);
  return text.slice(0, 4000).match(/^===\s*(\d+\.\d+(?:\.\d+)?)\s*===/m)?.[1] || null;
}

// UPGRADING.md (4.5 y 5.0): "## 4.5" o "## 5.0dev+".
async function fromUpgradingMd(root) {
  const text = await fetchText(`${root}/UPGRADING.md`);
  if (!/moodle/i.test(text.slice(0, 2000))) return null;
  return text.match(/^##\s+(\d+\.\d+(?:\.\d+)?)/m)?.[1] || null;
}

// Configuración pública que usa la app oficial de Moodle (no requiere sesión).
async function publicConfig(root) {
  const res = await fetch(`${root}/lib/ajax/service-nologin.php?info=tool_mobile_get_public_config`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify([{ index: 0, methodname: 'tool_mobile_get_public_config', args: {} }]),
    credentials: 'omit',
    signal: AbortSignal.timeout(10_000),
  });
  const data = (await res.json())?.[0];
  return data && !data.error ? data.data : null;
}

// Calendario oficial de versiones (el mismo que publica moodledev.io/general/releases).
async function moodleSupport(branch, version) {
  const data = await cachedJson('https://raw.githubusercontent.com/moodle/devdocs/main/data/versions.json');
  const now = Date.now();
  const released = (data?.versions || []).filter((v) => parseDate(v.releaseDate) <= now);
  const latestPatch = (v) => (v.releases || []).filter((r) => parseDate(r.releaseDate) <= now).map((r) => r.name).pop() || `${v.name}`;
  const newest = released[0];
  const newestLts = released.find((v) => v.isLTS);
  const result = {
    latest: newest ? latestPatch(newest) : null,
    latestLts: newestLts ? latestPatch(newestLts) : null,
    status: 'unknown',
  };
  const entry = branch && released.find((v) => v.name === branch);
  if (!entry) return result;

  const generalEnd = parseDate(entry.generalEndDate);
  const securityEnd = parseDate(entry.securityEndDate);
  const latestInBranch = latestPatch(entry);
  return {
    ...result,
    branch,
    isLTS: !!entry.isLTS,
    releaseDate: parseDate(entry.releaseDate)?.toISOString() || null,
    generalEnd: generalEnd?.toISOString() || null,
    securityEnd: securityEnd?.toISOString() || null,
    latestInBranch,
    // Solo se puede decir que falta un parche si se conoce la versión exacta (4.1.3, no 4.1).
    patchOutdated: /^\d+\.\d+\.\d+/.test(version || '') && compareVersions(version, latestInBranch) < 0,
    newerBranch: newest && newest.name !== branch,
    status: now <= generalEnd ? 'supported' : now <= securityEnd ? 'security' : 'unsupported',
  };
}

// Tipos de plugin: carpeta dentro de Moodle → prefijo del componente (mod_forum, block_html…).
const PLUGIN_DIRS = [
  ['mod', 'mod'], ['blocks', 'block'], ['local', 'local'], ['theme', 'theme'], ['filter', 'filter'], ['auth', 'auth'],
  ['enrol', 'enrol'], ['report', 'report'], ['course/format', 'format'], ['admin/tool', 'tool'], ['question/type', 'qtype'],
  ['question/behaviour', 'qbehaviour'], ['lib/editor/tiny/plugins', 'tiny'], ['lib/editor/atto/plugins', 'atto'],
  ['availability/condition', 'availability'], ['grade/report', 'gradereport'], ['mod/assign/submission', 'assignsubmission'],
  ['mod/assign/feedback', 'assignfeedback'], ['mod/quiz/accessrule', 'quizaccess'], ['repository', 'repository'], ['media/player', 'media'],
];
const PLUGIN_TYPES = new Set([...PLUGIN_DIRS.map(([, type]) => type), 'aiplacement', 'aiprovider', 'customfield', 'datafield',
  'booktool', 'ltisource', 'paygw', 'h5plib', 'communication', 'qbank', 'gradingform', 'message', 'profilefield', 'factor', 'editor']);
const NOT_PLUGINS = new Set(['styles', 'image', 'font', 'javascript', 'yui_combo', 'jquery', 'index', 'view', 'amd', 'pix', 'templates', 'lang', 'classes']);

function scanMoodlePlugins(html, urls, root) {
  const found = new Map();
  const add = (type, name, evidence) => {
    if (!PLUGIN_TYPES.has(type) || NOT_PLUGINS.has(name) || name.length < 2) return;
    const component = `${type}_${name}`;
    if (!found.has(component)) found.set(component, { component, type, name, evidence: new Set() });
    found.get(component).evidence.add(evidence);
  };

  // Rutas de archivos: /mod/forum/…, /blocks/html/…, /course/format/tiles/…
  const base = new URL(root).pathname.replace(/\/$/, '');
  const sorted = [...PLUGIN_DIRS].sort((a, b) => b[0].length - a[0].length);
  for (const href of urls) {
    let url;
    try {
      url = new URL(href);
    } catch {
      continue;
    }
    if (url.origin !== new URL(root).origin || !url.pathname.startsWith(`${base}/`)) continue;
    const path = url.pathname.slice(base.length + 1);
    for (const [dir, type] of sorted) {
      const m = path.match(new RegExp(`^${dir.replace(/\//g, '\\/')}\\/([a-z][a-z0-9_]*)\\/`));
      if (m) {
        add(type, m[1], 'archivos de la página');
        break;
      }
    }
  }

  // Módulos AMD ("mod_forum/discussion", "theme_moove/loader") y componentes en URLs
  // como /pluginfile.php/1/theme_boost/logo/… o /theme/image.php/boost/mod_quiz/….
  const text = unescapeHtml(html) + '\n' + urls.join('\n');
  for (const m of text.matchAll(/[/'"]([a-z]+)_([a-z][a-z0-9_]*[a-z0-9])(?=[/'"])/g)) {
    add(m[1], m[2], 'módulos y recursos de la página');
  }
  return [...found.values()].slice(0, MAX_PLUGINS);
}

async function moodleCorePlugins() {
  const data = await cachedJson('https://raw.githubusercontent.com/moodle/moodle/main/lib/plugins.json');
  const core = new Set();
  for (const group of [data?.standard, data?.deleted]) {
    for (const [type, names] of Object.entries(group || {})) for (const name of names) core.add(`${type}_${name}`);
  }
  return core;
}

async function moodleProfile(hints, cfg, detected) {
  const page = new URL(hints.url);
  let root = page.origin;
  try {
    if (cfg?.wwwroot && new URL(cfg.wwwroot).origin === page.origin) root = cfg.wwwroot.replace(/\/$/, '');
  } catch {}
  const totara = detected.includes('Totara Learn');
  const html = unescapeHtml(hints.html);

  // Si la página actual no enlaza la documentación ni la app, puede que la portada sí.
  const pageDocs = docsBranch(html);
  const pageBuild = buildOf(html);
  const [front, upgradeTxt, upgradingMd, config, core] = await Promise.all([
    (pageDocs && pageBuild) || totara ? null : attempt(fetchText(`${root}/`).then(unescapeHtml)),
    attempt(fromUpgradeTxt(root)),
    attempt(fromUpgradingMd(root)),
    attempt(publicConfig(root)),
    attempt(moodleCorePlugins()),
  ]);

  const build = pageBuild || (front ? buildOf(front) : null);
  const sources = totara
    ? [
      { source: 'enlace a la ayuda de Totara', version: html.match(/help\.totaralearning\.com\/display\/TL(\d+)\//)?.[1] },
    ]
    : [
      // De más a menos fiable: estos enlaces los genera el código que está funcionando.
      { source: `enlace a la app móvil (compilación ${build})`, version: await attempt(releaseFromBuild(build)) },
      { source: 'enlace a docs.moodle.org de esta página', version: pageDocs },
      { source: 'enlace a docs.moodle.org de la portada', version: front ? docsBranch(front) : null },
      { source: 'UPGRADING.md', version: upgradingMd, atLeast: true },
      { source: 'lib/upgrade.txt', version: upgradeTxt, atLeast: true },
    ];
  const valid = sources.filter((s) => s.version && /^\d+(?:\.\d+)*$/.test(s.version));
  // La más fiable manda; si otra da la misma rama con más detalle (4.1 → 4.1.3), se usa esa.
  let version = valid[0]?.version || null;
  let atLeast = !!valid[0]?.atLeast;
  for (const s of valid) {
    if (version && s.version.startsWith(`${version}.`)) {
      version = s.version;
      atLeast = !!s.atLeast;
    }
  }

  const support = totara ? null : await attempt(moodleSupport(branchOf(version), version));
  if (support && atLeast) support.patchMaybeOutdated = support.patchOutdated;
  if (support && atLeast) support.patchOutdated = false;

  const plugins = scanMoodlePlugins(hints.html, hints.urls, root).map((p) => ({
    component: p.component,
    type: p.type,
    name: p.name,
    core: core ? core.has(p.component) : null,
    evidence: [...p.evidence],
  }));
  const theme = cfg?.theme || plugins.find((p) => p.type === 'theme')?.name || null;
  if (theme && !plugins.some((p) => p.component === `theme_${theme}`)) {
    plugins.push({ component: `theme_${theme}`, type: 'theme', name: theme, core: core ? core.has(`theme_${theme}`) : null, evidence: ['M.cfg.theme'] });
  }

  const facts = [];
  if (config) {
    if (config.sitename) facts.push(['Nombre del sitio', config.sitename]);
    facts.push(['Acceso de invitados', config.guestlogin ? 'Permitido' : 'No']);
    facts.push(['Registro propio', config.registerauth ? `Abierto (${config.registerauth})` : 'Cerrado']);
    facts.push(['App móvil de Moodle', config.enablemobilewebservice ? 'Habilitada' : 'Deshabilitada']);
    if ('tool_mfa_enabled' in config) facts.push(['Doble factor (MFA)', config.tool_mfa_enabled ? 'Activado' : 'Desactivado']);
    const providers = (config.identityproviders || []).map((p) => p.name).filter(Boolean);
    if (providers.length) facts.push(['Inicio de sesión con', providers.join(', ')]);
    if (config.maintenanceenabled) facts.push(['Mantenimiento', 'Activado']);
    if (config.lang) facts.push(['Idioma por defecto', config.lang]);
  }
  if (theme) facts.push(['Tema', core?.has(`theme_${theme}`) ? `${theme} (del núcleo)` : `${theme} (adicional)`]);

  return {
    name: totara ? 'Totara Learn' : detected.includes('Moodle Workplace') ? 'Moodle Workplace' : 'Moodle',
    root,
    siteName: config?.sitename || null,
    version: { value: totara && version ? `Totara ${version}` : version, atLeast: atLeast && /^\d+\.\d+\.\d+/.test(version || ''), sources: valid },
    support,
    facts,
    plugins: plugins.sort((a, b) => (a.core === b.core ? a.component.localeCompare(b.component) : a.core ? 1 : -1)),
    hiddenVersionNote: totara
      ? 'Totara no publica su versión en archivos públicos.'
      : 'El sitio oculta la versión (sin enlaces a docs.moodle.org ni a la app móvil, y con lib/upgrade.txt y UPGRADING.md bloqueados).',
  };
}

// --- Otras plataformas --------------------------------------------------------------------

async function chamiloProfile(hints, engineVersion) {
  const root = new URL(hints.url).origin;
  const changelog = await attempt(fetchText(`${root}/documentation/changelog.html`)
    .then((t) => t.match(/<h[1-3][^>]*>\s*Chamilo\s+(?:LMS\s+)?v?(\d+\.\d+(?:\.\d+)*)/i)?.[1] || null));
  const sources = [
    { source: 'documentation/changelog.html', version: changelog },
    { source: 'meta generator / X-Powered-By', version: engineVersion },
  ].filter((s) => s.version);
  let version = sources[0]?.version || null;
  for (const s of sources) if (version && s.version.startsWith(`${version}.`)) version = s.version;
  // Chamilo mantiene varias líneas a la vez: 1.11.x, 2.0.x, 3.0.x.
  const line = (v) => v.split('.').slice(0, 2).join('.');
  // Sin versión, al menos se distingue la generación: 1.x (PHP clásico) o 2.0+ (Symfony + Vue).
  const html = unescapeHtml(hints.html);
  const generation = /\/main\/inc\/lib\/javascript\//.test(html) ? 'Chamilo 1.x'
    : /\/build\/(?:legacy_app|vue)\.js/.test(html) ? 'Chamilo 2.0 o posterior (Symfony + Vue)' : null;
  return {
    version: { value: version, sources },
    releases: await attempt(githubLatest('chamilo/chamilo-lms', version || (generation === 'Chamilo 1.x' ? '1.11' : null), line)),
    facts: generation ? [['Generación', generation]] : [],
  };
}

async function iliasProfile(hints, engineVersion) {
  const fromAssets = mostCommon([...unescapeHtml(hints.html).matchAll(/[?&]version=(\d+)_(\d+)\b/g)].map((m) => `${m[1]}.${m[2]}`));
  const sources = [
    { source: '?version= de sus archivos', version: fromAssets || engineVersion },
  ].filter((s) => s.version);
  const version = sources[0]?.version || null;
  return { version: { value: version, sources }, releases: await attempt(githubLatest('ILIAS-eLearning/ILIAS', version, (v) => v.split('.')[0])) };
}

async function sakaiProfile(hints, engineVersion) {
  const sources = engineVersion ? [{ source: '?version= de sus scripts', version: engineVersion }] : [];
  return {
    version: { value: engineVersion || null, sources },
    releases: await attempt(githubLatest('sakaiproject/sakai', engineVersion, (v) => v.split('.')[0], { tags: true })),
  };
}

// Blackboard Learn publica su versión en una API pública (sin sesión).
async function blackboardProfile(hints, engineVersion) {
  const data = await attempt(fetchJson(`${new URL(hints.url).origin}/learn/api/public/v1/system/version`));
  const learn = data?.learn;
  const api = learn && Number.isFinite(learn.major) ? `${learn.major}.${learn.minor}.${learn.patch}` : null;
  const sources = [
    api && { source: '/learn/api/public/v1/system/version', version: api, build: learn.build || null },
    engineVersion && { source: 'cabecera X-Blackboard-Product', version: engineVersion },
  ].filter(Boolean);
  return {
    version: { value: sources[0]?.version || null, sources },
    facts: learn?.build ? [['Compilación', learn.build]] : [],
    note: 'Las versiones 3900 en adelante son Blackboard Learn SaaS (se actualiza cada mes); las 9.1 son instalaciones propias.',
  };
}

// D2L Brightspace: versiones de su API pública (cambian con cada actualización mensual).
async function d2lProfile(hints) {
  const list = await attempt(fetchJson(`${new URL(hints.url).origin}/d2l/api/versions/`));
  const byCode = Object.fromEntries((Array.isArray(list) ? list : []).map((p) => [p.ProductCode, p.LatestVersion]));
  const facts = [['API de la plataforma (LP)', byCode.lp], ['API de aprendizaje (LE)', byCode.le]].filter(([, v]) => v);
  return {
    version: { value: null, sources: [] },
    facts,
    note: 'Brightspace es un servicio en la nube que D2L actualiza cada mes: no tiene un número de versión público. Las versiones de su API indican la actualización instalada.',
  };
}

function canvasProfile(hints) {
  const host = new URL(hints.url).host;
  const cloud = /\.instructure\.com$/i.test(host) || hints.urls.some((u) => /du11hjcvx0uqb\.cloudfront\.net|instructure-uploads/.test(u));
  return {
    version: { value: null, sources: [] },
    facts: [['Alojamiento', cloud ? 'Nube de Instructure (versión comercial)' : 'Instalación propia (código abierto)']],
    note: cloud
      ? 'Instructure actualiza Canvas cada pocas semanas en su nube: siempre tiene la última versión.'
      : 'Canvas de código abierto no publica número de versión; se actualiza desde su repositorio (instructure/canvas-lms).',
  };
}

// --- Información general (para cualquier plataforma, también las hechas a medida) ----------

// Tecnologías de la plataforma por categoría: frameworks, lenguajes, servidor, base de datos…
const STACK_CATS = [1, 3, 4, 6, 7, 8, 9, 10, 13];
function stackOf(technologies) {
  return technologies
    .filter((t) => (t.categories.some((c) => STACK_CATS.includes(c.id)) || t.name === 'Keycloak') && !t.categories.some((c) => c.id === 27))
    .map((t) => (t.version ? `${t.name} ${t.version}` : t.name));
}

// Dominio de la institución: flavisur.edu.pe para aulavirtual.flavisur.edu.pe.
function siteDomain(host) {
  const parts = host.split('.');
  const n = /^(?:com|edu|gob|gov|org|net|ac|co|mil|nom)$/.test(parts.at(-2) || '') && parts.at(-1).length === 2 ? 3 : 2;
  return parts.slice(-n).join('.');
}

// Otros sistemas de la misma institución enlazados desde la página (intranet, web, matrícula…).
function relatedSystems(hints) {
  const host = new URL(hints.url).host;
  const domain = siteDomain(host);
  const hosts = new Set();
  for (const href of hints.urls) {
    try {
      const h = new URL(href).host;
      if (h !== host && (h === domain || h.endsWith(`.${domain}`))) hosts.add(h);
    } catch {}
  }
  return [...hosts].slice(0, 10);
}

// Quién la desarrolló: créditos del pie de página, «Desarrollado por…», copyright o meta author.
function developerOf(hints) {
  const lines = (hints.text || '').split(/\n+/).map((l) => l.trim()).filter(Boolean);
  const found = [];
  const push = (v) => {
    const clean = v.replace(/\s+/g, ' ').trim().replace(/[.,;:–-]+$/, '');
    if (clean.length >= 3 && !found.includes(clean)) found.push(clean);
  };
  for (const line of lines) {
    const m = line.match(/(?:desarrollad[oa]|elaborad[oa]|diseñad[oa]|implementad[oa]|powered)\s+(?:por|by)\s*:?\s*(.{3,80})/i);
    if (m) push(m[1]);
    if (/^(?:departamento|área|oficina|unidad|dirección)\s+de\s+(?:inform[aá]tica|sistemas|tecnolog[ií]a|tic)/i.test(line)) push(line.slice(0, 90));
  }
  for (const line of lines) {
    const m = line.match(/(?:©|\(c\)|copyright)\s*(?:\d{4}(?:\s*[-–]\s*\d{4})?)?\s*(.{3,70})/i);
    if (m) push(m[1].replace(/\s*(?:todos los derechos reservados|all rights reserved).*$/i, ''));
  }
  if (hints.author) push(hints.author);
  return found.slice(0, 3);
}

// Cómo se entra: formulario propio, recuperación de contraseña e inicio de sesión con terceros.
function loginInfo(hints) {
  const facts = [];
  const form = (hints.forms || []).find((f) => f.inputs.some((i) => i.type === 'password'));
  if (form) {
    const user = form.inputs.find((i) => i.type !== 'password' && i.type !== 'hidden' && i.type !== 'submit' && i.type !== 'checkbox');
    const label = user?.label || user?.name || '';
    const kind = /dni|documento/i.test(label) ? 'DNI / documento' : /c[oó]digo/i.test(label) ? 'código de alumno' : /mail|correo/i.test(label) ? 'correo' : label || 'usuario';
    let action = '';
    try {
      action = new URL(form.action).pathname;
    } catch {}
    facts.push(['Acceso', `Formulario propio con ${kind} y contraseña${action ? ` (envía a ${action})` : ''}`]);
  }
  const text = `${hints.text || ''}\n${hints.urls.join('\n')}`;
  if (/olvid[eé]|recuperar|restablecer|forgot|\/reset/i.test(text)) {
    const page = new URL(hints.url).host;
    const elsewhere = hints.urls.map((u) => {
      try {
        const url = new URL(u);
        return url.host !== page && /olvid|recuper|contrase|password|reset|clave/i.test(url.href) ? url.host : null;
      } catch {
        return null;
      }
    }).find(Boolean);
    facts.push(['Recuperar contraseña', elsewhere ? `Disponible (en ${elsewhere})` : 'Disponible']);
  }
  const sso = [
    [/accounts\.google\.com|google-signin|gsi\/client/i, 'Google'],
    [/login\.microsoftonline\.com|login\.live\.com/i, 'Microsoft'],
    [/facebook\.com\/(?:v[\d.]+\/)?dialog\/oauth/i, 'Facebook'],
  ].filter(([re]) => re.test(text)).map(([, name]) => name);
  if (sso.length) facts.push(['Inicio de sesión con', sso.join(', ')]);
  const captcha = [
    [/challenges\.cloudflare\.com\/turnstile|cf-turnstile/i, 'Cloudflare Turnstile'],
    [/google\.com\/recaptcha|recaptcha\/api|g-recaptcha/i, 'Google reCAPTCHA'],
    [/hcaptcha\.com/i, 'hCaptcha'],
  ].filter(([re]) => re.test(`${text}\n${hints.html.slice(0, 300000)}`)).map(([, name]) => name);
  if (captcha.length) facts.push(['Protección anti-bots', captcha.join(', ')]);
  if (form?.inputs.some((i) => i.type === 'checkbox' && /record|remember|manten/i.test(`${i.name} ${i.label}`))) facts.push(['Recordar sesión', 'Sí (casilla «Recordarme»)']);
  return facts;
}

// Servicios externos que la política de seguridad (CSP) del sitio permite cargar: describe
// qué integra la plataforma (pagos, chat, vídeo, almacenamiento…) aunque no estén en esta página.
const CSP_SERVICES = [
  ['Pagos', [[/culqi\.com/, 'Culqi'], [/vnforapps\.com/, 'Niubiz (VisaNet Perú)'], [/alignet|pay-me\.cloud/, 'Alignet / PayMe'], [/paypal\.com/, 'PayPal'],
    [/stripe\.com/, 'Stripe'], [/mercadopago|mercadolibre/, 'Mercado Pago'], [/payulatam|payu\.com/, 'PayU'], [/izipay/, 'Izipay'], [/wompi/, 'Wompi'], [/epayco/, 'ePayco'], [/openpay/, 'Openpay']]],
  ['Identidad y firma', [[/verifika\.com/, 'Verifika (validación de identidad)'], [/auco\.ai/, 'Auco (firma electrónica)'], [/docusign/, 'DocuSign']]],
  ['Soporte y chat', [[/zendesk|zdassets/, 'Zendesk'], [/tawk\.to/, 'Tawk.to'], [/intercom/, 'Intercom'], [/crisp\.chat/, 'Crisp'], [/freshchat|freshdesk/, 'Freshworks']]],
  ['Marketing y CRM', [[/hs-scripts|hs-analytics|hubapi|hsadspixel|hs-banner/, 'HubSpot'], [/connect\.facebook\.net|facebook\.com/, 'Meta (Facebook)'], [/secured-pixel\.com/, 'Píxel publicitario']]],
  ['Analítica', [[/dynatrace/, 'Dynatrace'], [/rum\.[\w-]+\.amazonaws\.com|dataplane\.rum/, 'Amazon CloudWatch RUM'], [/clarity\.ms/, 'Microsoft Clarity'], [/contentsquare/, 'Contentsquare'], [/google-analytics|analytics\.google/, 'Google Analytics'], [/googletagmanager/, 'Google Tag Manager'], [/hotjar/, 'Hotjar']]],
  ['Publicidad', [[/googlesyndication|doubleclick|googleadservices|googletagservices|adtrafficquality/, 'Google Ads / AdSense']]],
  ['Vídeo y contenidos', [[/youtube\.com/, 'YouTube'], [/vimeo\.com/, 'Vimeo'], [/jwplayer|jwpcdn/, 'JW Player'], [/genial\.ly|genially/, 'Genially'], [/articulate\.com/, 'Articulate (cursos SCORM)'],
    [/h5p\./, 'H5P'], [/plyr\.io/, 'Plyr'], [/highcharts/, 'Highcharts'], [/ckeditor/, 'CKEditor'], [/maps\.googleapis/, 'Google Maps'], [/translate\.googleapis/, 'Google Translate']]],
  ['Infraestructura', [[/blob\.core\.windows\.net/, 'Azure Blob Storage'], [/service\.signalr\.net/, 'Azure SignalR (tiempo real)'], [/\.s3[.-][\w.-]*amazonaws\.com|s3\.amazonaws/, 'Amazon S3'],
    [/cloudfront\.net/, 'Amazon CloudFront'], [/sentry\.io/, 'Sentry (errores)'], [/firebase|googleapis\.com\/identitytoolkit/, 'Firebase']]],
  ['Seguridad', [[/challenges\.cloudflare\.com/, 'Cloudflare Turnstile'], [/recaptcha|google\.com\/recaptcha/, 'Google reCAPTCHA'], [/hcaptcha/, 'hCaptcha']]],
];
function cspServices(headers) {
  const csp = (headers?.['content-security-policy'] || []).join(' ');
  if (!csp) return [];
  const hosts = [...new Set(csp.split(/\s+/).filter((s) => /\./.test(s) && !/^'/.test(s)))].join(' ');
  return CSP_SERVICES
    .map(([group, list]) => [group, [...new Set(list.filter(([re]) => re.test(hosts)).map(([, name]) => name))]])
    .filter(([, names]) => names.length);
}

// Cabeceras de seguridad HTTP del documento.
function securityHeaders(headers) {
  if (!headers || !Object.keys(headers).length) return null;
  const checks = [
    ['strict-transport-security', 'HSTS'],
    ['content-security-policy', 'CSP'],
    ['x-frame-options', 'X-Frame-Options'],
    ['x-content-type-options', 'X-Content-Type-Options'],
    ['referrer-policy', 'Referrer-Policy'],
    ['permissions-policy', 'Permissions-Policy'],
  ];
  const present = checks.filter(([h]) => headers[h]).map(([, n]) => n);
  const missing = checks.filter(([h]) => !headers[h]).map(([, n]) => n);
  return `${present.length}/${checks.length}: ${present.join(', ') || 'ninguna'}${missing.length ? ` · faltan ${missing.join(', ')}` : ''}`;
}

// País por el idioma de la página: es-PE → Perú.
function countryOf(lang) {
  const region = String(lang || '').match(/^[a-z]{2,3}[-_]([A-Z]{2})\b/i)?.[1];
  if (!region) return null;
  try {
    return new Intl.DisplayNames(['es'], { type: 'region' }).of(region.toUpperCase());
  } catch {
    return null;
  }
}

// Nombre de la institución que usa la plataforma («Le damos la bienvenida a …», alt del logo).
function institutionOf(hints) {
  const text = (hints.text || '').replace(/&nbsp;/g, ' ');
  const m = text.match(/(?:le damos la bienvenida a|bienvenid[oa]s? a(?:l| la)?)\s+(.{4,120}?)(?:\s*["“«(]|[\n!.]|$)/i);
  if (m && !/^(?:nuestr|tu |su |la plataforma|el aula|el campus)/i.test(m[1])) return m[1].trim();
  const logo = (hints.images || []).find((i) => /logo/i.test(i.src) && i.alt.length > 3 && !/^logo$/i.test(i.alt));
  return logo ? logo.alt.replace(/^logo\s+(?:de\s+)?/i, '') : null;
}

// Q10: cada institución es un cliente (aplentId) alojado en un servidor siteN.q10.com.
function q10Profile(hints) {
  const url = new URL(hints.url);
  const facts = [];
  const tenant = url.searchParams.get('aplentId') || hints.html.match(/aplentId=([0-9a-f-]{36})/i)?.[1];
  if (tenant) facts.push(['ID de cliente (aplentId)', tenant]);
  const server = url.host.match(/^(site\d+)\.q10\.com$/i)?.[1];
  if (server) facts.push(['Servidor de Q10', `${server} (${url.host})`]);
  const sites = [...new Set(hints.urls.map((u) => {
    try {
      const h = new URL(u).host;
      return !/q10|google|cloudflare|contentsquare|icomoon|clarity|facebook|zendesk|tawk/i.test(h) && /\.(?:edu|ac|org|gob)(?:\.[a-z]{2})?$|\.edu$/.test(h) ? h : null;
    } catch {
      return null;
    }
  }).filter(Boolean))];
  if (sites.length) facts.push(['Web de la institución', sites.join(', ')]);
  const logo = hints.urls.find((u) => /cdn\.q10\.com\/public\//.test(u));
  if (logo) facts.push(['Logo de la institución', logo.replace(/#.*$/, '')]);
  facts.push(['Módulos de Q10', 'Gestión comercial, admisiones y matrículas, gestión académica, gestión financiera, educación virtual (aulas virtuales), bienestar estudiantil']);
  return {
    version: { value: null, sources: [] },
    facts,
    note: 'Q10 es un servicio en la nube (SaaS) que actualiza su proveedor: todas las instituciones usan la misma versión y no se publica su número.',
  };
}

// Módulos propios de una aplicación Symfony (/bundles/<nombre>/), sin los de terceros conocidos.
const VENDOR_BUNDLES = /^(?:framework|fosjsrouting|fosuser|fosckeditor|fosrest|twig|webprofiler|sonata\w*|easyadmin|apiplatform|nelmio\w*|liipimagine|bazinga\w*|stof\w*|vich\w*|knp\w*|ckeditor|doctrine\w*|jms\w*|lexik\w*|oneup\w*|sensio\w*|ewz\w*|gregwar\w*|white_october\w*|whiteoctober\w*|avanzu\w*|mopa\w*|craue\w*)$/i;
function customModules(hints) {
  const names = new Set();
  for (const m of unescapeHtml(hints.html + '\n' + hints.urls.join('\n')).matchAll(/\/bundles\/([a-z][a-z0-9_]+)\//gi)) {
    if (!VENDOR_BUNDLES.test(m[1])) names.add(m[1].toLowerCase());
  }
  return [...names].slice(0, 6);
}

// Señales de que una página sin LMS conocido es una plataforma educativa.
const EDU_WORDS = /\b(?:aula|campus|plataforma|entorno)\s*virtual|intranet\s+(?:acad[eé]mica|estudiantil)|e-?learning|\b(?:alumnos?|estudiantes?|docentes?|matr[ií]cula)\b/i;
function looksEducational(hints) {
  const host = new URL(hints.url).host;
  const edu = /\.edu(?:\.[a-z]{2})?$|\.ac\.[a-z]{2}$/.test(host);
  const words = EDU_WORDS.test(`${hints.title}\n${(hints.text || '').slice(0, 5000)}`) || /^(?:aula|campus|virtual|elearning|lms)/i.test(host);
  const login = (hints.forms || []).some((f) => f.inputs.some((i) => i.type === 'password'));
  return (edu && (words || login)) || (words && login);
}

function customProfile(hints, technologies) {
  const modules = customModules(hints);
  const developer = developerOf(hints);
  const stack = stackOf(technologies);
  const facts = [];
  if (modules.length) facts.push(['Módulos propios', modules.join(', ')]);
  if (developer.length) facts.push(['Desarrollado por', developer.join(' · ')]);
  return {
    version: { value: null, sources: [] },
    facts,
    note: 'No coincide con ningún LMS conocido (Moodle, Chamilo, Canvas…): es un desarrollo propio de la institución o de un proveedor local' +
      (stack.length ? `, construido con ${stack.slice(0, 3).join(', ')}` : '') + '. No tiene versión pública ni se puede comparar con una versión oficial.',
  };
}

// --- Inicio de sesión único (SSO) -----------------------------------------------------------
// Muchas plataformas mandan primero a un servidor de identidad (Keycloak, CAS, SAML…). Desde ahí se
// puede saber a qué aplicación se va a entrar (redirect_uri) y analizarla también.

function detectSso(hints, technologies) {
  const url = new URL(hints.url);
  const p = url.searchParams;
  const keycloak = url.pathname.match(/\/realms\/([^/]+)\/(?:protocol\/openid-connect|login-actions)\//);
  let provider = null;
  if (keycloak || technologies.some((t) => t.name === 'Keycloak')) provider = 'Keycloak';
  else if (/login\.microsoftonline\.com$/.test(url.host)) provider = 'Microsoft Entra ID';
  else if (/accounts\.google\.com$/.test(url.host)) provider = 'Google';
  else if (/\/cas\/login$/.test(url.pathname) && p.get('service')) provider = 'CAS';
  else if (p.get('SAMLRequest') || /\/idp\/(?:profile\/SAML2|module\.php)|\/saml2?\//i.test(url.pathname)) provider = 'SAML (Shibboleth / SimpleSAMLphp)';
  else if (p.get('client_id') && p.get('redirect_uri') && p.get('response_type')) provider = 'OpenID Connect / OAuth 2';
  if (!provider) return null;
  return {
    provider,
    realm: keycloak ? decodeURIComponent(keycloak[1]) : null,
    issuer: keycloak ? `${url.origin}/realms/${keycloak[1]}` : null,
    clientId: p.get('client_id'),
    redirect: p.get('redirect_uri') || p.get('service') || null,
    responseType: p.get('response_type'),
    pkce: p.get('code_challenge_method'),
    scope: p.get('scope'),
    theme: hints.html.match(/\/resources\/[\w-]+\/login\/([\w.-]+)\//)?.[1] || null,
    social: [...new Set([...hints.html.matchAll(/id="social-([\w-]+)"/g)].map((m) => m[1]))],
  };
}

// Plataformas educativas que puede mencionar el código de una aplicación propia.
const MENTIONS = [
  ['Canvas', /\bCanvas\b(?!\s*(?:API|Rendering|Context|Element|Gradient|Pattern))|instructure\.com/g],
  ['Moodle', /\bMoodle\b/gi], ['Blackboard', /\bBlackboard\b/g], ['Brightspace / D2L', /\bBrightspace\b|\bD2L\b/g],
  ['Chamilo', /\bChamilo\b/gi], ['Google Classroom', /classroom\.google\.com|Google Classroom/g],
  ['Microsoft Teams', /teams\.microsoft\.com|Microsoft Teams/g], ['Zoom', /[\w-]*\.?zoom\.us\b/g],
];

const FRAMEWORK_HINTS = [
  [/\/static\/js\/main\.[0-9a-f]+\.chunk\.js/, 'React (Create React App)'], [/\/_next\/static\//, 'Next.js (React)'],
  [/\/_nuxt\//, 'Nuxt (Vue)'], [/ng-version=|main-es20\d\d\.|\/main\.[0-9a-f]{16,}\.js/, 'Angular'],
  [/\/assets\/index-[\w-]+\.js/, 'Vite (React / Vue)'], [/\/_framework\/blazor/, 'Blazor'], [/<div id="app"><\/div>/, 'Vue'],
];

// Página de destino del SSO: título, tecnología, alojamiento, servicios y sistemas que enlaza su código.
async function destinationInfo(target) {
  let url;
  try {
    url = new URL(target);
  } catch {
    return null;
  }
  if (!/^https?:$/.test(url.protocol)) return null;
  const res = await fetch(url.href, { credentials: 'omit', signal: AbortSignal.timeout(10_000), redirect: 'follow' });
  const html = (await res.text()).slice(0, 500_000);
  const headers = {};
  res.headers.forEach((value, name) => (headers[name.toLowerCase()] ||= []).push(value));
  const h = (name) => headers[name]?.[0] || '';
  const hosting = [
    (h('x-amz-cf-id') || /cloudfront/i.test(h('via') + h('x-cache') + h('server'))) && 'Amazon CloudFront',
    (h('x-amz-server-side-encryption') || /AmazonS3/i.test(h('server'))) && 'Amazon S3',
    h('cf-ray') && 'Cloudflare',
    /vercel/i.test(h('server')) && 'Vercel', /netlify/i.test(h('server')) && 'Netlify',
    h('x-azure-ref') && 'Azure Front Door',
  ].filter(Boolean);
  const scripts = [...html.matchAll(/<script[^>]+src=["']([^"']+)/gi)].map((m) => {
    try {
      return new URL(m[1].replace(/&amp;/g, '&'), url).href;
    } catch {
      return null;
    }
  }).filter(Boolean);

  // Código de la aplicación (mismo origen): sistemas de la institución y plataformas que menciona.
  const bundles = scripts.filter((s) => new URL(s).origin === url.origin && /(?:main|app|index)[.-][\w.-]*\.js/.test(s)).slice(0, 2);
  let code = '';
  for (const src of bundles) {
    const text = await attempt(fetchText(src));
    if (text) code += text.slice(0, 8_000_000);
  }
  const domain = siteDomain(url.host);
  const systems = [...new Set([...`${html}\n${code}`.matchAll(/https?:\/\/([a-z0-9.-]+\.[a-z]{2,})/gi)]
    .map((m) => m[1].toLowerCase()).filter((host) => host !== url.host && (host === domain || host.endsWith(`.${domain}`))))];
  const mentions = MENTIONS.map(([name, re]) => [name, (code.match(re) || []).length]).filter(([, n]) => n > 0);

  return {
    url: url.href,
    title: html.match(/<title[^>]*>([^<]*)/i)?.[1]?.trim() || null,
    description: html.match(/<meta[^>]+name=["']description["'][^>]+content=["']([^"']*)/i)?.[1] || null,
    frameworks: FRAMEWORK_HINTS.filter(([re]) => re.test(html)).map(([, name]) => name).slice(0, 2),
    hosting,
    services: cspServices(headers),
    security: securityHeaders(headers),
    systems: systems.slice(0, 20),
    virtualClass: systems.filter((s) => /^(?:class|aula|aulas|campus|virtual|lms|moodle|canvas|blackboard|elearning|cursos)[\w-]*\./.test(s)),
    mentions,
  };
}

async function ssoProfile(hints, sso) {
  const facts = [['Proveedor de identidad', sso.provider]];
  if (sso.realm) facts.push(['Realm (espacio de usuarios)', sso.realm]);
  if (sso.clientId) facts.push(['Aplicación que pide el acceso', sso.clientId]);
  let destination = null;
  if (sso.redirect) {
    try {
      const r = new URL(sso.redirect);
      facts.push(['Destino tras iniciar sesión', `${r.host}${r.pathname}`]);
    } catch {}
  }
  if (sso.responseType) {
    const flow = sso.responseType === 'code' ? 'Authorization Code' : sso.responseType.includes('token') ? 'Implícito (obsoleto, menos seguro)' : sso.responseType;
    facts.push(['Flujo OAuth', `${flow}${sso.pkce ? ` con PKCE (${sso.pkce})` : sso.responseType === 'code' ? ' sin PKCE' : ''}`]);
  }
  if (sso.scope) facts.push(['Permisos solicitados (scope)', sso.scope]);
  if (sso.theme) facts.push(['Tema de la pantalla de acceso', sso.theme]);
  if (sso.provider === 'Keycloak') facts.push(['Inicio con redes / otros proveedores', sso.social.length ? sso.social.join(', ') : 'Ninguno configurado']);

  const [config, dest] = await Promise.all([
    sso.issuer ? attempt(fetchJson(`${sso.issuer}/.well-known/openid-configuration`)) : null,
    sso.redirect ? attempt(destinationInfo(sso.redirect)) : null,
  ]);
  if (config?.issuer) facts.push(['Emisor OpenID', config.issuer]);
  destination = dest;

  return {
    version: { value: null, sources: [] },
    facts,
    destination,
    note: 'Esta es la pantalla de inicio de sesión único (SSO) de la institución, no la plataforma educativa en sí: tras identificarte, te lleva a la aplicación de destino.',
  };
}

// --- Perfil completo ----------------------------------------------------------------------

export async function lmsProfile({ tabId, technologies, headers = {} }) {
  let lms = technologies.filter((t) => t.categories.some((c) => c.id === 27));
  const checkedAt = new Date().toISOString();

  let hints, cfg;
  try {
    [[{ result: hints }], [{ result: cfg }]] = await Promise.all([
      chrome.scripting.executeScript({ target: { tabId }, func: collectLmsHints, args: [MAX_HTML] }),
      chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: collectLmsRuntime }),
    ]);
  } catch (err) {
    throw new Error(`El navegador no permite inspeccionar esta página (${err.message}).`);
  }

  // Ningún LMS conocido: si la página parece educativa (dominio .edu, «aula virtual», acceso de
  // alumnos…), se trata como una plataforma propia y se describe igualmente.
  const sso = lms.length ? null : detectSso(hints, technologies);
  if (sso) {
    lms = [{ name: 'Inicio de sesión único (SSO)', version: '', website: '', description: `Servidor de identidad ${sso.provider} de la institución.` }];
  } else if (!lms.length && looksEducational(hints)) {
    lms = [{ name: 'Aula virtual propia', version: '', website: '', description: '' }];
  }
  if (!lms.length) return { isLms: false, checkedAt };

  const names = lms.map((t) => t.name);
  const main = lms.find((t) => KIND[t.name] !== 'cloud') || lms[0];
  const engineVersion = main.version || null;
  const base = { isLms: true, url: hints.url, checkedAt, detected: names, kind: KIND[main.name] || 'open', root: new URL(hints.url).origin };

  let detail;
  if (['Moodle', 'Moodle Workplace', 'Totara Learn'].includes(main.name)) detail = await moodleProfile(hints, cfg, names);
  else if (main.name === 'Chamilo') detail = await chamiloProfile(hints, engineVersion);
  else if (main.name === 'ILIAS') detail = await iliasProfile(hints, engineVersion);
  else if (main.name === 'Sakai') detail = await sakaiProfile(hints, engineVersion);
  else if (main.name === 'Blackboard Learn') detail = await blackboardProfile(hints, engineVersion);
  else if (main.name === 'D2L Brightspace') detail = await d2lProfile(hints);
  else if (main.name === 'Canvas LMS') detail = canvasProfile(hints);
  else if (main.name === 'Aula virtual propia') detail = customProfile(hints, technologies);
  else if (main.name === 'Q10') detail = q10Profile(hints);
  else if (sso) detail = await ssoProfile(hints, sso);
  else {
    detail = {
      version: { value: engineVersion, sources: engineVersion ? [{ source: 'reglas de detección', version: engineVersion }] : [] },
      note: KIND[main.name] === 'open'
        ? `${main.name} no publica su versión en archivos públicos.`
        : `${main.name} es un servicio en la nube: el proveedor lo actualiza y no muestra número de versión.`,
    };
  }

  const general = [];
  const institution = detail.siteName ? null : institutionOf(hints);
  if (institution) general.push(['Institución', institution]);
  const country = countryOf(hints.lang);
  if (country) general.push(['País (idioma de la página)', country]);
  const security = securityHeaders(headers);
  if (security) general.push(['Cabeceras de seguridad', security]);
  const own = detail.facts || [];
  const facts = [...general, ...own, ...loginInfo(hints).filter(([label]) => !own.some(([l]) => l === label))];
  return {
    ...base,
    name: main.name,
    website: main.website,
    description: main.description,
    title: hints.title || null,
    ...detail,
    facts,
    stack: stackOf(technologies),
    // En las plataformas en la nube el dominio es del proveedor (cdn.q10.com…), no de la institución.
    related: ['cloud', 'corporate'].includes(base.kind) ? [] : relatedSystems(hints),
    services: cspServices(headers),
  };
}
